const inspector=require('node:inspector');
const {PerformanceObserver}=require('node:perf_hooks');
const session=new inspector.Session();session.connect();
const gc=[];const observer=new PerformanceObserver(list=>{for(const e of list.getEntries())gc.push({duration:e.duration,kind:e.detail.kind});});observer.observe({entryTypes:['gc']});
const post=(method,params={})=>new Promise((resolve,reject)=>session.post(method,params,(error,result)=>error?reject(error):resolve(result)));
let zeroExits=0,completed=0;const times=[];const originalExit=process.exit;
process.exit=code=>{if(code!==0)throw Error('Nonzero generated exit: '+code);zeroExits++;};
function freshProgram(){
function word_to_u32(w) {
  let x = 0;
  for (let i = 0; w.$ === "WCon"; i++) {
    x |= Number(w.head) << i;
    w = w.tail;
  }
  return x >>> 0;
}

function u32_to_word(x) {
  let w = {$: "WNil"};
  for (let i = 31; i >= 0; i--) {
    w = {$: "WCon", head: ((x >>> i) & 1) === 1, tail: w};
  }
  return w;
}

function cmp_new(a, b) {
  return {$: a < b ? "LT"
    : a === b ? "EQ" : "GT"};
}

function nat_divmod(a, b) {
  return b === 0 ? {$: "Tuple", fst: 0, snd: a}
    : {$: "Tuple", fst: Math.trunc(a / b), snd: a % b};
}

function nat_chk(n) {
  if (n > 281474976710655) {
    throw "bend: a Nat past the largest immediate 2^48-1";
  }
  return n;
}

function nat_host(n) {
  const int = typeof n === "bigint" || Number.isInteger(n);
  if (int && n >= 0 && n <= 2 ** 53) {
    return Number(n);
  }
  return { [Symbol.toPrimitive]() { throw "bend: a Nat past the largest immediate 2^48-1"; } };
}

function f32_show(x) {
  if (x !== x) {
    return "nan";
  }
  if (!Number.isFinite(x) || Object.is(x, -0)) {
    return x < 0 ? "-inf"
      : x === 0 ? "-0" : "inf";
  }
  let s = "x";
  for (let p = 1; p <= 9 && f32_round(s) !== x; p += 1) {
    s = String(Number(x.toExponential(p - 1)));
  }
  return s;
}

function f32_bits(x) {
  return new Uint32Array(new Float32Array([x]).buffer)[0];
}

function f32_from_bits(u) {
  return new Float32Array(new Uint32Array([u]).buffer)[0];
}

function f32_read(s) {
  const re = /^\s*[+-]?((\d+\.?\d*|\.\d+)(e[+-]?\d+)?|inf(inity)?|nan)$/i;
  const v = f32_round(s.replace(/inf\w*/i, "Infinity"));
  return re.test(s) ? {$: "Some", value: v} : {$: "None"};
}

const f32_round = function f32_round(s) {
  const d = Number(s);
  const a = Math.abs(d);
  const f = Math.fround(a);
  const g = 2 * a - Math.min(f, 2 ** 128);
  if (g === f || Math.fround(g) !== g || g === Infinity) {
    return Math.sign(d) * f;
  }
  let k = 0;
  while (a * 2 ** k % 1 !== 0) {
    k += 1;
  }
  const [, i, r, e] = /(\d*)\.?(\d*)(?:e([+-]?\d+))?$/i.exec(s);
  const n = Number(e ?? 0) - r.length;
  const x = BigInt(i + r) * 2n ** BigInt(k) * 10n ** BigInt(Math.max(n, 0));
  const y = BigInt(a * 2 ** k) * 10n ** BigInt(Math.max(-n, 0));
  return Math.sign(d) * (x === y || x > y !== g > f ? f : g);
};

function char_new(code) {
  if (code > 0x10FFFF || (code >= 0xD800 && code <= 0xDFFF)) {
    throw "bend: " + code + " is not a Unicode scalar value";
  }
  return String.fromCodePoint(code);
}

// Array
// =====

function array_new(d, v) {
  if (d > 31) {
    throw "bend: an array past the deepest block class 31";
  }
  return Array(2 ** d).fill(v);
}

function array_node(a, b) {
  if (a.length !== b.length) {
    throw "bend: runtime fail-stop";
  }
  return a.concat(b);
}

function array_rmw(a, i, f) {
  const at = i % a.length;
  const old = a[at];
  a[at] = f(old);
  return {$: "Tuple", fst: a, snd: old};
}

// Run
// ===

function run_tail(f, x) {
  return {$: "$JMP", f: f.j?.f === f ? f.j : f, x: [x]};
}

function run_clo(j) {
  const f = (x) => run_loop(j(x));
  f.j = j;
  j.f = f;
  return f;
}

function run_loop(r) {
  while (r !== null && typeof r === "object" && r.$ === "$JMP") {
    r = r.f(...r.x);
  }
  return r;
}

function run_lib(f, n) {
  return (...a) => a.length < n ? run_lib((...b) => f(...a, ...b), n - a.length)
    : f(...a);
}

// Effect
// ======

const $0eff = Object.create(null);

function io_eff(k, run, need) {
  if (k in $0eff) {
    throw new Error("bend: two effects register " + k);
  }
  $0eff[k] = { run, need };
}
(() => {
// IO
// ==

function io_print(text) {
  io_out(1, io_bytes(text + "\n"));
  return { $: "Unit" };
}

io_eff("IO.print", io_print);

})();

for (const k of ["IO.print"]) {
  if (!(k in $0eff)) {
    throw new Error("bend: no effect registers " + k);
  }
}

// Program
// =======

function $main$() {
  return $run$(10);
}

function $run$(_fuel_0) {
  if (_fuel_0 === 0) {
    return run_clo((_x_0) => {
  return $IO$pure$({$: "Unit"}, _x_0);
});
  } else {
    const _rest_0 = (_fuel_0 - 1);
    return run_clo((_x_1) => {
  const _x_2 = ($json$058array$(($driver$058equivalent$())));
  const _x_3 = (_x_2 + "}");
  return $IO$bind$((_x_4) => $IO$print$(("{\"format\":1,\"application\":\"Workshop\",\"checkpoints\":" + _x_3), _x_4), run_clo((_x_5) => {
  return $run$(_rest_0);
}), _x_1);
});
  }
}

function $IO$pure$(_x_0, _k_0) {
  return run_tail(_k_0, _x_0);
}

function $IO$bind$(_m_0, _f_0, _k_0) {
  return run_tail(_m_0, run_clo((_x_0) => {
  return run_tail(_f_0(_x_0), _k_0);
}));
}

function $IO$print$(_text_0, _k_0) {
  return { $: "$FFI", run: $0eff["IO.print"].run, need: $0eff["IO.print"].need, args: [(_text_0)], kont: (_k_0) };
}
function $json$058array$(_values_0) {
  return $List$show$1261$(_values_0);
}

function $driver$058equivalent$() {
  return $driver$058run_ready$(($driver$058init_created$(($schema$058create$(($$$$047$$$047src$047ecs$047world$058factory$()))))));
}

function $List$show$1261$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($json$058raw$(_h_0));
    const _x_1 = ($List$show$go$1261$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $driver$058run_ready$(_result_0) {
  if (_result_0.$ === "None") {
    return {$: "Con", "head": "{\"initFailure\":true}", "tail": {$: "Nil"}};
  } else {
    const _state_0 = _result_0["value"];
    return $driver$058finish$(($driver$058phase_advanced$(($driver$058phase_duplicate$(($driver$058phase_churn$(($driver$058phase_remove$(($driver$058phase_insert$(($driver$058phase_retry$(($driver$058phase_work$(($driver$058phase_seed$(_state_0)))))))))))))))));
  }
}

function $driver$058init_created$(_result_0) {
  if (_result_0.$ === "../../src/ecs/world.Created") {
    const _factory_0 = _result_0["factory"];
    const _world_0 = _result_0["world"];
    return $driver$058init_work$(_factory_0, ($$$$047$$$047src$047ecs$047system$058register$1262$(_world_0, "produce", {$: "Con", "head": "Stock.write", "tail": {$: "Con", "head": "Recipe.read", "tail": {$: "Con", "head": "Queue.optional", "tail": {$: "Con", "head": "Enabled.present", "tail": {$: "Con", "head": "Locked.absent", "tail": {$: "Nil"}}}}}})));
  } else {
    return {$: "None"};
  }
}

function $schema$058create$(_factory_0) {
  return $$$$047$$$047src$047ecs$047world$058create$1260$(_factory_0, {$: "Unit"});
}

function $$$$047$$$047src$047ecs$047world$058factory$() {
  return {$: "../../src/ecs/world.Factory", "nextNamespace": 1};
}

function $json$058raw$(_s_0) {
  return _s_0;
}

function $List$show$go$1261$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($json$058raw$(_h_0));
    const _x_1 = ($List$show$go$1261$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $driver$058finish$(_state_0) {
  const _checkpoints_0 = _state_0["checkpoints"];
  return $List$reverse$(_checkpoints_0);
}

function $driver$058phase_advanced$(_state_0) {
  return $driver$058step_advanced$(($driver$058change$1265$(($driver$058step_advanced$(($driver$058step_advanced$(_state_0, "advanced-first")), "advanced-repeat")))), "advanced-replacement");
}

function $driver$058phase_duplicate$(_state_0) {
  return $driver$058record$(($driver$058step_duplicate$(_state_0)), "duplicate-final-world");
}

function $driver$058phase_churn$(_state_0) {
  return $driver$058record$(($driver$058step_work$(($driver$058record$(($driver$058change$1260$(($driver$058record$(($driver$058change$1264$(_state_0)), "churn-pending")))), "churn-visible")))), "work-after-churn");
}

function $driver$058phase_remove$(_state_0) {
  return $driver$058record$(($driver$058change$1260$(($driver$058record$(($driver$058change$1263$(_state_0)), "remove-pending")))), "remove-visible");
}

function $driver$058phase_insert$(_state_0) {
  return $driver$058record$(($driver$058change$1260$(($driver$058record$(($driver$058change$1262$(_state_0)), "insert-pending")))), "insert-visible");
}

function $driver$058phase_retry$(_state_0) {
  return $driver$058record$(($driver$058change$1260$(($driver$058record$(($driver$058step_retry$(($driver$058record$(($driver$058change$1260$(($driver$058record$(($driver$058step_retry$(_state_0, true)), "rollback-three-families")))), "rollback-no-command")), false)), "retry-committed-command-pending")))), "retry-command-visible");
}

function $driver$058phase_work$(_state_0) {
  return $driver$058record$(($driver$058step_work$(($driver$058record$(($driver$058step_work$(_state_0)), "work-first")))), "work-repeat");
}

function $driver$058phase_seed$(_state_0) {
  return $driver$058record$(($driver$058change$1260$(($driver$058record$(($driver$058change$1261$(($driver$058record$(_state_0, "empty")))), "spawn-pending")))), "seed-visible");
}

function $driver$058init_work$(_factory_0, _result_0) {
  if (_result_0.$ === "../../src/ecs/system.Registered") {
    const _world_0 = _result_0["world"];
    const _work_0 = _result_0["registry"];
    return $driver$058init_retry$(_factory_0, _work_0, ($$$$047$$$047src$047ecs$047system$058register$1261$(_world_0, "retry", {$: "Con", "head": "Stock.write", "tail": {$: "Con", "head": "Recipe.write", "tail": {$: "Con", "head": "Queue.write", "tail": {$: "Con", "head": "Enabled.present", "tail": {$: "Con", "head": "Locked.absent", "tail": {$: "Con", "head": "Queue.insert", "tail": {$: "Nil"}}}}}}})));
  } else {
    return {$: "None"};
  }
}

function $$$$047$$$047src$047ecs$047system$058register$1262$(_world_0, _name_0, _access_0) {
  return $$$$047$$$047src$047ecs$047system$058register_namespace$1262$(($$$$047$$$047src$047ecs$047world$058namespace$1260$(_world_0)), _name_0, _access_0);
}

function $$$$047$$$047src$047ecs$047world$058create$1260$(_factory_0, _resource_0) {
  const _namespace_0 = _factory_0["nextNamespace"];
  return $$$$047$$$047src$047ecs$047world$058create_checked$1260$((_namespace_0 < 4294967295), _namespace_0, _resource_0);
}

function $List$reverse$(_xs_0) {
  return $List$reverse$go$(_xs_0, {$: "Nil"});
}

function $driver$058step_advanced$(_state_0, _label_0) {
  const _factory_0 = _state_0["factory"];
  const _world_0 = _state_0["world"];
  const _work_0 = _state_0["work"];
  const _retry_0 = _state_0["retry"];
  const _advanced_0 = _state_0["advanced"];
  const _checkpoints_0 = _state_0["checkpoints"];
  return $driver$058advanced_cursor$(_factory_0, _work_0, _retry_0, _advanced_0, _checkpoints_0, _label_0, _world_0);
}

function $driver$058change$1265$(_state_0) {
  const _factory_0 = _state_0["factory"];
  const _world_0 = _state_0["world"];
  const _work_0 = _state_0["work"];
  const _retry_0 = _state_0["retry"];
  const _advanced_0 = _state_0["advanced"];
  const _checkpoints_0 = _state_0["checkpoints"];
  return {$: "driver.State", "factory": _factory_0, "world": run_loop($scenario$045ops$058barrier$(($scenario$045ops$058advanced_replace$(_world_0)))), "work": _work_0, "retry": _retry_0, "advanced": _advanced_0, "checkpoints": _checkpoints_0};
}

function $driver$058record$(_state_0, _label_0) {
  const _factory_0 = _state_0["factory"];
  const _world_0 = _state_0["world"];
  const _work_0 = _state_0["work"];
  const _retry_0 = _state_0["retry"];
  const _advanced_0 = _state_0["advanced"];
  const _checkpoints_0 = _state_0["checkpoints"];
  return $driver$058record_rows$({$: "driver.Owners", "factory": _factory_0, "work": _work_0, "retry": _retry_0, "advanced": _advanced_0, "checkpoints": _checkpoints_0}, _label_0, ($observe$058all$(_world_0)));
}

function $driver$058step_duplicate$(_state_0) {
  const _factory_0 = _state_0["factory"];
  const _world_0 = _state_0["world"];
  const _work_0 = _state_0["work"];
  const _retry_0 = _state_0["retry"];
  const _advanced_0 = _state_0["advanced"];
  const _checkpoints_0 = _state_0["checkpoints"];
  return $driver$058duplicate_result$({$: "driver.Owners", "factory": _factory_0, "work": _work_0, "retry": _retry_0, "advanced": _advanced_0, "checkpoints": _checkpoints_0}, ($declarations$058duplicate$(_world_0)));
}

function $driver$058step_work$(_state_0) {
  const _factory_0 = _state_0["factory"];
  const _world_0 = _state_0["world"];
  const _work_0 = _state_0["work"];
  const _retry_0 = _state_0["retry"];
  const _advanced_0 = _state_0["advanced"];
  const _checkpoints_0 = _state_0["checkpoints"];
  return $driver$058step_work_result$(_factory_0, _retry_0, _advanced_0, _checkpoints_0, ($$$$047$$$047src$047ecs$047system$058run$1260$(_work_0, _world_0, {$: "Unit"})));
}

function $driver$058change$1260$(_state_0) {
  const _factory_0 = _state_0["factory"];
  const _world_0 = _state_0["world"];
  const _work_0 = _state_0["work"];
  const _retry_0 = _state_0["retry"];
  const _advanced_0 = _state_0["advanced"];
  const _checkpoints_0 = _state_0["checkpoints"];
  return {$: "driver.State", "factory": _factory_0, "world": run_loop($scenario$045ops$058barrier$(_world_0)), "work": _work_0, "retry": _retry_0, "advanced": _advanced_0, "checkpoints": _checkpoints_0};
}

function $driver$058change$1264$(_state_0) {
  const _factory_0 = _state_0["factory"];
  const _world_0 = _state_0["world"];
  const _work_0 = _state_0["work"];
  const _retry_0 = _state_0["retry"];
  const _advanced_0 = _state_0["advanced"];
  const _checkpoints_0 = _state_0["checkpoints"];
  return {$: "driver.State", "factory": _factory_0, "world": ($scenario$045ops$058churn$(_world_0)), "work": _work_0, "retry": _retry_0, "advanced": _advanced_0, "checkpoints": _checkpoints_0};
}

function $driver$058change$1263$(_state_0) {
  const _factory_0 = _state_0["factory"];
  const _world_0 = _state_0["world"];
  const _work_0 = _state_0["work"];
  const _retry_0 = _state_0["retry"];
  const _advanced_0 = _state_0["advanced"];
  const _checkpoints_0 = _state_0["checkpoints"];
  return {$: "driver.State", "factory": _factory_0, "world": ($scenario$045ops$058remove$(_world_0)), "work": _work_0, "retry": _retry_0, "advanced": _advanced_0, "checkpoints": _checkpoints_0};
}

function $driver$058change$1262$(_state_0) {
  const _factory_0 = _state_0["factory"];
  const _world_0 = _state_0["world"];
  const _work_0 = _state_0["work"];
  const _retry_0 = _state_0["retry"];
  const _advanced_0 = _state_0["advanced"];
  const _checkpoints_0 = _state_0["checkpoints"];
  return {$: "driver.State", "factory": _factory_0, "world": ($scenario$045ops$058insert$(_world_0)), "work": _work_0, "retry": _retry_0, "advanced": _advanced_0, "checkpoints": _checkpoints_0};
}

function $driver$058step_retry$(_state_0, _fail_0) {
  const _factory_0 = _state_0["factory"];
  const _world_0 = _state_0["world"];
  const _work_0 = _state_0["work"];
  const _retry_0 = _state_0["retry"];
  const _advanced_0 = _state_0["advanced"];
  const _checkpoints_0 = _state_0["checkpoints"];
  return $driver$058retry_named$(_factory_0, _work_0, _retry_0, _advanced_0, _checkpoints_0, _fail_0, ($$$$047$$$047src$047ecs$047world$058namespace$1260$(_world_0)));
}

function $driver$058change$1261$(_state_0) {
  const _factory_0 = _state_0["factory"];
  const _world_0 = _state_0["world"];
  const _work_0 = _state_0["work"];
  const _retry_0 = _state_0["retry"];
  const _advanced_0 = _state_0["advanced"];
  const _checkpoints_0 = _state_0["checkpoints"];
  return {$: "driver.State", "factory": _factory_0, "world": ($scenario$045ops$058seed$(_world_0)), "work": _work_0, "retry": _retry_0, "advanced": _advanced_0, "checkpoints": _checkpoints_0};
}

function $driver$058init_retry$(_factory_0, _work_0, _result_0) {
  if (_result_0.$ === "../../src/ecs/system.Registered") {
    const _world_0 = _result_0["world"];
    const _retry_0 = _result_0["registry"];
    return $driver$058init_advanced$(_factory_0, _work_0, _retry_0, ($$$$047$$$047src$047ecs$047system$058register$1260$(_world_0, "advanced-reader", {$: "Con", "head": "Stock.read", "tail": {$: "Con", "head": "Queue.optional", "tail": {$: "Con", "head": "Enabled.present", "tail": {$: "Con", "head": "Locked.absent", "tail": {$: "Con", "head": "Recipe.added", "tail": {$: "Con", "head": "Stock.changed", "tail": {$: "Nil"}}}}}}})));
  } else {
    return {$: "None"};
  }
}

function $$$$047$$$047src$047ecs$047system$058register$1261$(_world_0, _name_0, _access_0) {
  return $$$$047$$$047src$047ecs$047system$058register_namespace$1261$(($$$$047$$$047src$047ecs$047world$058namespace$1260$(_world_0)), _name_0, _access_0);
}

function $$$$047$$$047src$047ecs$047system$058register_namespace$1262$(_named_0, _name_0, _access_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return $$$$047$$$047src$047ecs$047system$058register_join$1262$(($$$$047$$$047src$047ecs$047world$058register$1260$(_world_0, _name_0, _access_0)), _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047src$047ecs$047world$058namespace$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _namespace_0};
}

function $$$$047$$$047src$047ecs$047world$058create_checked$1260$(_available_0, _namespace_0, _resource_0) {
  if (!_available_0) {
    return {$: "../../src/ecs/world.CreateRejected", "factory": {$: "../../src/ecs/world.Factory", "nextNamespace": _namespace_0}, "resource": _resource_0};
  } else {
    return {$: "../../src/ecs/world.Created", "factory": {$: "../../src/ecs/world.Factory", "nextNamespace": ((_namespace_0 + 1) >>> 0)}, "world": {$: "../../src/ecs/world.World", "namespace": _namespace_0, "nextId": 1, "highWater": 0, "live": array_new(0, false), "capacity": 1, "depth": 0, "store": ($schema$058empty_store$({$: "Unit"})), "resource": _resource_0, "events": {$: "Nil"}, "pending": {$: "Nil"}, "registrations": {$: "Nil"}, "nextSystemId": 1, "clock": 0}};
  }
}

function $List$reverse$go$($0, $1) {
  for (;;) {
    {
      const _xs_0 = $0;
      const _acc_0 = $1;
      if (_xs_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _h_0 = _xs_0["head"];
        const _t_0 = _xs_0["tail"];
        $0 = _t_0;
        $1 = {$: "Con", "head": _h_0, "tail": _acc_0};
        continue;
      }
    }
  }
}

function $driver$058advanced_cursor$(_factory_0, _work_0, _retry_0, _advanced_0, _checkpoints_0, _label_0, _world_0) {
  const _namespace_0 = _advanced_0["namespace"];
  const _id_0 = _advanced_0["id"];
  const _name_0 = _advanced_0["name"];
  const _access_0 = _advanced_0["access"];
  const _cursor_0 = _advanced_0["cursor"];
  return $driver$058advanced_result$(_factory_0, _work_0, _retry_0, _checkpoints_0, _label_0, ($$$$047$$$047src$047ecs$047system$058run_tracked$1260$({$: "../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, _world_0, _cursor_0)));
}

function $scenario$045ops$058barrier$(_world_0) {
  return $$$$047$$$047src$047ecs$047world$058barrier$1260$(_world_0);
}

function $scenario$045ops$058advanced_replace$(_world_0) {
  return $scenario$045ops$058advanced_replace_namespace$(($$$$047$$$047src$047ecs$047world$058namespace$1260$(_world_0)));
}

function $driver$058record_rows$(_owners_0, _label_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _rows_0 = _observed_0["snd"];
  return $driver$058record_composed$(_owners_0, _label_0, _rows_0, ($declarations$058composed$(_world_0)));
}

function $observe$058all$(_world_0) {
  return $observe$058all_join$(($$$$047$$$047src$047ecs$047world$058handles$1260$(_world_0)));
}

function $driver$058duplicate_result$(_owners_0, _result_0) {
  const _factory_0 = _owners_0["factory"];
  const _work_0 = _owners_0["work"];
  const _retry_0 = _owners_0["retry"];
  const _advanced_0 = _owners_0["advanced"];
  const _checkpoints_0 = _owners_0["checkpoints"];
  const _world_0 = _result_0["world"];
  const _values_0 = _result_0["values"];
  return {$: "driver.State", "factory": _factory_0, "world": _world_0, "work": _work_0, "retry": _retry_0, "advanced": _advanced_0, "checkpoints": {$: "Con", "head": ($driver$058first_nonempty$(_values_0)), "tail": _checkpoints_0}};
}

function $declarations$058duplicate$(_world_0) {
  return $$$$047$$$047src$047ecs$047owned$045optimized$045compose$058each_fields$1264$({$: "Unit"}, _world_0);
}

function $driver$058step_work_result$(_factory_0, _retry_0, _advanced_0, _checkpoints_0, _result_0) {
  if (_result_0.$ === "../../src/ecs/system.Completed") {
    const _work_0 = _result_0["registry"];
    const _t_0 = _result_0["outcome"];
    if (_t_0.$ === "../../src/ecs/system.Succeeded") {
      const _world_0 = _t_0["world"];
      return {$: "driver.State", "factory": _factory_0, "world": _world_0, "work": _work_0, "retry": _retry_0, "advanced": _advanced_0, "checkpoints": _checkpoints_0};
    } else {
      const _world_1 = _t_0["world"];
      const _error_0 = _t_0["error"];
      const _x_0 = ($json$058quoted$(_error_0));
      const _x_1 = (_x_0 + "}");
      return {$: "driver.State", "factory": _factory_0, "world": _world_1, "work": _work_0, "retry": _retry_0, "advanced": _advanced_0, "checkpoints": {$: "Con", "head": ("{\"unexpectedWorkError\":" + _x_1), "tail": _checkpoints_0}};
    }
  } else {
    const _work_1 = _result_0["registry"];
    const _world_2 = _result_0["world"];
    return {$: "driver.State", "factory": _factory_0, "world": _world_2, "work": _work_1, "retry": _retry_0, "advanced": _advanced_0, "checkpoints": {$: "Con", "head": "{\"unexpectedRegistrationRefusal\":true}", "tail": _checkpoints_0}};
  }
}

function $$$$047$$$047src$047ecs$047system$058run$1260$(_registry_0, _world_0, _args_0) {
  return $$$$047$$$047src$047ecs$047system$058run_namespace$1260$(_registry_0, ($$$$047$$$047src$047ecs$047world$058namespace$1260$(_world_0)), _args_0);
}

function $scenario$045ops$058churn$(_world_0) {
  return $scenario$045ops$058churn_namespace$(($$$$047$$$047src$047ecs$047world$058namespace$1260$(_world_0)));
}

function $scenario$045ops$058remove$(_world_0) {
  return $scenario$045ops$058remove_namespace$(($$$$047$$$047src$047ecs$047world$058namespace$1260$(_world_0)));
}

function $scenario$045ops$058insert$(_world_0) {
  return $scenario$045ops$058insert_namespace$(($$$$047$$$047src$047ecs$047world$058namespace$1260$(_world_0)));
}

function $driver$058retry_named$(_factory_0, _work_0, _retry_0, _advanced_0, _checkpoints_0, _fail_0, _named_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return $driver$058step_retry_result$(_factory_0, _work_0, _advanced_0, _checkpoints_0, ($$$$047$$$047src$047ecs$047system$058run$1261$(_retry_0, _world_0, {$: "gameplay.RetryArgs", "fail": _fail_0, "target": {$: "../../src/ecs/world.Handle", "namespace": _namespace_0, "id": 2}})));
}

function $scenario$045ops$058seed$(_world_0) {
  return $scenario$045ops$058commit$(($scenario$045ops$058spawn$(($scenario$045ops$058spawn$(($scenario$045ops$058spawn$(($scenario$045ops$058spawn$(($scenario$045ops$058spawn$(($scenario$045ops$058spawn$(($$$$047$$$047src$047ecs$047transaction$058begin$1261$(_world_0)), ($schema$058seed_1$()))), ($schema$058seed_2$()))), ($schema$058seed_3$()))), ($schema$058seed_4$()))), ($schema$058seed_5$()))), ($schema$058seed_6$()))));
}

function $driver$058init_advanced$(_factory_0, _work_0, _retry_0, _result_0) {
  if (_result_0.$ === "../../src/ecs/system.Registered") {
    const _world_0 = _result_0["world"];
    const _advanced_0 = _result_0["registry"];
    return {$: "Some", "value": {$: "driver.State", "factory": _factory_0, "world": _world_0, "work": _work_0, "retry": _retry_0, "advanced": _advanced_0, "checkpoints": {$: "Nil"}}};
  } else {
    return {$: "None"};
  }
}

function $$$$047$$$047src$047ecs$047system$058register$1260$(_world_0, _name_0, _access_0) {
  return $$$$047$$$047src$047ecs$047system$058register_namespace$1260$(($$$$047$$$047src$047ecs$047world$058namespace$1260$(_world_0)), _name_0, _access_0);
}

function $$$$047$$$047src$047ecs$047system$058register_namespace$1261$(_named_0, _name_0, _access_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return $$$$047$$$047src$047ecs$047system$058register_join$1261$(($$$$047$$$047src$047ecs$047world$058register$1260$(_world_0, _name_0, _access_0)), _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047src$047ecs$047system$058register_join$1262$(_registered_0, _namespace_0, _name_0, _access_0) {
  const _world_0 = _registered_0["fst"];
  const _result_0 = _registered_0["snd"];
  return $$$$047$$$047src$047ecs$047system$058register_meta$1262$(_world_0, _result_0, _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047src$047ecs$047world$058register$1260$(_world_0, _name_0, _access_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047src$047ecs$047world$058register_checked$1260$((_nextSystemId_0 < 4294967295), {$: "../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, _name_0, _access_0);
}

function $schema$058empty_store$(_unit_0) {
  return {$: "schema.Store", "stock": ($$$$047$$$047src$047ecs$047column$058empty_indexed$1260$()), "recipe": ($$$$047$$$047src$047ecs$047column$058empty_indexed$1261$()), "queue": ($$$$047$$$047src$047ecs$047column$058empty_indexed$1262$()), "enabled": ($$$$047$$$047src$047ecs$047column$058empty_indexed$1263$()), "locked": ($$$$047$$$047src$047ecs$047column$058empty_indexed$1264$())};
}

function $driver$058advanced_result$(_factory_0, _work_0, _retry_0, _checkpoints_0, _label_0, _result_0) {
  if (_result_0.$ === "../../src/ecs/system.Completed") {
    const _advanced_0 = _result_0["registry"];
    const _t_0 = _result_0["outcome"];
    if (_t_0.$ === "../../src/ecs/system.Succeeded") {
      const _world_0 = _t_0["world"];
      const _ids_0 = _t_0["output"];
      const _x_0 = ($json$058numbers$(_ids_0));
      const _x_1 = (_x_0 + "}");
      const _x_2 = ($json$058quoted$(_label_0));
      const _x_3 = (",\"ids\":" + _x_1);
      const _x_4 = (_x_2 + _x_3);
      return {$: "driver.State", "factory": _factory_0, "world": _world_0, "work": _work_0, "retry": _retry_0, "advanced": _advanced_0, "checkpoints": {$: "Con", "head": ("{\"label\":" + _x_4), "tail": _checkpoints_0}};
    } else {
      const _world_1 = _t_0["world"];
      const _error_0 = _t_0["error"];
      const _x_5 = ($json$058quoted$(_error_0));
      const _x_6 = (_x_5 + "}");
      const _x_7 = ($json$058quoted$(_label_0));
      const _x_8 = (",\"error\":" + _x_6);
      const _x_9 = (_x_7 + _x_8);
      return {$: "driver.State", "factory": _factory_0, "world": _world_1, "work": _work_0, "retry": _retry_0, "advanced": _advanced_0, "checkpoints": {$: "Con", "head": ("{\"label\":" + _x_9), "tail": _checkpoints_0}};
    }
  } else {
    const _advanced_1 = _result_0["registry"];
    const _world_2 = _result_0["world"];
    return {$: "driver.State", "factory": _factory_0, "world": _world_2, "work": _work_0, "retry": _retry_0, "advanced": _advanced_1, "checkpoints": {$: "Con", "head": "{\"unexpectedAdvancedRefusal\":true}", "tail": _checkpoints_0}};
  }
}

function $$$$047$$$047src$047ecs$047system$058run_tracked$1260$(_registry_0, _world_0, _args_0) {
  return $$$$047$$$047src$047ecs$047system$058tracked_result$1260$(($$$$047$$$047src$047ecs$047system$058run$1262$(_registry_0, _world_0, _args_0)));
}

function $$$$047$$$047src$047ecs$047world$058barrier$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047src$047ecs$047world$058drain_fifo$1260$(_pending_0, {$: "../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": {$: "Nil"}, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0});
}

function $scenario$045ops$058advanced_replace_namespace$(_named_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return $scenario$045ops$058commit$(($schema$058queue_stock$(($schema$058queue_recipe$(($$$$047$$$047src$047ecs$047transaction$058begin$1261$(_world_0)), ($scenario$045ops$058handle$(_namespace_0, 3)), {$: "Some", "value": ($schema$058recipe_payload$(88))})), ($scenario$045ops$058handle$(_namespace_0, 3)), {$: "Some", "value": ($schema$058stock_payload$(89))})));
}

function $driver$058record_composed$(_owners_0, _label_0, _rows_0, _result_0) {
  const _world_0 = _result_0["world"];
  const _composed_0 = _result_0["values"];
  return $driver$058record_empty$(_owners_0, _label_0, _rows_0, _composed_0, ($declarations$058empty$(_world_0)));
}

function $declarations$058composed$(_world_0) {
  return $$$$047$$$047src$047ecs$047owned$045optimized$045compose$058each_fields$1261$({$: "Unit"}, _world_0);
}

function $observe$058all_join$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  const _handles_0 = _observed_0["snd"];
  return $observe$058rows$(_handles_0, {$: "Tuple", "fst": _world_0, "snd": {$: "Nil"}});
}

function $$$$047$$$047src$047ecs$047world$058handles$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047src$047ecs$047world$058handles_finish$1260$(($$$$047$$$047src$047ecs$047world$058collect_live$1260$(_highWater_0, _namespace_0, _live_0)), _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $driver$058first_nonempty$(_values_0) {
  if (_values_0.$ === "Nil") {
    return "{\"unexpectedDuplicateEmpty\":true}";
  } else {
    const _value_0 = _values_0["head"];
    return _value_0;
  }
}

function $$$$047$$$047src$047ecs$047owned$045optimized$045compose$058each_fields$1264$(_args_0, _world_0) {
  return $$$$047$$$047src$047ecs$047optimized$045compose$058recovered$1264$(($$$$047$$$047src$047ecs$047owned$045compose$058each_fields$1264$(_args_0, ($$$$047$$$047src$047ecs$047optimized$045compose$058map_store$1266$(_world_0)))));
}

function $json$058quoted$(_s_0) {
  const _x_0 = (_s_0 + "\"");
  return ("\"" + _x_0);
}

function $$$$047$$$047src$047ecs$047system$058run_namespace$1260$(_registry_0, _named_0, _args_0) {
  const _world_0 = _named_0["fst"];
  const _actual_0 = _named_0["snd"];
  return $$$$047$$$047src$047ecs$047system$058run_namespace_value$1260$(_registry_0, _world_0, _actual_0, _args_0);
}

function $scenario$045ops$058churn_namespace$(_named_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return $scenario$045ops$058commit$(($schema$058queue_recipe$(($scenario$045ops$058spawn$(($scenario$045ops$058despawn_join$(($$$$047$$$047src$047ecs$047commands$058tx_despawn_with$1260$(($$$$047$$$047src$047ecs$047transaction$058begin$1261$(_world_0)), ($scenario$045ops$058handle$(_namespace_0, 2)))))), ($schema$058churn_bundle$()))), ($scenario$045ops$058handle$(_namespace_0, 1)), {$: "Some", "value": ($schema$058recipe_payload$(27))})));
}

function $scenario$045ops$058remove_namespace$(_named_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return $scenario$045ops$058commit$(($schema$058queue_recipe$(($schema$058queue_locked$(($$$$047$$$047src$047ecs$047transaction$058begin$1261$(_world_0)), ($scenario$045ops$058handle$(_namespace_0, 4)), {$: "None"})), ($scenario$045ops$058handle$(_namespace_0, 1)), {$: "None"})));
}

function $scenario$045ops$058insert_namespace$(_named_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return $scenario$045ops$058commit$(($schema$058queue_enabled$(($schema$058queue_recipe$(($$$$047$$$047src$047ecs$047transaction$058begin$1261$(_world_0)), ($scenario$045ops$058handle$(_namespace_0, 3)), {$: "Some", "value": ($schema$058recipe_payload$(22))})), ($scenario$045ops$058handle$(_namespace_0, 5)), {$: "Some", "value": {$: "schema.Enabled"}})));
}

function $driver$058step_retry_result$(_factory_0, _work_0, _advanced_0, _checkpoints_0, _result_0) {
  if (_result_0.$ === "../../src/ecs/system.Completed") {
    const _retry_0 = _result_0["registry"];
    const _t_0 = _result_0["outcome"];
    if (_t_0.$ === "../../src/ecs/system.Succeeded") {
      const _world_0 = _t_0["world"];
      return {$: "driver.State", "factory": _factory_0, "world": _world_0, "work": _work_0, "retry": _retry_0, "advanced": _advanced_0, "checkpoints": _checkpoints_0};
    } else {
      const _world_1 = _t_0["world"];
      const _error_0 = _t_0["error"];
      const _x_0 = ($json$058quoted$(_error_0));
      const _x_1 = (_x_0 + "}}");
      return {$: "driver.State", "factory": _factory_0, "world": _world_1, "work": _work_0, "retry": _retry_0, "advanced": _advanced_0, "checkpoints": {$: "Con", "head": ("{\"label\":\"failed-result\",\"ok\":false,\"error\":{\"kind\":\"SystemFailure\",\"system\":\"retry\",\"error\":" + _x_1), "tail": _checkpoints_0}};
    }
  } else {
    const _retry_1 = _result_0["registry"];
    const _world_2 = _result_0["world"];
    return {$: "driver.State", "factory": _factory_0, "world": _world_2, "work": _work_0, "retry": _retry_1, "advanced": _advanced_0, "checkpoints": {$: "Con", "head": "{\"unexpectedRegistrationRefusal\":true}", "tail": _checkpoints_0}};
  }
}

function $$$$047$$$047src$047ecs$047system$058run$1261$(_registry_0, _world_0, _args_0) {
  return $$$$047$$$047src$047ecs$047system$058run_namespace$1261$(_registry_0, ($$$$047$$$047src$047ecs$047world$058namespace$1260$(_world_0)), _args_0);
}

function $scenario$045ops$058commit$(_tx_0) {
  return $scenario$045ops$058commit_result$(($$$$047$$$047src$047ecs$047commands$058tx_finish$1261$(_tx_0, {$: "../../src/ecs/transaction.Success"})));
}

function $scenario$045ops$058spawn$(_tx_0, _bundle_0) {
  return $scenario$045ops$058spawned$(($$$$047$$$047src$047ecs$047commands$058tx_spawn$1260$(_tx_0, _bundle_0)));
}

function $$$$047$$$047src$047ecs$047transaction$058begin$1261$(_world_0) {
  return {$: "../../src/ecs/transaction.Tx", "world": _world_0, "undo": {$: "Nil"}, "commands": {$: "Nil"}, "events": {$: "Nil"}};
}

function $schema$058seed_1$() {
  return {$: "schema.Bundle", "stock": {$: "Some", "value": ($schema$058stock_payload$(10))}, "recipe": {$: "Some", "value": ($schema$058recipe_payload$(20))}, "queue": {$: "Some", "value": ($schema$058queue_payload$(30))}, "enabled": {$: "Some", "value": {$: "schema.Enabled"}}, "locked": {$: "None"}};
}

function $schema$058seed_2$() {
  return {$: "schema.Bundle", "stock": {$: "Some", "value": ($schema$058stock_payload$(11))}, "recipe": {$: "Some", "value": ($schema$058recipe_payload$(21))}, "queue": {$: "None"}, "enabled": {$: "Some", "value": {$: "schema.Enabled"}}, "locked": {$: "None"}};
}

function $schema$058seed_3$() {
  return {$: "schema.Bundle", "stock": {$: "Some", "value": ($schema$058stock_payload$(12))}, "recipe": {$: "None"}, "queue": {$: "Some", "value": ($schema$058queue_payload$(32))}, "enabled": {$: "Some", "value": {$: "schema.Enabled"}}, "locked": {$: "None"}};
}

function $schema$058seed_4$() {
  return {$: "schema.Bundle", "stock": {$: "Some", "value": ($schema$058stock_payload$(13))}, "recipe": {$: "Some", "value": ($schema$058recipe_payload$(23))}, "queue": {$: "Some", "value": ($schema$058queue_payload$(33))}, "enabled": {$: "Some", "value": {$: "schema.Enabled"}}, "locked": {$: "Some", "value": {$: "schema.Locked"}}};
}

function $schema$058seed_5$() {
  return {$: "schema.Bundle", "stock": {$: "Some", "value": ($schema$058stock_payload$(14))}, "recipe": {$: "Some", "value": ($schema$058recipe_payload$(24))}, "queue": {$: "Some", "value": ($schema$058queue_payload$(34))}, "enabled": {$: "None"}, "locked": {$: "None"}};
}

function $schema$058seed_6$() {
  return {$: "schema.Bundle", "stock": {$: "None"}, "recipe": {$: "None"}, "queue": {$: "None"}, "enabled": {$: "None"}, "locked": {$: "None"}};
}

function $$$$047$$$047src$047ecs$047system$058register_namespace$1260$(_named_0, _name_0, _access_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return $$$$047$$$047src$047ecs$047system$058register_join$1260$(($$$$047$$$047src$047ecs$047world$058register$1260$(_world_0, _name_0, _access_0)), _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047src$047ecs$047system$058register_join$1261$(_registered_0, _namespace_0, _name_0, _access_0) {
  const _world_0 = _registered_0["fst"];
  const _result_0 = _registered_0["snd"];
  return $$$$047$$$047src$047ecs$047system$058register_meta$1261$(_world_0, _result_0, _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047src$047ecs$047system$058register_meta$1262$(_world_0, _result_0, _namespace_0, _name_0, _access_0) {
  if (_result_0.$ === "../../src/ecs/world.RegistrationRejected") {
    return {$: "../../src/ecs/system.RegistrationFailed", "world": _world_0};
  } else {
    const _id_0 = _result_0["id"];
    return {$: "../../src/ecs/system.Registered", "world": _world_0, "registry": {$: "../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": 0}};
  }
}

function $$$$047$$$047src$047ecs$047world$058register_checked$1260$(_available_0, _world_0, _name_0, _access_0) {
  if (!_available_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../src/ecs/world.RegistrationRejected", "error": {$: "../../src/ecs/world.SystemIdExhausted"}}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    return {$: "Tuple", "fst": {$: "../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": {$: "Con", "head": {$: "../../src/ecs/world.RegistrationMeta", "id": _nextSystemId_0, "name": _name_0, "access": _access_0}, "tail": _registrations_0}, "nextSystemId": ((_nextSystemId_0 + 1) >>> 0), "clock": _clock_0}, "snd": {$: "../../src/ecs/world.Registered", "id": _nextSystemId_0}};
  }
}

function $$$$047$$$047src$047ecs$047column$058empty_indexed$1260$() {
  return $$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$([{$: "None"}], ($$$$047$$$047src$047ecs$047indexed$045lifecycle$058empty$()));
}

function $$$$047$$$047src$047ecs$047column$058empty_indexed$1261$() {
  return $$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$([{$: "None"}], ($$$$047$$$047src$047ecs$047indexed$045lifecycle$058empty$()));
}

function $$$$047$$$047src$047ecs$047column$058empty_indexed$1262$() {
  return $$$$047$$$047src$047ecs$047column$058indexed_wrap$1262$([{$: "None"}], ($$$$047$$$047src$047ecs$047indexed$045lifecycle$058empty$()));
}

function $$$$047$$$047src$047ecs$047column$058empty_indexed$1263$() {
  return $$$$047$$$047src$047ecs$047column$058indexed_wrap$1263$([{$: "None"}], ($$$$047$$$047src$047ecs$047indexed$045lifecycle$058empty$()));
}

function $$$$047$$$047src$047ecs$047column$058empty_indexed$1264$() {
  return $$$$047$$$047src$047ecs$047column$058indexed_wrap$1264$([{$: "None"}], ($$$$047$$$047src$047ecs$047indexed$045lifecycle$058empty$()));
}

function $json$058numbers$(_xs_0) {
  return $List$show$1260$(_xs_0);
}

function $$$$047$$$047src$047ecs$047system$058tracked_result$1260$(_result_0) {
  if (_result_0.$ === "../../src/ecs/system.RegistrationRejected") {
    const _registry_0 = _result_0["registry"];
    const _world_0 = _result_0["world"];
    const _args_0 = _result_0["args"];
    return {$: "../../src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _registry_1 = _result_0["registry"];
    const _outcome_0 = _result_0["outcome"];
    return $$$$047$$$047src$047ecs$047system$058tracked_outcome$1260$(_registry_1, _outcome_0);
  }
}

function $$$$047$$$047src$047ecs$047system$058run$1262$(_registry_0, _world_0, _args_0) {
  return $$$$047$$$047src$047ecs$047system$058run_namespace$1262$(_registry_0, ($$$$047$$$047src$047ecs$047world$058namespace$1260$(_world_0)), _args_0);
}

function $$$$047$$$047src$047ecs$047world$058drain_fifo$1260$(_commands_0, _world_0) {
  if (_commands_0.$ === "Nil") {
    return _world_0;
  } else {
    const _command_0 = _commands_0["head"];
    const _rest_0 = _commands_0["tail"];
    return run_tail(_command_0, run_loop($$$$047$$$047src$047ecs$047world$058drain_fifo$1260$(_rest_0, _world_0)));
  }
}

function $schema$058queue_stock$(_tx_0, _handle_0, _incoming_0) {
  return $schema$058queued$1260$(($$$$047$$$047src$047ecs$047structural$058tx_replace$1260$(($schema$058stock$()), _tx_0, _handle_0, _incoming_0)));
}

function $schema$058queue_recipe$(_tx_0, _handle_0, _incoming_0) {
  return $schema$058queued$1261$(($$$$047$$$047src$047ecs$047structural$058tx_replace$1261$(($schema$058recipe$()), _tx_0, _handle_0, _incoming_0)));
}

function $scenario$045ops$058handle$(_namespace_0, _id_0) {
  return {$: "../../src/ecs/world.Handle", "namespace": _namespace_0, "id": _id_0};
}

function $schema$058recipe_payload$(_value_0) {
  return {$: "schema.Recipe", "value": _value_0, "owned": ($schema$058payload_array$({$: "Con", "head": _value_0, "tail": {$: "Con", "head": ((_value_0 + 1) >>> 0), "tail": {$: "Con", "head": ((_value_0 + 2) >>> 0), "tail": {$: "Nil"}}}})), "length": 3};
}

function $schema$058stock_payload$(_value_0) {
  return {$: "schema.Stock", "value": _value_0, "owned": ($schema$058payload_array$({$: "Con", "head": _value_0, "tail": {$: "Con", "head": ((_value_0 + 1) >>> 0), "tail": {$: "Con", "head": ((_value_0 + 2) >>> 0), "tail": {$: "Nil"}}}})), "length": 3};
}

function $driver$058record_empty$(_owners_0, _label_0, _rows_0, _composed_0, _result_0) {
  const _world_0 = _result_0["world"];
  const _empty_0 = _result_0["values"];
  return $driver$058record_finish$(_owners_0, _label_0, _rows_0, _composed_0, _empty_0, ($declarations$058contradictory$(_world_0)));
}

function $declarations$058empty$(_world_0) {
  return $$$$047$$$047src$047ecs$047owned$045optimized$045compose$058each_fields$1262$({$: "Unit"}, _world_0);
}

function $$$$047$$$047src$047ecs$047owned$045optimized$045compose$058each_fields$1261$(_args_0, _world_0) {
  return $$$$047$$$047src$047ecs$047optimized$045compose$058recovered$1261$(($$$$047$$$047src$047ecs$047owned$045compose$058each_fields$1261$(_args_0, ($$$$047$$$047src$047ecs$047optimized$045compose$058map_store$1261$(_world_0)))));
}

function $observe$058rows$($0, $1) {
  for (;;) {
    {
      const _handles_0 = $0;
      const _observed_0 = $1;
      if (_handles_0.$ === "Nil") {
        const _world_0 = _observed_0["fst"];
        const _prior_0 = _observed_0["snd"];
        return {$: "Tuple", "fst": _world_0, "snd": ($List$reverse$(_prior_0))};
      } else {
        const _handle_0 = _handles_0["head"];
        const _rest_0 = _handles_0["tail"];
        const _world_1 = _observed_0["fst"];
        const _prior_1 = _observed_0["snd"];
        $0 = _rest_0;
        $1 = ($observe$058row_accumulate$(_prior_1, ($observe$058row$(_world_1, _handle_0))));
        continue;
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047world$058handles_finish$1260$(_scanned_0, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _scanned_0["live"];
  const _handles_0 = _scanned_0["handles"];
  return {$: "Tuple", "fst": {$: "../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": ($List$reverse$(_handles_0))};
}

function $$$$047$$$047src$047ecs$047world$058collect_live$1260$(_remaining_0, _namespace_0, _live_0) {
  if (_remaining_0 === 0) {
    return {$: "../../src/ecs/world.HandleScan", "live": _live_0, "handles": {$: "Nil"}};
  } else {
    const _rest_0 = (_remaining_0 - 1);
    const _x_0 = nat_chk(_rest_0 + 1);
    return $$$$047$$$047src$047ecs$047world$058collect_join$1260$(($$$$047$$$047src$047ecs$047world$058collect_live$1260$(_rest_0, _namespace_0, _live_0)), _namespace_0, (_x_0 >>> 0));
  }
}

function $$$$047$$$047src$047ecs$047optimized$045compose$058recovered$1264$(_result_0) {
  const _world_0 = _result_0["world"];
  const _outcome_0 = _result_0["outcome"];
  const _values_0 = _result_0["values"];
  return {$: "../../src/ecs/compose.Executed", "world": ($$$$047$$$047src$047ecs$047optimized$045compose$058map_store$1265$(_world_0)), "outcome": _outcome_0, "values": _values_0};
}

function $$$$047$$$047src$047ecs$047owned$045compose$058each_fields$1264$(_args_0, _world_0) {
  return $$$$047$$$047src$047ecs$047owned$045compose$058reserved_fields$1264$(_args_0, 0, ($$$$047$$$047src$047ecs$047world$058handles$1260$(_world_0)));
}

function $$$$047$$$047src$047ecs$047optimized$045compose$058map_store$1266$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": ($schema$058prepare_stock$(_store_0)), "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $$$$047$$$047src$047ecs$047system$058run_namespace_value$1260$(_registry_0, _world_0, _actual_0, _args_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return $$$$047$$$047src$047ecs$047system$058run_namespace_checked$1260$((_namespace_0 === _actual_0), {$: "../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, _world_0, _args_0);
}

function $scenario$045ops$058despawn_join$(_observed_0) {
  const _tx_0 = _observed_0["fst"];
  return _tx_0;
}

function $$$$047$$$047src$047ecs$047commands$058tx_despawn_with$1260$(_tx_0, _handle_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047src$047ecs$047commands$058despawn_join_with$1260$(($$$$047$$$047src$047ecs$047world$058valid$1260$(_world_0, _handle_0)), _undo_0, _commands_0, _events_0, _handle_0);
}

function $schema$058churn_bundle$() {
  return {$: "schema.Bundle", "stock": {$: "Some", "value": ($schema$058stock_payload$(16))}, "recipe": {$: "Some", "value": ($schema$058recipe_payload$(26))}, "queue": {$: "None"}, "enabled": {$: "Some", "value": {$: "schema.Enabled"}}, "locked": {$: "None"}};
}

function $schema$058queue_locked$(_tx_0, _handle_0, _incoming_0) {
  return $schema$058queued$1264$(($$$$047$$$047src$047ecs$047structural$058tx_replace$1264$(($schema$058locked$()), _tx_0, _handle_0, _incoming_0)));
}

function $schema$058queue_enabled$(_tx_0, _handle_0, _incoming_0) {
  return $schema$058queued$1263$(($$$$047$$$047src$047ecs$047structural$058tx_replace$1263$(($schema$058enabled$()), _tx_0, _handle_0, _incoming_0)));
}

function $$$$047$$$047src$047ecs$047system$058run_namespace$1261$(_registry_0, _named_0, _args_0) {
  const _world_0 = _named_0["fst"];
  const _actual_0 = _named_0["snd"];
  return $$$$047$$$047src$047ecs$047system$058run_namespace_value$1261$(_registry_0, _world_0, _actual_0, _args_0);
}

function $scenario$045ops$058commit_result$(_result_0) {
  const _world_0 = _result_0["world"];
  return _world_0;
}

function $$$$047$$$047src$047ecs$047commands$058tx_finish$1261$(_tx_0, _outcome_0) {
  return $$$$047$$$047src$047ecs$047transaction$058finish$1261$(_tx_0, _outcome_0);
}

function $scenario$045ops$058spawned$(_result_0) {
  const _tx_0 = _result_0["fst"];
  return _tx_0;
}

function $$$$047$$$047src$047ecs$047commands$058tx_spawn$1260$(_tx_0, _payload_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047src$047ecs$047commands$058spawn_join$1260$(($$$$047$$$047src$047ecs$047world$058reserve_id$1260$(_world_0)), _undo_0, _commands_0, _events_0, _payload_0);
}

function $schema$058queue_payload$(_value_0) {
  return {$: "schema.Queue", "value": _value_0, "owned": ($schema$058payload_array$({$: "Con", "head": _value_0, "tail": {$: "Con", "head": ((_value_0 + 1) >>> 0), "tail": {$: "Con", "head": ((_value_0 + 2) >>> 0), "tail": {$: "Nil"}}}})), "length": 3};
}

function $$$$047$$$047src$047ecs$047system$058register_join$1260$(_registered_0, _namespace_0, _name_0, _access_0) {
  const _world_0 = _registered_0["fst"];
  const _result_0 = _registered_0["snd"];
  return $$$$047$$$047src$047ecs$047system$058register_meta$1260$(_world_0, _result_0, _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047src$047ecs$047system$058register_meta$1261$(_world_0, _result_0, _namespace_0, _name_0, _access_0) {
  if (_result_0.$ === "../../src/ecs/world.RegistrationRejected") {
    return {$: "../../src/ecs/system.RegistrationFailed", "world": _world_0};
  } else {
    const _id_0 = _result_0["id"];
    return {$: "../../src/ecs/system.Registered", "world": _world_0, "registry": {$: "../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": 0}};
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0) {
  return {$: "../../src/ecs/column.Indexed", "state": {$: "../../src/ecs/column.IndexedOrdinaryOwned", "state": {$: "../../src/ecs/column.IndexedOrdinaryState", "values": _values_0, "metadata": _metadata_0}}};
}

function $$$$047$$$047src$047ecs$047indexed$045lifecycle$058empty$() {
  return {$: "../../src/ecs/indexed-lifecycle.Metadata", "added": [0], "changed": [0], "capacity": 1, "depth": 0, "exceptional": {$: "Nil"}};
}

function $$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0) {
  return {$: "../../src/ecs/column.Indexed", "state": {$: "../../src/ecs/column.IndexedOrdinaryOwned", "state": {$: "../../src/ecs/column.IndexedOrdinaryState", "values": _values_0, "metadata": _metadata_0}}};
}

function $$$$047$$$047src$047ecs$047column$058indexed_wrap$1262$(_values_0, _metadata_0) {
  return {$: "../../src/ecs/column.Indexed", "state": {$: "../../src/ecs/column.IndexedOrdinaryOwned", "state": {$: "../../src/ecs/column.IndexedOrdinaryState", "values": _values_0, "metadata": _metadata_0}}};
}

function $$$$047$$$047src$047ecs$047column$058indexed_wrap$1263$(_values_0, _metadata_0) {
  return {$: "../../src/ecs/column.Indexed", "state": {$: "../../src/ecs/column.IndexedOrdinaryOwned", "state": {$: "../../src/ecs/column.IndexedOrdinaryState", "values": _values_0, "metadata": _metadata_0}}};
}

function $$$$047$$$047src$047ecs$047column$058indexed_wrap$1264$(_values_0, _metadata_0) {
  return {$: "../../src/ecs/column.Indexed", "state": {$: "../../src/ecs/column.IndexedOrdinaryOwned", "state": {$: "../../src/ecs/column.IndexedOrdinaryState", "values": _values_0, "metadata": _metadata_0}}};
}

function $List$show$1260$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($U32$show$(_h_0));
    const _x_1 = ($List$show$go$1260$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $$$$047$$$047src$047ecs$047system$058tracked_outcome$1260$(_registry_0, _outcome_0) {
  if (_outcome_0.$ === "../../src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../src/ecs/system.Completed", "registry": _registry_0, "outcome": {$: "../../src/ecs/system.Failed", "world": _world_0, "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    return $$$$047$$$047src$047ecs$047system$058tracked_clock$1260$(_registry_0, _output_0, ($$$$047$$$047src$047ecs$047world$058clock$1260$(_world_1)));
  }
}

function $$$$047$$$047src$047ecs$047system$058run_namespace$1262$(_registry_0, _named_0, _args_0) {
  const _world_0 = _named_0["fst"];
  const _actual_0 = _named_0["snd"];
  return $$$$047$$$047src$047ecs$047system$058run_namespace_value$1262$(_registry_0, _world_0, _actual_0, _args_0);
}

function $schema$058queued$1260$(_result_0) {
  if (_result_0.$ === "../../src/ecs/structural.Queued") {
    const _tx_0 = _result_0["tx"];
    return _tx_0;
  } else {
    const _tx_1 = _result_0["tx"];
    return _tx_1;
  }
}

function $$$$047$$$047src$047ecs$047structural$058tx_replace$1260$(_family_0, _tx_0, _handle_0, _incoming_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047src$047ecs$047structural$058queue_join$1260$(_family_0, ($$$$047$$$047src$047ecs$047world$058valid$1260$(_world_0, _handle_0)), _undo_0, _commands_0, _events_0, _handle_0, _incoming_0);
}

function $schema$058stock$() {
  return $$$$047$$$047src$047ecs$047component$058define$1260$("Stock");
}

function $schema$058queued$1261$(_result_0) {
  if (_result_0.$ === "../../src/ecs/structural.Queued") {
    const _tx_0 = _result_0["tx"];
    return _tx_0;
  } else {
    const _tx_1 = _result_0["tx"];
    return _tx_1;
  }
}

function $$$$047$$$047src$047ecs$047structural$058tx_replace$1261$(_family_0, _tx_0, _handle_0, _incoming_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047src$047ecs$047structural$058queue_join$1261$(_family_0, ($$$$047$$$047src$047ecs$047world$058valid$1260$(_world_0, _handle_0)), _undo_0, _commands_0, _events_0, _handle_0, _incoming_0);
}

function $schema$058recipe$() {
  return $$$$047$$$047src$047ecs$047component$058define$1261$("Recipe");
}

function $schema$058payload_array$(_values_0) {
  const _x_0 = ($schema$058shape_depth$(($schema$058shape$(_values_0, {$: "schema.ArrayShape", "capacity": 1, "depth": 0, "used": 0}))));
  return $schema$058fill$(_values_0, 0, array_new(_x_0, 0));
}

function $driver$058record_finish$(_owners_0, _label_0, _rows_0, _composed_0, _empty_0, _result_0) {
  const _factory_0 = _owners_0["factory"];
  const _work_0 = _owners_0["work"];
  const _retry_0 = _owners_0["retry"];
  const _advanced_0 = _owners_0["advanced"];
  const _checkpoints_0 = _owners_0["checkpoints"];
  const _world_0 = _result_0["world"];
  const _contradict_0 = _result_0["values"];
  const _x_0 = ($json$058array$(_contradict_0));
  const _x_1 = (_x_0 + "}");
  const _x_2 = ($json$058array$(_empty_0));
  const _x_3 = (",\"contradict\":" + _x_1);
  const _x_4 = (_x_2 + _x_3);
  const _x_5 = ($json$058array$(_composed_0));
  const _x_6 = (",\"empty\":" + _x_4);
  const _x_7 = (_x_5 + _x_6);
  const _x_8 = ($json$058array$(_rows_0));
  const _x_9 = (",\"composed\":" + _x_7);
  const _x_10 = (_x_8 + _x_9);
  const _x_11 = ($json$058quoted$(_label_0));
  const _x_12 = (",\"entities\":" + _x_10);
  const _x_13 = (_x_11 + _x_12);
  return {$: "driver.State", "factory": _factory_0, "world": _world_0, "work": _work_0, "retry": _retry_0, "advanced": _advanced_0, "checkpoints": {$: "Con", "head": ("{\"label\":" + _x_13), "tail": _checkpoints_0}};
}

function $declarations$058contradictory$(_world_0) {
  return $$$$047$$$047src$047ecs$047owned$045optimized$045compose$058each_fields$1263$({$: "Unit"}, _world_0);
}

function $$$$047$$$047src$047ecs$047owned$045optimized$045compose$058each_fields$1262$(_args_0, _world_0) {
  return $$$$047$$$047src$047ecs$047optimized$045compose$058recovered$1262$(($$$$047$$$047src$047ecs$047owned$045compose$058each_fields$1262$(_args_0, ($$$$047$$$047src$047ecs$047optimized$045compose$058map_store$1262$(_world_0)))));
}

function $$$$047$$$047src$047ecs$047optimized$045compose$058recovered$1261$(_result_0) {
  const _world_0 = _result_0["world"];
  const _outcome_0 = _result_0["outcome"];
  const _values_0 = _result_0["values"];
  return {$: "../../src/ecs/compose.Executed", "world": ($$$$047$$$047src$047ecs$047optimized$045compose$058map_store$1260$(_world_0)), "outcome": _outcome_0, "values": _values_0};
}

function $$$$047$$$047src$047ecs$047owned$045compose$058each_fields$1261$(_args_0, _world_0) {
  return $$$$047$$$047src$047ecs$047owned$045compose$058reserved_fields$1261$(_args_0, 0, ($$$$047$$$047src$047ecs$047world$058handles$1260$(_world_0)));
}

function $$$$047$$$047src$047ecs$047optimized$045compose$058map_store$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": ($schema$058prepare_store$(_store_0)), "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $observe$058row_accumulate$(_prior_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _head_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _world_0, "snd": {$: "Con", "head": _head_0, "tail": _prior_0}};
}

function $observe$058row$(_world_0, _handle_0) {
  return $observe$058row_stock$(_handle_0, ($schema$058get_stock$(_world_0, _handle_0)));
}

function $$$$047$$$047src$047ecs$047world$058collect_join$1260$(_scanned_0, _namespace_0, _id_0) {
  const _live_0 = _scanned_0["live"];
  const _handles_0 = _scanned_0["handles"];
  return $$$$047$$$047src$047ecs$047world$058collect_step$1260$({$: "Tuple", fst: _live_0, snd: _live_0[_id_0 % _live_0.length]}, _namespace_0, _id_0, _handles_0);
}

function $$$$047$$$047src$047ecs$047optimized$045compose$058map_store$1265$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": ($schema$058recover_stock$(_store_0)), "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $$$$047$$$047src$047ecs$047owned$045compose$058reserved_fields$1264$(_args_0, _cursor_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _handles_0 = _observed_0["snd"];
  return $$$$047$$$047src$047ecs$047owned$045compose$058finished$1261$(run_loop($$$$047$$$047src$047ecs$047owned$045compose$058run_handles_fields$1264$(_handles_0, _args_0, _cursor_0, ($$$$047$$$047src$047ecs$047transaction$058begin$1260$(_world_0)))));
}

function $schema$058prepare_stock$(_store_0) {
  const _stock_0 = _store_0["stock"];
  const _recipe_0 = _store_0["recipe"];
  const _queue_0 = _store_0["queue"];
  const _enabled_0 = _store_0["enabled"];
  const _locked_0 = _store_0["locked"];
  return {$: "schema.Store", "stock": ($$$$047$$$047src$047ecs$047column$058prepare$1260$(_stock_0)), "recipe": _recipe_0, "queue": _queue_0, "enabled": _enabled_0, "locked": _locked_0};
}

function $$$$047$$$047src$047ecs$047system$058run_namespace_checked$1260$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    const _cursor_0 = _registry_0["cursor"];
    return $$$$047$$$047src$047ecs$047system$058run_metadata$1260$({$: "../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, ($$$$047$$$047src$047ecs$047world$058registration_matches$1260$(_world_0, _id_0, _name_0, _access_0)), _args_0);
  }
}

function $$$$047$$$047src$047ecs$047commands$058despawn_join_with$1260$(_checked_0, _undo_0, _commands_0, _events_0, _handle_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047src$047ecs$047commands$058despawn_checked_with$1260$(_allowed_0, _world_0, _undo_0, _commands_0, _events_0, _handle_0);
}

function $$$$047$$$047src$047ecs$047world$058valid$1260$(_world_0, _handle_0) {
  return $$$$047$$$047src$047ecs$047world$058valid_join$1260$(_handle_0, ($$$$047$$$047src$047ecs$047world$058metadata_valid$1260$(_world_0, _handle_0)));
}

function $schema$058queued$1264$(_result_0) {
  if (_result_0.$ === "../../src/ecs/structural.Queued") {
    const _tx_0 = _result_0["tx"];
    return _tx_0;
  } else {
    const _tx_1 = _result_0["tx"];
    return _tx_1;
  }
}

function $$$$047$$$047src$047ecs$047structural$058tx_replace$1264$(_family_0, _tx_0, _handle_0, _incoming_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047src$047ecs$047structural$058queue_join$1264$(_family_0, ($$$$047$$$047src$047ecs$047world$058valid$1260$(_world_0, _handle_0)), _undo_0, _commands_0, _events_0, _handle_0, _incoming_0);
}

function $schema$058locked$() {
  return $$$$047$$$047src$047ecs$047component$058define$1264$("Locked");
}

function $schema$058queued$1263$(_result_0) {
  if (_result_0.$ === "../../src/ecs/structural.Queued") {
    const _tx_0 = _result_0["tx"];
    return _tx_0;
  } else {
    const _tx_1 = _result_0["tx"];
    return _tx_1;
  }
}

function $$$$047$$$047src$047ecs$047structural$058tx_replace$1263$(_family_0, _tx_0, _handle_0, _incoming_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047src$047ecs$047structural$058queue_join$1263$(_family_0, ($$$$047$$$047src$047ecs$047world$058valid$1260$(_world_0, _handle_0)), _undo_0, _commands_0, _events_0, _handle_0, _incoming_0);
}

function $schema$058enabled$() {
  return $$$$047$$$047src$047ecs$047component$058define$1263$("Enabled");
}

function $$$$047$$$047src$047ecs$047system$058run_namespace_value$1261$(_registry_0, _world_0, _actual_0, _args_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return $$$$047$$$047src$047ecs$047system$058run_namespace_checked$1261$((_namespace_0 === _actual_0), {$: "../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, _world_0, _args_0);
}

function $$$$047$$$047src$047ecs$047transaction$058finish$1261$(_tx_0, _outcome_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047src$047ecs$047transaction$058finish_world$1261$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0);
}

function $$$$047$$$047src$047ecs$047commands$058spawn_join$1260$(_reserved_0, _undo_0, _commands_0, _events_0, _payload_0) {
  const _world_0 = _reserved_0["fst"];
  const _reservation_0 = _reserved_0["snd"];
  return $$$$047$$$047src$047ecs$047commands$058spawn_reserved$1260$(_reservation_0, _world_0, _undo_0, _commands_0, _events_0, _payload_0);
}

function $$$$047$$$047src$047ecs$047world$058reserve_id$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047src$047ecs$047world$058reserve_available$1260$((_nextId_0 < 131073), ($Bool$not$((_nextId_0 < _capacity_0))), {$: "../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0});
}

function $$$$047$$$047src$047ecs$047system$058register_meta$1260$(_world_0, _result_0, _namespace_0, _name_0, _access_0) {
  if (_result_0.$ === "../../src/ecs/world.RegistrationRejected") {
    return {$: "../../src/ecs/system.RegistrationFailed", "world": _world_0};
  } else {
    const _id_0 = _result_0["id"];
    return {$: "../../src/ecs/system.Registered", "world": _world_0, "registry": {$: "../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": 0}};
  }
}

function $U32$show$(_a_0) {
  const _b_0 = _a_0;
  return $U32$show$if$(_b_0, (_b_0 === 0));
}

function $List$show$go$1260$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($U32$show$(_h_0));
    const _x_1 = ($List$show$go$1260$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $$$$047$$$047src$047ecs$047system$058tracked_clock$1260$(_registry_0, _output_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _clock_0 = _observed_0["snd"];
  return $$$$047$$$047src$047ecs$047system$058cursor_outcome$1260$({$: "../../src/ecs/system.Succeeded", "world": _world_0, "output": _output_0}, _registry_0, _clock_0);
}

function $$$$047$$$047src$047ecs$047world$058clock$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _clock_0};
}

function $$$$047$$$047src$047ecs$047system$058run_namespace_value$1262$(_registry_0, _world_0, _actual_0, _args_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return $$$$047$$$047src$047ecs$047system$058run_namespace_checked$1262$((_namespace_0 === _actual_0), {$: "../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, _world_0, _args_0);
}

function $$$$047$$$047src$047ecs$047structural$058queue_join$1260$(_family_0, _checked_0, _undo_0, _commands_0, _events_0, _handle_0, _incoming_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047src$047ecs$047structural$058queue_checked$1260$(_allowed_0, _family_0, _world_0, _undo_0, _commands_0, _events_0, _handle_0, _incoming_0);
}

function $$$$047$$$047src$047ecs$047component$058define$1260$(_name_0) {
  return {$: "../../src/ecs/component.Family", "name": _name_0};
}

function $$$$047$$$047src$047ecs$047structural$058queue_join$1261$(_family_0, _checked_0, _undo_0, _commands_0, _events_0, _handle_0, _incoming_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047src$047ecs$047structural$058queue_checked$1261$(_allowed_0, _family_0, _world_0, _undo_0, _commands_0, _events_0, _handle_0, _incoming_0);
}

function $$$$047$$$047src$047ecs$047component$058define$1261$(_name_0) {
  return {$: "../../src/ecs/component.Family", "name": _name_0};
}

function $schema$058fill$($0, $1, $2) {
  for (;;) {
    {
      const _values_0 = $0;
      const _index_0 = $1;
      const _array_0 = $2;
      if (_values_0.$ === "Nil") {
        return _array_0;
      } else {
        const _x_0 = _values_0["head"];
        const _rest_0 = _values_0["tail"];
        $0 = _rest_0;
        $1 = ((_index_0 + 1) >>> 0);
        $2 = (_array_0[_index_0 % _array_0.length] = _x_0, _array_0);
        continue;
      }
    }
  }
}

function $schema$058shape_depth$(_shape_0) {
  const _depth_0 = _shape_0["depth"];
  return _depth_0;
}

function $schema$058shape$($0, $1) {
  for (;;) {
    {
      const _values_0 = $0;
      const _current_0 = $1;
      if (_values_0.$ === "Nil") {
        return _current_0;
      } else {
        const _rest_0 = _values_0["tail"];
        $0 = _rest_0;
        $1 = ($schema$058shape_advance$(_current_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047owned$045optimized$045compose$058each_fields$1263$(_args_0, _world_0) {
  return $$$$047$$$047src$047ecs$047optimized$045compose$058recovered$1263$(($$$$047$$$047src$047ecs$047owned$045compose$058each_fields$1263$(_args_0, ($$$$047$$$047src$047ecs$047optimized$045compose$058map_store$1264$(_world_0)))));
}

function $$$$047$$$047src$047ecs$047optimized$045compose$058recovered$1262$(_result_0) {
  const _world_0 = _result_0["world"];
  const _outcome_0 = _result_0["outcome"];
  const _values_0 = _result_0["values"];
  return {$: "../../src/ecs/compose.Executed", "world": ($$$$047$$$047src$047ecs$047optimized$045compose$058map_store$1262$(_world_0)), "outcome": _outcome_0, "values": _values_0};
}

function $$$$047$$$047src$047ecs$047owned$045compose$058each_fields$1262$(_args_0, _world_0) {
  return $$$$047$$$047src$047ecs$047owned$045compose$058reserved_fields$1262$(_args_0, 0, ($$$$047$$$047src$047ecs$047world$058handles$1260$(_world_0)));
}

function $$$$047$$$047src$047ecs$047optimized$045compose$058map_store$1262$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": ($schema$058identity_store$(_store_0)), "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $$$$047$$$047src$047ecs$047optimized$045compose$058map_store$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": ($schema$058recover_store$(_store_0)), "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $$$$047$$$047src$047ecs$047owned$045compose$058reserved_fields$1261$(_args_0, _cursor_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _handles_0 = _observed_0["snd"];
  return $$$$047$$$047src$047ecs$047owned$045compose$058finished$1261$(run_loop($$$$047$$$047src$047ecs$047owned$045compose$058run_handles_fields$1261$(_handles_0, _args_0, _cursor_0, ($$$$047$$$047src$047ecs$047transaction$058begin$1260$(_world_0)))));
}

function $schema$058prepare_store$(_store_0) {
  const _stock_0 = _store_0["stock"];
  const _recipe_0 = _store_0["recipe"];
  const _queue_0 = _store_0["queue"];
  const _enabled_0 = _store_0["enabled"];
  const _locked_0 = _store_0["locked"];
  return {$: "schema.Store", "stock": ($$$$047$$$047src$047ecs$047column$058prepare$1260$(_stock_0)), "recipe": ($$$$047$$$047src$047ecs$047column$058prepare$1261$(_recipe_0)), "queue": ($$$$047$$$047src$047ecs$047column$058prepare$1262$(_queue_0)), "enabled": ($$$$047$$$047src$047ecs$047column$058prepare$1263$(_enabled_0)), "locked": ($$$$047$$$047src$047ecs$047column$058prepare$1264$(_locked_0))};
}

function $observe$058row_stock$(_handle_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _stock_0 = _observed_0["snd"];
  return $observe$058row_recipe$(_handle_0, _stock_0, ($schema$058get_recipe$(_world_0, _handle_0)));
}

function $schema$058get_stock$(_world_0, _handle_0) {
  return $$$$047$$$047src$047ecs$047component$058get$1260$(($schema$058stock$()), _world_0, _handle_0);
}

function $$$$047$$$047src$047ecs$047world$058collect_step$1260$(_checked_0, _namespace_0, _id_0, _handles_0) {
  const _live_0 = _checked_0["fst"];
  const _present_0 = _checked_0["snd"];
  return {$: "../../src/ecs/world.HandleScan", "live": _live_0, "handles": ($$$$047$$$047src$047ecs$047world$058collect_checked$1260$(_present_0, _namespace_0, _id_0, _handles_0))};
}

function $schema$058recover_stock$(_store_0) {
  const _stock_0 = _store_0["stock"];
  const _recipe_0 = _store_0["recipe"];
  const _queue_0 = _store_0["queue"];
  const _enabled_0 = _store_0["enabled"];
  const _locked_0 = _store_0["locked"];
  return {$: "schema.Store", "stock": ($$$$047$$$047src$047ecs$047column$058recover$1260$(_stock_0)), "recipe": _recipe_0, "queue": _queue_0, "enabled": _enabled_0, "locked": _locked_0};
}

function $$$$047$$$047src$047ecs$047owned$045compose$058finished$1261$(_observed_0) {
  const _tx_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  const _result_0 = _t_0["fst"];
  const _values_0 = _t_0["snd"];
  return $$$$047$$$047src$047ecs$047owned$045compose$058finish_returned$1261$(_values_0, ($$$$047$$$047src$047ecs$047commands$058tx_finish$1260$(_tx_0, _result_0)));
}

function $$$$047$$$047src$047ecs$047owned$045compose$058run_handles_fields$1264$(_handles_0, _args_0, _cursor_0, _tx_0) {
  if (_handles_0.$ === "Nil") {
    return {$: "Tuple", "fst": _tx_0, "snd": {$: "Tuple", "fst": {$: "../../src/ecs/transaction.Success"}, "snd": {$: "Nil"}}};
  } else {
    const _handle_0 = _handles_0["head"];
    const _rest_0 = _handles_0["tail"];
    return $$$$047$$$047src$047ecs$047owned$045compose$058selected_fields$1264$(_args_0, run_clo((_x_0) => {
  return $$$$047$$$047src$047ecs$047owned$045compose$058run_handles_fields$1264$(_rest_0, _args_0, _cursor_0, _x_0);
}), ($reference$045declarations$058match_stock$1260$({$: "../../src/ecs/compose.Frame", "tx": _tx_0, "handle": _handle_0, "error": {$: "None"}, "cursor": _cursor_0})));
  }
}

function $$$$047$$$047src$047ecs$047transaction$058begin$1260$(_world_0) {
  return {$: "../../src/ecs/transaction.Tx", "world": _world_0, "undo": {$: "Nil"}, "commands": {$: "Nil"}, "events": {$: "Nil"}};
}

function $$$$047$$$047src$047ecs$047column$058prepare$1260$(_column_0) {
  if (_column_0.$ === "../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047src$047ecs$047column$058prepare_sized$1260$(_stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return {$: "../../src/ecs/column.Prepared", "state": _carrier_0};
  } else if (_column_0.$ === "../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058indexed_prepare_state$1260$(($$$$047$$$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return {$: "../../src/ecs/column.PreparedIndexed", "state": _carrier_2};
  }
}

function $$$$047$$$047src$047ecs$047system$058run_metadata$1260$(_registry_0, _checked_0, _args_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047src$047ecs$047system$058run_checked$1260$(_allowed_0, _registry_0, _world_0, _args_0);
}

function $$$$047$$$047src$047ecs$047world$058registration_matches$1260$(_world_0, _id_0, _name_0, _access_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": ($$$$047$$$047src$047ecs$047world$058registration_list_matches$(_registrations_0, _id_0, _name_0, _access_0))};
}

function $$$$047$$$047src$047ecs$047commands$058despawn_checked_with$1260$(_allowed_0, _world_0, _undo_0, _commands_0, _events_0, _handle_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": {$: "../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "snd": {$: "../../src/ecs/world.Rejected", "error": {$: "../../src/ecs/world.MissingEntity"}}};
  } else {
    return {$: "Tuple", "fst": {$: "../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": {$: "Con", "head": run_clo((_x_0) => {
  return $$$$047$$$047src$047ecs$047commands$058despawn_apply_with$1260$(_x_0, _handle_0);
}), "tail": _commands_0}, "events": _events_0}, "snd": {$: "../../src/ecs/world.Accepted"}};
  }
}

function $$$$047$$$047src$047ecs$047world$058valid_join$1260$(_handle_0, _checked_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047src$047ecs$047world$058valid_checked$1260$(_allowed_0, _world_0, _handle_0);
}

function $$$$047$$$047src$047ecs$047world$058metadata_valid$1260$(_world_0, _handle_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _ns_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  return {$: "Tuple", "fst": {$: "../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": ($Bool$and$((_namespace_0 === _ns_0), ($Bool$and$((0 < _id_0), (_id_0 < _nextId_0)))))};
}

function $$$$047$$$047src$047ecs$047structural$058queue_join$1264$(_family_0, _checked_0, _undo_0, _commands_0, _events_0, _handle_0, _incoming_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047src$047ecs$047structural$058queue_checked$1264$(_allowed_0, _family_0, _world_0, _undo_0, _commands_0, _events_0, _handle_0, _incoming_0);
}

function $$$$047$$$047src$047ecs$047component$058define$1264$(_name_0) {
  return {$: "../../src/ecs/component.Family", "name": _name_0};
}

function $$$$047$$$047src$047ecs$047structural$058queue_join$1263$(_family_0, _checked_0, _undo_0, _commands_0, _events_0, _handle_0, _incoming_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047src$047ecs$047structural$058queue_checked$1263$(_allowed_0, _family_0, _world_0, _undo_0, _commands_0, _events_0, _handle_0, _incoming_0);
}

function $$$$047$$$047src$047ecs$047component$058define$1263$(_name_0) {
  return {$: "../../src/ecs/component.Family", "name": _name_0};
}

function $$$$047$$$047src$047ecs$047system$058run_namespace_checked$1261$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    const _cursor_0 = _registry_0["cursor"];
    return $$$$047$$$047src$047ecs$047system$058run_metadata$1261$({$: "../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, ($$$$047$$$047src$047ecs$047world$058registration_matches$1260$(_world_0, _id_0, _name_0, _access_0)), _args_0);
  }
}

function $$$$047$$$047src$047ecs$047transaction$058finish_world$1261$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0) {
  if (_outcome_0.$ === "../../src/ecs/transaction.Success") {
    const _committed_0 = ($$$$047$$$047src$047ecs$047commands$058enqueue$1260$(_world_0, ($List$reverse$(_commands_0))));
    return {$: "../../src/ecs/transaction.Returned", "world": ($$$$047$$$047src$047ecs$047commands$058publish$1260$(_committed_0, ($List$reverse$(_events_0)))), "outcome": {$: "../../src/ecs/transaction.Success"}};
  } else {
    const _error_0 = _outcome_0["error"];
    return {$: "../../src/ecs/transaction.Returned", "world": ($$$$047$$$047src$047ecs$047transaction$058rollback$1260$(_undo_0, _world_0)), "outcome": {$: "../../src/ecs/transaction.Failure", "error": _error_0}};
  }
}

function $$$$047$$$047src$047ecs$047commands$058spawn_reserved$1260$(_reservation_0, _world_0, _undo_0, _commands_0, _events_0, _payload_0) {
  if (_reservation_0.$ === "../../src/ecs/world.ReservationRejected") {
    const _error_0 = _reservation_0["error"];
    return {$: "Tuple", "fst": {$: "../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "snd": {$: "../../src/ecs/world.ReservationRejected", "error": _error_0}};
  } else {
    const _handle_0 = _reservation_0["handle"];
    return {$: "Tuple", "fst": {$: "../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": {$: "Con", "head": run_clo((_x_0) => {
  return $$$$047$$$047src$047ecs$047commands$058spawn_apply$1260$(_x_0, _handle_0, _payload_0);
}), "tail": _commands_0}, "events": _events_0}, "snd": {$: "../../src/ecs/world.Reserved", "handle": _handle_0}};
  }
}

function $$$$047$$$047src$047ecs$047world$058reserve_available$1260$(_available_0, _grow_0, _world_0) {
  if (!_available_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../src/ecs/world.ReservationRejected", "error": {$: "../../src/ecs/world.CapacityExceeded"}}};
  } else {
    if (!_grow_0) {
      const _namespace_0 = _world_0["namespace"];
      const _nextId_0 = _world_0["nextId"];
      const _highWater_0 = _world_0["highWater"];
      const _live_0 = _world_0["live"];
      const _capacity_0 = _world_0["capacity"];
      const _depth_0 = _world_0["depth"];
      const _store_0 = _world_0["store"];
      const _resource_0 = _world_0["resource"];
      const _events_0 = _world_0["events"];
      const _pending_0 = _world_0["pending"];
      const _registrations_0 = _world_0["registrations"];
      const _nextSystemId_0 = _world_0["nextSystemId"];
      const _clock_0 = _world_0["clock"];
      return $$$$047$$$047src$047ecs$047world$058reserve_finish$1260$({$: "../../src/ecs/world.Growth", "live": _live_0, "capacity": _capacity_0, "depth": _depth_0}, _namespace_0, _nextId_0, _highWater_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
    } else {
      const _namespace_1 = _world_0["namespace"];
      const _nextId_1 = _world_0["nextId"];
      const _highWater_1 = _world_0["highWater"];
      const _live_1 = _world_0["live"];
      const _capacity_1 = _world_0["capacity"];
      const _depth_1 = _world_0["depth"];
      const _store_1 = _world_0["store"];
      const _resource_1 = _world_0["resource"];
      const _events_1 = _world_0["events"];
      const _pending_1 = _world_0["pending"];
      const _registrations_1 = _world_0["registrations"];
      const _nextSystemId_1 = _world_0["nextSystemId"];
      const _clock_1 = _world_0["clock"];
      return $$$$047$$$047src$047ecs$047world$058reserve_finish$1260$(($$$$047$$$047src$047ecs$047world$058grow_live$(1, _capacity_1, _depth_1, _live_1)), _namespace_1, _nextId_1, _highWater_1, _store_1, _resource_1, _events_1, _pending_1, _registrations_1, _nextSystemId_1, _clock_1);
    }
  }
}

function $Bool$not$(_b_0) {
  if (!_b_0) {
    return true;
  } else {
    return false;
  }
}

function $U32$show$if$(_a_0, _z_0) {
  if (_z_0) {
    return "0";
  } else {
    return $U32$show$go$(10, _a_0, "");
  }
}

function $$$$047$$$047src$047ecs$047system$058cursor_outcome$1260$(_outcome_0, _registry_0, _nextCursor_0) {
  if (_outcome_0.$ === "../../src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../src/ecs/system.Completed", "registry": _registry_0, "outcome": {$: "../../src/ecs/system.Failed", "world": _world_0, "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    return {$: "../../src/ecs/system.Completed", "registry": {$: "../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _nextCursor_0}, "outcome": {$: "../../src/ecs/system.Succeeded", "world": _world_1, "output": _output_0}};
  }
}

function $$$$047$$$047src$047ecs$047system$058run_namespace_checked$1262$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    const _cursor_0 = _registry_0["cursor"];
    return $$$$047$$$047src$047ecs$047system$058run_metadata$1262$({$: "../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, ($$$$047$$$047src$047ecs$047world$058registration_matches$1260$(_world_0, _id_0, _name_0, _access_0)), _args_0);
  }
}

function $$$$047$$$047src$047ecs$047structural$058queue_checked$1260$(_allowed_0, _family_0, _world_0, _undo_0, _commands_0, _events_0, _handle_0, _incoming_0) {
  if (!_allowed_0) {
    return {$: "../../src/ecs/structural.QueueRejected", "tx": {$: "../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "incoming": _incoming_0, "error": {$: "../../src/ecs/world.MissingEntity"}};
  } else {
    return {$: "../../src/ecs/structural.Queued", "tx": {$: "../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": {$: "Con", "head": run_clo((_x_0) => {
  return $$$$047$$$047src$047ecs$047structural$058apply$1260$(_family_0, _x_0, _handle_0, _incoming_0);
}), "tail": _commands_0}, "events": _events_0}};
  }
}

function $$$$047$$$047src$047ecs$047structural$058queue_checked$1261$(_allowed_0, _family_0, _world_0, _undo_0, _commands_0, _events_0, _handle_0, _incoming_0) {
  if (!_allowed_0) {
    return {$: "../../src/ecs/structural.QueueRejected", "tx": {$: "../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "incoming": _incoming_0, "error": {$: "../../src/ecs/world.MissingEntity"}};
  } else {
    return {$: "../../src/ecs/structural.Queued", "tx": {$: "../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": {$: "Con", "head": run_clo((_x_0) => {
  return $$$$047$$$047src$047ecs$047structural$058apply$1261$(_family_0, _x_0, _handle_0, _incoming_0);
}), "tail": _commands_0}, "events": _events_0}};
  }
}

function $schema$058shape_advance$(_shape_0) {
  const _capacity_0 = _shape_0["capacity"];
  const _depth_0 = _shape_0["depth"];
  const _used_0 = _shape_0["used"];
  return $schema$058shape_choose$(($Nat$is_eq$(_capacity_0, _used_0)), _capacity_0, _depth_0, _used_0);
}

function $$$$047$$$047src$047ecs$047optimized$045compose$058recovered$1263$(_result_0) {
  const _world_0 = _result_0["world"];
  const _outcome_0 = _result_0["outcome"];
  const _values_0 = _result_0["values"];
  return {$: "../../src/ecs/compose.Executed", "world": ($$$$047$$$047src$047ecs$047optimized$045compose$058map_store$1263$(_world_0)), "outcome": _outcome_0, "values": _values_0};
}

function $$$$047$$$047src$047ecs$047owned$045compose$058each_fields$1263$(_args_0, _world_0) {
  return $$$$047$$$047src$047ecs$047owned$045compose$058reserved_fields$1263$(_args_0, 0, ($$$$047$$$047src$047ecs$047world$058handles$1260$(_world_0)));
}

function $$$$047$$$047src$047ecs$047optimized$045compose$058map_store$1264$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": ($schema$058prepare_enabled$(_store_0)), "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $$$$047$$$047src$047ecs$047owned$045compose$058reserved_fields$1262$(_args_0, _cursor_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _handles_0 = _observed_0["snd"];
  return $$$$047$$$047src$047ecs$047owned$045compose$058finished$1261$(run_loop($$$$047$$$047src$047ecs$047owned$045compose$058run_handles_fields$1262$(_handles_0, _args_0, _cursor_0, ($$$$047$$$047src$047ecs$047transaction$058begin$1260$(_world_0)))));
}

function $schema$058identity_store$(_store_0) {
  return _store_0;
}

function $schema$058recover_store$(_store_0) {
  const _stock_0 = _store_0["stock"];
  const _recipe_0 = _store_0["recipe"];
  const _queue_0 = _store_0["queue"];
  const _enabled_0 = _store_0["enabled"];
  const _locked_0 = _store_0["locked"];
  return {$: "schema.Store", "stock": ($$$$047$$$047src$047ecs$047column$058recover$1260$(_stock_0)), "recipe": ($$$$047$$$047src$047ecs$047column$058recover$1261$(_recipe_0)), "queue": ($$$$047$$$047src$047ecs$047column$058recover$1262$(_queue_0)), "enabled": ($$$$047$$$047src$047ecs$047column$058recover$1263$(_enabled_0)), "locked": ($$$$047$$$047src$047ecs$047column$058recover$1264$(_locked_0))};
}

function $$$$047$$$047src$047ecs$047owned$045compose$058run_handles_fields$1261$(_handles_0, _args_0, _cursor_0, _tx_0) {
  if (_handles_0.$ === "Nil") {
    return {$: "Tuple", "fst": _tx_0, "snd": {$: "Tuple", "fst": {$: "../../src/ecs/transaction.Success"}, "snd": {$: "Nil"}}};
  } else {
    const _handle_0 = _handles_0["head"];
    const _rest_0 = _handles_0["tail"];
    return $$$$047$$$047src$047ecs$047owned$045compose$058selected_fields$1261$(_args_0, run_clo((_x_0) => {
  return $$$$047$$$047src$047ecs$047owned$045compose$058run_handles_fields$1261$(_rest_0, _args_0, _cursor_0, _x_0);
}), ($reference$045declarations$058work_match$({$: "../../src/ecs/compose.Frame", "tx": _tx_0, "handle": _handle_0, "error": {$: "None"}, "cursor": _cursor_0})));
  }
}

function $$$$047$$$047src$047ecs$047column$058prepare$1261$(_column_0) {
  if (_column_0.$ === "../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047src$047ecs$047column$058prepare_sized$1261$(_stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return {$: "../../src/ecs/column.Prepared", "state": _carrier_0};
  } else if (_column_0.$ === "../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058indexed_prepare_state$1261$(($$$$047$$$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return {$: "../../src/ecs/column.PreparedIndexed", "state": _carrier_2};
  }
}

function $$$$047$$$047src$047ecs$047column$058prepare$1262$(_column_0) {
  if (_column_0.$ === "../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047src$047ecs$047column$058prepare_sized$1262$(_stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return {$: "../../src/ecs/column.Prepared", "state": _carrier_0};
  } else if (_column_0.$ === "../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058indexed_prepare_state$1262$(($$$$047$$$047src$047ecs$047column$058indexed_unseal$1262$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return {$: "../../src/ecs/column.PreparedIndexed", "state": _carrier_2};
  }
}

function $$$$047$$$047src$047ecs$047column$058prepare$1263$(_column_0) {
  if (_column_0.$ === "../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047src$047ecs$047column$058prepare_sized$1263$(_stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return {$: "../../src/ecs/column.Prepared", "state": _carrier_0};
  } else if (_column_0.$ === "../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058indexed_prepare_state$1263$(($$$$047$$$047src$047ecs$047column$058indexed_unseal$1263$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return {$: "../../src/ecs/column.PreparedIndexed", "state": _carrier_2};
  }
}

function $$$$047$$$047src$047ecs$047column$058prepare$1264$(_column_0) {
  if (_column_0.$ === "../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047src$047ecs$047column$058prepare_sized$1264$(_stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return {$: "../../src/ecs/column.Prepared", "state": _carrier_0};
  } else if (_column_0.$ === "../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058indexed_prepare_state$1264$(($$$$047$$$047src$047ecs$047column$058indexed_unseal$1264$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return {$: "../../src/ecs/column.PreparedIndexed", "state": _carrier_2};
  }
}

function $observe$058row_recipe$(_handle_0, _stock_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _recipe_0 = _observed_0["snd"];
  return $observe$058row_queue$(_handle_0, _stock_0, _recipe_0, ($schema$058get_queue$(_world_0, _handle_0)));
}

function $schema$058get_recipe$(_world_0, _handle_0) {
  return $$$$047$$$047src$047ecs$047component$058get$1261$(($schema$058recipe$()), _world_0, _handle_0);
}

function $$$$047$$$047src$047ecs$047component$058get$1260$(_family_0, _world_0, _handle_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _ns_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  return $$$$047$$$047src$047ecs$047component$058get_live_owned$1260$(_id_0, ($$$$047$$$047src$047ecs$047component$058get_live_read$(($Bool$and$((_namespace_0 === _ns_0), ($Bool$and$((0 < _id_0), (_id_0 < _nextId_0))))), _id_0, _live_0)), _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047src$047ecs$047world$058collect_checked$1260$(_present_0, _namespace_0, _id_0, _handles_0) {
  if (!_present_0) {
    return _handles_0;
  } else {
    return {$: "Con", "head": {$: "../../src/ecs/world.Handle", "namespace": _namespace_0, "id": _id_0}, "tail": _handles_0};
  }
}

function $$$$047$$$047src$047ecs$047column$058recover$1260$(_column_0) {
  if (_column_0.$ === "../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
  } else if (_column_0.$ === "../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058recover_state$1260$(($$$$047$$$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
  } else if (_column_0.$ === "../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return {$: "../../src/ecs/column.Indexed", "state": _carrier_1};
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058indexed_recover_state$1260$(($$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
  }
}

function $$$$047$$$047src$047ecs$047owned$045compose$058finish_returned$1261$(_values_0, _returned_0) {
  const _world_0 = _returned_0["world"];
  const _t_0 = _returned_0["outcome"];
  if (_t_0.$ === "../../src/ecs/transaction.Success") {
    return {$: "../../src/ecs/compose.Executed", "world": _world_0, "outcome": {$: "../../src/ecs/transaction.Success"}, "values": _values_0};
  } else {
    const _error_0 = _t_0["error"];
    return {$: "../../src/ecs/compose.Executed", "world": _world_0, "outcome": {$: "../../src/ecs/transaction.Failure", "error": _error_0}, "values": {$: "Nil"}};
  }
}

function $$$$047$$$047src$047ecs$047commands$058tx_finish$1260$(_tx_0, _outcome_0) {
  return $$$$047$$$047src$047ecs$047transaction$058finish$1260$(_tx_0, _outcome_0);
}

function $$$$047$$$047src$047ecs$047owned$045compose$058selected_fields$1264$(_args_0, _next_0, _observed_0) {
  const _t_0 = _observed_0["fst"];
  const _tx_0 = _t_0["tx"];
  const __0 = _t_0["handle"];
  const __1 = _t_0["error"];
  const __2 = _t_0["cursor"];
  const _t_1 = _observed_0["snd"];
  if (!_t_1) {
    return run_tail(_next_0, _tx_0);
  } else {
    return $$$$047$$$047src$047ecs$047owned$045compose$058body_returned$1261$(_next_0, ($$$$047$$$047src$047ecs$047owned$045compose$058left$1263$(($$$$047$$$047src$047ecs$047capabilities$058invoke$12610$(_args_0, ($owned$045rows$058enter_duplicate$({$: "../../src/ecs/compose.Frame", "tx": _tx_0, "handle": __0, "error": __1, "cursor": __2})))))));
  }
}

function $reference$045declarations$058match_stock$1260$(_frame_0) {
  return $$$$047$$$047src$047ecs$047compose$058family_match$1263$(_frame_0);
}

function $$$$047$$$047src$047ecs$047column$058prepare_sized$1260$(_stamps_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047src$047ecs$047column$058prepared_evacuated$1260$(_stamps_0, _size_0, ($$$$047$$$047src$047ecs$047column$058evacuate$1260$(_size_0, _size_0, _values_0, {$: "../../src/ecs/owner-handoff.HandoffNil"})));
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepare_state$1260$(_state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047src$047ecs$047column$058indexed_prepare_sized$1260$(_metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047src$047ecs$047column$058indexed_unseal$1260$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../src/ecs/column.IndexedOrdinaryOwned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047system$058run_checked$1260$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    return $$$$047$$$047src$047ecs$047system$058complete$1260$(_registry_0, ($driver$058run_work$(_world_0, _args_0)));
  }
}

function $$$$047$$$047src$047ecs$047world$058registration_list_matches$(_registrations_0, _id_0, _name_0, _access_0) {
  if (_registrations_0.$ === "Nil") {
    return false;
  } else {
    const _meta_0 = _registrations_0["head"];
    const _rest_0 = _registrations_0["tail"];
    const _x_0 = ($$$$047$$$047src$047ecs$047world$058registration_meta_matches$(_meta_0, _id_0, _name_0, _access_0));
    const _x_1 = ($$$$047$$$047src$047ecs$047world$058registration_list_matches$(_rest_0, _id_0, _name_0, _access_0));
    return (_x_0 || _x_1);
  }
}

function $$$$047$$$047src$047ecs$047commands$058despawn_apply_with$1260$(_world_0, _handle_0) {
  return $$$$047$$$047src$047ecs$047commands$058clear_accepted$1260$(($$$$047$$$047src$047ecs$047world$058deactivate$1260$(_world_0, _handle_0)), _handle_0);
}

function $$$$047$$$047src$047ecs$047world$058valid_checked$1260$(_allowed_0, _world_0, _handle_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _world_0, "snd": false};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047src$047ecs$047world$058live_join$1260$({$: "Tuple", fst: _live_0, snd: _live_0[_id_0 % _live_0.length]}, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
  }
}

function $Bool$and$(_a_0, _b_0) {
  if (!_a_0) {
    return false;
  } else {
    return _b_0;
  }
}

function $$$$047$$$047src$047ecs$047structural$058queue_checked$1264$(_allowed_0, _family_0, _world_0, _undo_0, _commands_0, _events_0, _handle_0, _incoming_0) {
  if (!_allowed_0) {
    return {$: "../../src/ecs/structural.QueueRejected", "tx": {$: "../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "incoming": _incoming_0, "error": {$: "../../src/ecs/world.MissingEntity"}};
  } else {
    return {$: "../../src/ecs/structural.Queued", "tx": {$: "../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": {$: "Con", "head": run_clo((_x_0) => {
  return $$$$047$$$047src$047ecs$047structural$058apply$1264$(_family_0, _x_0, _handle_0, _incoming_0);
}), "tail": _commands_0}, "events": _events_0}};
  }
}

function $$$$047$$$047src$047ecs$047structural$058queue_checked$1263$(_allowed_0, _family_0, _world_0, _undo_0, _commands_0, _events_0, _handle_0, _incoming_0) {
  if (!_allowed_0) {
    return {$: "../../src/ecs/structural.QueueRejected", "tx": {$: "../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "incoming": _incoming_0, "error": {$: "../../src/ecs/world.MissingEntity"}};
  } else {
    return {$: "../../src/ecs/structural.Queued", "tx": {$: "../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": {$: "Con", "head": run_clo((_x_0) => {
  return $$$$047$$$047src$047ecs$047structural$058apply$1263$(_family_0, _x_0, _handle_0, _incoming_0);
}), "tail": _commands_0}, "events": _events_0}};
  }
}

function $$$$047$$$047src$047ecs$047system$058run_metadata$1261$(_registry_0, _checked_0, _args_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047src$047ecs$047system$058run_checked$1261$(_allowed_0, _registry_0, _world_0, _args_0);
}

function $$$$047$$$047src$047ecs$047commands$058enqueue$1260$(_world_0, _commands_0) {
  return $$$$047$$$047src$047ecs$047commands$058enqueue_list$1260$(_commands_0, _world_0);
}

function $$$$047$$$047src$047ecs$047commands$058publish$1260$(_world_0, _events_0) {
  return $$$$047$$$047src$047ecs$047world$058event_publish$1260$(_world_0, _events_0);
}

function $$$$047$$$047src$047ecs$047transaction$058rollback$1260$($0, $1) {
  for (;;) {
    {
      const _undo_0 = $0;
      const _world_0 = $1;
      if (_undo_0.$ === "Nil") {
        return _world_0;
      } else {
        const _inverse_0 = _undo_0["head"];
        const _rest_0 = _undo_0["tail"];
        $0 = _rest_0;
        $1 = _inverse_0(_world_0);
        continue;
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047commands$058spawn_apply$1260$(_world_0, _handle_0, _payload_0) {
  return $$$$047$$$047src$047ecs$047commands$058spawned$1260$(($$$$047$$$047src$047ecs$047world$058activate$1260$(_world_0, _handle_0)), _handle_0, _payload_0);
}

function $$$$047$$$047src$047ecs$047world$058reserve_finish$1260$(_grown_0, _namespace_0, _nextId_0, _highWater_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _grown_0["live"];
  const _capacity_0 = _grown_0["capacity"];
  const _depth_0 = _grown_0["depth"];
  return {$: "Tuple", "fst": {$: "../../src/ecs/world.World", "namespace": _namespace_0, "nextId": ((_nextId_0 + 1) >>> 0), "highWater": _nextId_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../../src/ecs/world.Reserved", "handle": {$: "../../src/ecs/world.Handle", "namespace": _namespace_0, "id": _nextId_0}}};
}

function $$$$047$$$047src$047ecs$047world$058grow_live$($0, $1, $2, $3) {
  for (;;) {
    {
      const _remaining_0 = $0;
      const _capacity_0 = $1;
      const _depth_0 = $2;
      const _live_0 = $3;
      if (_remaining_0 === 0) {
        return {$: "../../src/ecs/world.Growth", "live": _live_0, "capacity": _capacity_0, "depth": _depth_0};
      } else {
        const _rest_0 = (_remaining_0 - 1);
        $0 = _rest_0;
        $1 = (Math.imul(_capacity_0, 2) >>> 0);
        $2 = nat_chk(_depth_0 + 1);
        $3 = array_node(_live_0, array_new(_depth_0, false));
        continue;
      }
    }
  }
}

function $U32$show$go$($0, $1, $2, $3) {
  let $pc = 0;
  for (;;) switch ($pc) {
    case 0: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = _n_0;
        $3 = (_n_0 === 0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _n_0 = $2;
      const _z_0 = $3;
      if (_z_0) {
        return _acc_0;
      } else {
        const _x_0 = (10 === 0 ? _n_0 : _n_0 % 10);
        $0 = _g_0;
        $1 = (10 === 0 ? 0 : (_n_0 / 10) >>> 0);
        $2 = (char_new(((48 + _x_0) >>> 0)) + _acc_0);
        $pc = 0; continue;
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047system$058run_metadata$1262$(_registry_0, _checked_0, _args_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047src$047ecs$047system$058run_checked$1262$(_allowed_0, _registry_0, _world_0, _args_0);
}

function $$$$047$$$047src$047ecs$047structural$058apply$1260$(_family_0, _world_0, _handle_0, _incoming_0) {
  return $$$$047$$$047src$047ecs$047structural$058applied$1260$(($$$$047$$$047src$047ecs$047component$058replace$1260$(_family_0, _world_0, _handle_0, _incoming_0)));
}

function $$$$047$$$047src$047ecs$047structural$058apply$1261$(_family_0, _world_0, _handle_0, _incoming_0) {
  return $$$$047$$$047src$047ecs$047structural$058applied$1261$(($$$$047$$$047src$047ecs$047component$058replace$1261$(_family_0, _world_0, _handle_0, _incoming_0)));
}

function $schema$058shape_choose$(_grow_0, _capacity_0, _depth_0, _used_0) {
  if (_grow_0) {
    return {$: "schema.ArrayShape", "capacity": nat_chk(2 * _capacity_0), "depth": nat_chk(_depth_0 + 1), "used": nat_chk(_used_0 + 1)};
  } else {
    return {$: "schema.ArrayShape", "capacity": _capacity_0, "depth": _depth_0, "used": nat_chk(_used_0 + 1)};
  }
}

function $Nat$is_eq$(_a_0, _b_0) {
  return $Cmp$is_eq$(cmp_new(_a_0, _b_0));
}

function $$$$047$$$047src$047ecs$047optimized$045compose$058map_store$1263$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": ($schema$058recover_enabled$(_store_0)), "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $$$$047$$$047src$047ecs$047owned$045compose$058reserved_fields$1263$(_args_0, _cursor_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _handles_0 = _observed_0["snd"];
  return $$$$047$$$047src$047ecs$047owned$045compose$058finished$1261$(run_loop($$$$047$$$047src$047ecs$047owned$045compose$058run_handles_fields$1263$(_handles_0, _args_0, _cursor_0, ($$$$047$$$047src$047ecs$047transaction$058begin$1260$(_world_0)))));
}

function $schema$058prepare_enabled$(_store_0) {
  const _stock_0 = _store_0["stock"];
  const _recipe_0 = _store_0["recipe"];
  const _queue_0 = _store_0["queue"];
  const _enabled_0 = _store_0["enabled"];
  const _locked_0 = _store_0["locked"];
  return {$: "schema.Store", "stock": _stock_0, "recipe": _recipe_0, "queue": _queue_0, "enabled": ($$$$047$$$047src$047ecs$047column$058prepare$1263$(_enabled_0)), "locked": _locked_0};
}

function $$$$047$$$047src$047ecs$047owned$045compose$058run_handles_fields$1262$(_handles_0, _args_0, _cursor_0, _tx_0) {
  if (_handles_0.$ === "Nil") {
    return {$: "Tuple", "fst": _tx_0, "snd": {$: "Tuple", "fst": {$: "../../src/ecs/transaction.Success"}, "snd": {$: "Nil"}}};
  } else {
    const _handle_0 = _handles_0["head"];
    const _rest_0 = _handles_0["tail"];
    return $$$$047$$$047src$047ecs$047owned$045compose$058selected_fields$1262$(_args_0, run_clo((_x_0) => {
  return $$$$047$$$047src$047ecs$047owned$045compose$058run_handles_fields$1262$(_rest_0, _args_0, _cursor_0, _x_0);
}), ($$$$047$$$047src$047ecs$047compose$058all$1260$({$: "../../src/ecs/compose.Frame", "tx": _tx_0, "handle": _handle_0, "error": {$: "None"}, "cursor": _cursor_0})));
  }
}

function $$$$047$$$047src$047ecs$047column$058recover$1261$(_column_0) {
  if (_column_0.$ === "../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
  } else if (_column_0.$ === "../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058recover_state$1261$(($$$$047$$$047src$047ecs$047column$058unseal$1261$(_carrier_0)));
  } else if (_column_0.$ === "../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return {$: "../../src/ecs/column.Indexed", "state": _carrier_1};
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058indexed_recover_state$1261$(($$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1261$(_carrier_2)));
  }
}

function $$$$047$$$047src$047ecs$047column$058recover$1262$(_column_0) {
  if (_column_0.$ === "../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
  } else if (_column_0.$ === "../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058recover_state$1262$(($$$$047$$$047src$047ecs$047column$058unseal$1262$(_carrier_0)));
  } else if (_column_0.$ === "../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return {$: "../../src/ecs/column.Indexed", "state": _carrier_1};
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058indexed_recover_state$1262$(($$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1262$(_carrier_2)));
  }
}

function $$$$047$$$047src$047ecs$047column$058recover$1263$(_column_0) {
  if (_column_0.$ === "../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
  } else if (_column_0.$ === "../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058recover_state$1263$(($$$$047$$$047src$047ecs$047column$058unseal$1263$(_carrier_0)));
  } else if (_column_0.$ === "../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return {$: "../../src/ecs/column.Indexed", "state": _carrier_1};
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058indexed_recover_state$1263$(($$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1263$(_carrier_2)));
  }
}

function $$$$047$$$047src$047ecs$047column$058recover$1264$(_column_0) {
  if (_column_0.$ === "../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
  } else if (_column_0.$ === "../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058recover_state$1264$(($$$$047$$$047src$047ecs$047column$058unseal$1264$(_carrier_0)));
  } else if (_column_0.$ === "../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return {$: "../../src/ecs/column.Indexed", "state": _carrier_1};
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058indexed_recover_state$1264$(($$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1264$(_carrier_2)));
  }
}

function $$$$047$$$047src$047ecs$047owned$045compose$058selected_fields$1261$(_args_0, _next_0, _observed_0) {
  const _t_0 = _observed_0["fst"];
  const _tx_0 = _t_0["tx"];
  const __0 = _t_0["handle"];
  const __1 = _t_0["error"];
  const __2 = _t_0["cursor"];
  const _t_1 = _observed_0["snd"];
  if (!_t_1) {
    return run_tail(_next_0, _tx_0);
  } else {
    return $$$$047$$$047src$047ecs$047owned$045compose$058body_returned$1261$(_next_0, ($$$$047$$$047src$047ecs$047owned$045compose$058left$1261$(($$$$047$$$047src$047ecs$047capabilities$058invoke$1268$(_args_0, ($owned$045rows$058enter_work$({$: "../../src/ecs/compose.Frame", "tx": _tx_0, "handle": __0, "error": __1, "cursor": __2})))))));
  }
}

function $reference$045declarations$058work_match$(_frame_0) {
  return $$$$047$$$047src$047ecs$047compose$058both$1262$(_frame_0);
}

function $$$$047$$$047src$047ecs$047column$058prepare_sized$1261$(_stamps_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047src$047ecs$047column$058prepared_evacuated$1261$(_stamps_0, _size_0, ($$$$047$$$047src$047ecs$047column$058evacuate$1261$(_size_0, _size_0, _values_0, {$: "../../src/ecs/owner-handoff.HandoffNil"})));
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepare_state$1261$(_state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047src$047ecs$047column$058indexed_prepare_sized$1261$(_metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047src$047ecs$047column$058indexed_unseal$1261$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../src/ecs/column.IndexedOrdinaryOwned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047column$058prepare_sized$1262$(_stamps_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047src$047ecs$047column$058prepared_evacuated$1262$(_stamps_0, _size_0, ($$$$047$$$047src$047ecs$047column$058evacuate$1262$(_size_0, _size_0, _values_0, {$: "../../src/ecs/owner-handoff.HandoffNil"})));
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepare_state$1262$(_state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047src$047ecs$047column$058indexed_prepare_sized$1262$(_metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047src$047ecs$047column$058indexed_unseal$1262$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../src/ecs/column.IndexedOrdinaryOwned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047column$058prepare_sized$1263$(_stamps_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047src$047ecs$047column$058prepared_evacuated$1263$(_stamps_0, _size_0, ($$$$047$$$047src$047ecs$047column$058evacuate$1263$(_size_0, _size_0, _values_0, {$: "../../src/ecs/owner-handoff.HandoffNil"})));
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepare_state$1263$(_state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047src$047ecs$047column$058indexed_prepare_sized$1263$(_metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047src$047ecs$047column$058indexed_unseal$1263$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../src/ecs/column.IndexedOrdinaryOwned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047column$058prepare_sized$1264$(_stamps_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047src$047ecs$047column$058prepared_evacuated$1264$(_stamps_0, _size_0, ($$$$047$$$047src$047ecs$047column$058evacuate$1264$(_size_0, _size_0, _values_0, {$: "../../src/ecs/owner-handoff.HandoffNil"})));
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepare_state$1264$(_state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047src$047ecs$047column$058indexed_prepare_sized$1264$(_metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047src$047ecs$047column$058indexed_unseal$1264$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../src/ecs/column.IndexedOrdinaryOwned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $observe$058row_queue$(_handle_0, _stock_0, _recipe_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _queue_0 = _observed_0["snd"];
  return $observe$058row_enabled$(_handle_0, _stock_0, _recipe_0, _queue_0, ($schema$058get_enabled$(_world_0, _handle_0)));
}

function $schema$058get_queue$(_world_0, _handle_0) {
  return $$$$047$$$047src$047ecs$047component$058get$1262$(($schema$058queue$()), _world_0, _handle_0);
}

function $$$$047$$$047src$047ecs$047component$058get$1261$(_family_0, _world_0, _handle_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _ns_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  return $$$$047$$$047src$047ecs$047component$058get_live_owned$1261$(_id_0, ($$$$047$$$047src$047ecs$047component$058get_live_read$(($Bool$and$((_namespace_0 === _ns_0), ($Bool$and$((0 < _id_0), (_id_0 < _nextId_0))))), _id_0, _live_0)), _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047src$047ecs$047component$058get_live_owned$1260$(_id_0, _observed_0, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": {$: "../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../../src/ecs/component.MissingEntity"}};
  } else {
    return $$$$047$$$047src$047ecs$047world$058with_store_finish$1260$(($$$$047$$$047src$047ecs$047component$058get_store$1260$(_id_0, ($schema$058take_stock$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
  }
}

function $$$$047$$$047src$047ecs$047component$058get_live_read$(_allowed_0, _id_0, _live_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _live_0, "snd": false};
  } else {
    return {$: "Tuple", fst: _live_0, snd: _live_0[_id_0 % _live_0.length]};
  }
}

function $$$$047$$$047src$047ecs$047column$058recover_state$1260$(_state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047src$047ecs$047column$058recover_current$1260$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0));
}

function $$$$047$$$047src$047ecs$047column$058unseal$1260$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../src/ecs/column.Owned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_recover_state$1260$(_state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047src$047ecs$047column$058indexed_recover_current$1260$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0));
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1260$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../src/ecs/column.IndexedPreparedOwned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047transaction$058finish$1260$(_tx_0, _outcome_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047src$047ecs$047transaction$058finish_world$1260$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0);
}

function $$$$047$$$047src$047ecs$047owned$045compose$058body_returned$1261$(_next_0, _observed_0) {
  const _t_0 = _observed_0["fst"];
  const _tx_0 = _t_0["tx"];
  const _internal_0 = _t_0["error"];
  const _t_1 = _observed_0["snd"];
  const _user_0 = _t_1["fst"];
  const _value_0 = _t_1["snd"];
  return $$$$047$$$047src$047ecs$047owned$045compose$058completed$1261$(_next_0, _tx_0, _value_0, ($$$$047$$$047src$047ecs$047compose$058outcome$1260$(_internal_0, _user_0)));
}

function $$$$047$$$047src$047ecs$047owned$045compose$058left$1263$(_observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _result_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($owned$045rows$058leave_duplicate$(_owner_0)), "snd": _result_0};
}

function $$$$047$$$047src$047ecs$047capabilities$058invoke$12610$(_args_0, _ctx_0) {
  return $gameplay$058duplicate_body$1261$(_args_0, _ctx_0);
}

function $owned$045rows$058enter_duplicate$(_frame_0) {
  const _t_0 = _frame_0["tx"];
  const _t_1 = _t_0["world"];
  const _namespace_0 = _t_1["namespace"];
  const _nextId_0 = _t_1["nextId"];
  const _highWater_0 = _t_1["highWater"];
  const _live_0 = _t_1["live"];
  const _capacity_0 = _t_1["capacity"];
  const _depth_0 = _t_1["depth"];
  const _t_2 = _t_1["store"];
  const _stock_0 = _t_2["stock"];
  const _recipe_0 = _t_2["recipe"];
  const _queue_0 = _t_2["queue"];
  const _enabled_0 = _t_2["enabled"];
  const _locked_0 = _t_2["locked"];
  const _resource_0 = _t_1["resource"];
  const _events_0 = _t_1["events"];
  const _pending_0 = _t_1["pending"];
  const _registrations_0 = _t_1["registrations"];
  const _nextSystemId_0 = _t_1["nextSystemId"];
  const _clock_0 = _t_1["clock"];
  const _undo_0 = _t_0["undo"];
  const _commands_0 = _t_0["commands"];
  const _txEvents_0 = _t_0["events"];
  const _handle_0 = _frame_0["handle"];
  const _error_0 = _frame_0["error"];
  const _cursor_0 = _frame_0["cursor"];
  return {$: "owned-rows.DuplicateRow", "state": {$: "owned-rows.DuplicateState", "header": {$: "../../src/ecs/owned-family.Header", "namespace": _namespace_0, "nextId": _nextId_0, "live": _live_0, "handle": _handle_0, "clock": _clock_0, "error": _error_0, "cursor": _cursor_0}, "stock": ($$$$047$$$047src$047ecs$047restored$045row$058detach$1260$(_stock_0, ($owned$045rows$058id$(_handle_0)))), "cold": {$: "owned-rows.DuplicateCold", "state": {$: "owned-rows.DuplicateColdState", "highWater": _highWater_0, "capacity": _capacity_0, "depth": _depth_0, "recipe": _recipe_0, "queue": _queue_0, "enabled": _enabled_0, "locked": _locked_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "undo": _undo_0, "commands": _commands_0, "txEvents": _txEvents_0}}}};
}

function $$$$047$$$047src$047ecs$047compose$058family_match$1263$(_frame_0) {
  return $$$$047$$$047src$047ecs$047compose$058selected_join$1263$({$: "../../src/ecs/compose.Required"}, ($$$$047$$$047src$047ecs$047compose$058get$1260$(_frame_0)));
}

function $$$$047$$$047src$047ecs$047column$058prepared_evacuated$1260$(_stamps_0, _capacity_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _rows_0 = _result_0["snd"];
  return {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": _rows_0, "past": {$: "../../src/ecs/column.HistoryNil"}}}};
}

function $$$$047$$$047src$047ecs$047column$058evacuate$1260$(_fuel_0, _id_0, _values_0, _rows_0) {
  if (_fuel_0 === 0) {
    return {$: "Tuple", "fst": _values_0, "snd": _rows_0};
  } else {
    const _rest_0 = (_fuel_0 - 1);
    return $$$$047$$$047src$047ecs$047column$058evacuate_start$1260$(_rest_0, _id_0, _values_0, _rows_0);
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepare_sized$1260$(_metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047src$047ecs$047column$058indexed_prepared_evacuated$1260$(_metadata_0, _size_0, ($$$$047$$$047src$047ecs$047column$058evacuate$1260$(_size_0, _size_0, _values_0, {$: "../../src/ecs/owner-handoff.HandoffNil"})));
}

function $$$$047$$$047src$047ecs$047system$058complete$1260$(_registry_0, _outcome_0) {
  return {$: "../../src/ecs/system.Completed", "registry": _registry_0, "outcome": _outcome_0};
}

function $driver$058run_work$(_world_0, _args_0) {
  return $driver$058unit_outcome$(($declarations$058work$(_world_0)));
}

function $$$$047$$$047src$047ecs$047world$058registration_meta_matches$(_meta_0, _id_0, _name_0, _access_0) {
  const _mid_0 = _meta_0["id"];
  const _mname_0 = _meta_0["name"];
  const _maccess_0 = _meta_0["access"];
  return $Bool$and$((_mid_0 === _id_0), ($Bool$and$(($String$eq$(_mname_0, _name_0)), ($$$$047$$$047src$047ecs$047world$058access_equal$(_maccess_0, _access_0)))));
}

function $$$$047$$$047src$047ecs$047commands$058clear_accepted$1260$(_activated_0, _handle_0) {
  const _world_0 = _activated_0["fst"];
  const _t_0 = _activated_0["snd"];
  if (_t_0.$ === "../../src/ecs/world.Rejected") {
    return _world_0;
  } else {
    return $$$$047$$$047src$047ecs$047commands$058clear_join$1260$(($$$$047$$$047src$047ecs$047world$058with_store$1260$(run_clo((_x_0) => {
  return {$: "Tuple", "fst": ($schema$058clear$(_x_0, _handle_0)), "snd": {$: "Unit"}};
}), _world_0)));
  }
}

function $$$$047$$$047src$047ecs$047world$058deactivate$1260$(_world_0, _handle_0) {
  return $$$$047$$$047src$047ecs$047world$058set_live_join$1260$(false, _handle_0, ($$$$047$$$047src$047ecs$047world$058metadata_valid$1260$(_world_0, _handle_0)));
}

function $$$$047$$$047src$047ecs$047world$058live_join$1260$(_checked_0, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _checked_0["fst"];
  const _found_0 = _checked_0["snd"];
  return {$: "Tuple", "fst": {$: "../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _found_0};
}

function $$$$047$$$047src$047ecs$047structural$058apply$1264$(_family_0, _world_0, _handle_0, _incoming_0) {
  return $$$$047$$$047src$047ecs$047structural$058applied$1264$(($$$$047$$$047src$047ecs$047component$058replace$1264$(_family_0, _world_0, _handle_0, _incoming_0)));
}

function $$$$047$$$047src$047ecs$047structural$058apply$1263$(_family_0, _world_0, _handle_0, _incoming_0) {
  return $$$$047$$$047src$047ecs$047structural$058applied$1263$(($$$$047$$$047src$047ecs$047component$058replace$1263$(_family_0, _world_0, _handle_0, _incoming_0)));
}

function $$$$047$$$047src$047ecs$047system$058run_checked$1261$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    return $$$$047$$$047src$047ecs$047system$058complete$1261$(_registry_0, ($driver$058run_retry$(_world_0, _args_0)));
  }
}

function $$$$047$$$047src$047ecs$047commands$058enqueue_list$1260$($0, $1) {
  for (;;) {
    {
      const _commands_0 = $0;
      const _world_0 = $1;
      if (_commands_0.$ === "Nil") {
        return _world_0;
      } else {
        const _command_0 = _commands_0["head"];
        const _rest_0 = _commands_0["tail"];
        $0 = _rest_0;
        $1 = ($$$$047$$$047src$047ecs$047world$058enqueue$1260$(_world_0, _command_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047world$058event_publish$1260$(_world_0, _published_0) {
  if (_published_0.$ === "Nil") {
    return _world_0;
  } else {
    const _head_0 = _published_0["head"];
    const _rest_0 = _published_0["tail"];
    return $$$$047$$$047src$047ecs$047world$058event_publish_nonempty$1260$(_world_0, {$: "Con", "head": _head_0, "tail": _rest_0});
  }
}

function $$$$047$$$047src$047ecs$047commands$058spawned$1260$(_activated_0, _handle_0, _payload_0) {
  const _world_0 = _activated_0["fst"];
  const _t_0 = _activated_0["snd"];
  if (_t_0.$ === "../../src/ecs/world.Accepted") {
    return $schema$058populate$(_world_0, _handle_0, _payload_0);
  } else {
    return _world_0;
  }
}

function $$$$047$$$047src$047ecs$047world$058activate$1260$(_world_0, _handle_0) {
  return $$$$047$$$047src$047ecs$047world$058set_live_join$1260$(true, _handle_0, ($$$$047$$$047src$047ecs$047world$058metadata_valid$1260$(_world_0, _handle_0)));
}

function $U32$show$fin$($0, $1, $2, $3) {
  let $pc = 1;
  for (;;) switch ($pc) {
    case 0: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = _n_0;
        $3 = (_n_0 === 0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _n_0 = $2;
      const _z_0 = $3;
      if (_z_0) {
        return _acc_0;
      } else {
        const _x_0 = (10 === 0 ? _n_0 : _n_0 % 10);
        $0 = _g_0;
        $1 = (10 === 0 ? 0 : (_n_0 / 10) >>> 0);
        $2 = (char_new(((48 + _x_0) >>> 0)) + _acc_0);
        $pc = 0; continue;
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047system$058run_checked$1262$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    return $$$$047$$$047src$047ecs$047system$058complete$1262$(_registry_0, ($driver$058run_advanced$(_world_0, _args_0)));
  }
}

function $$$$047$$$047src$047ecs$047structural$058applied$1260$(_result_0) {
  if (_result_0.$ === "../../src/ecs/component.Replaced") {
    const _world_0 = _result_0["world"];
    return _world_0;
  } else {
    const _world_1 = _result_0["world"];
    return _world_1;
  }
}

function $$$$047$$$047src$047ecs$047component$058replace$1260$(_family_0, _world_0, _handle_0, _incoming_0) {
  return $$$$047$$$047src$047ecs$047component$058replace_allowed$1260$(($$$$047$$$047src$047ecs$047world$058valid$1260$(_world_0, _handle_0)), _handle_0, _incoming_0);
}

function $$$$047$$$047src$047ecs$047structural$058applied$1261$(_result_0) {
  if (_result_0.$ === "../../src/ecs/component.Replaced") {
    const _world_0 = _result_0["world"];
    return _world_0;
  } else {
    const _world_1 = _result_0["world"];
    return _world_1;
  }
}

function $$$$047$$$047src$047ecs$047component$058replace$1261$(_family_0, _world_0, _handle_0, _incoming_0) {
  return $$$$047$$$047src$047ecs$047component$058replace_allowed$1261$(($$$$047$$$047src$047ecs$047world$058valid$1260$(_world_0, _handle_0)), _handle_0, _incoming_0);
}

function $Cmp$is_eq$(_c_0) {
  if (_c_0.$ === "EQ") {
    return true;
  } else {
    return false;
  }
}

function $schema$058recover_enabled$(_store_0) {
  const _stock_0 = _store_0["stock"];
  const _recipe_0 = _store_0["recipe"];
  const _queue_0 = _store_0["queue"];
  const _enabled_0 = _store_0["enabled"];
  const _locked_0 = _store_0["locked"];
  return {$: "schema.Store", "stock": _stock_0, "recipe": _recipe_0, "queue": _queue_0, "enabled": ($$$$047$$$047src$047ecs$047column$058recover$1263$(_enabled_0)), "locked": _locked_0};
}

function $$$$047$$$047src$047ecs$047owned$045compose$058run_handles_fields$1263$(_handles_0, _args_0, _cursor_0, _tx_0) {
  if (_handles_0.$ === "Nil") {
    return {$: "Tuple", "fst": _tx_0, "snd": {$: "Tuple", "fst": {$: "../../src/ecs/transaction.Success"}, "snd": {$: "Nil"}}};
  } else {
    const _handle_0 = _handles_0["head"];
    const _rest_0 = _handles_0["tail"];
    return $$$$047$$$047src$047ecs$047owned$045compose$058selected_fields$1263$(_args_0, run_clo((_x_0) => {
  return $$$$047$$$047src$047ecs$047owned$045compose$058run_handles_fields$1263$(_rest_0, _args_0, _cursor_0, _x_0);
}), ($reference$045declarations$058contradictory_match$({$: "../../src/ecs/compose.Frame", "tx": _tx_0, "handle": _handle_0, "error": {$: "None"}, "cursor": _cursor_0})));
  }
}

function $$$$047$$$047src$047ecs$047owned$045compose$058selected_fields$1262$(_args_0, _next_0, _observed_0) {
  const _t_0 = _observed_0["fst"];
  const _tx_0 = _t_0["tx"];
  const __0 = _t_0["handle"];
  const __1 = _t_0["error"];
  const __2 = _t_0["cursor"];
  const _t_1 = _observed_0["snd"];
  if (!_t_1) {
    return run_tail(_next_0, _tx_0);
  } else {
    return $$$$047$$$047src$047ecs$047owned$045compose$058body_returned$1261$(_next_0, ($$$$047$$$047src$047ecs$047owned$045compose$058left$1262$(($$$$047$$$047src$047ecs$047capabilities$058invoke$1269$(_args_0, ($declarations$058frame_identity$({$: "../../src/ecs/compose.Frame", "tx": _tx_0, "handle": __0, "error": __1, "cursor": __2})))))));
  }
}

function $$$$047$$$047src$047ecs$047compose$058all$1260$(_frame_0) {
  return {$: "Tuple", "fst": _frame_0, "snd": true};
}

function $$$$047$$$047src$047ecs$047column$058recover_state$1261$(_state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047src$047ecs$047column$058recover_current$1261$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0));
}

function $$$$047$$$047src$047ecs$047column$058unseal$1261$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../src/ecs/column.Owned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_recover_state$1261$(_state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047src$047ecs$047column$058indexed_recover_current$1261$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0));
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1261$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../src/ecs/column.IndexedPreparedOwned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047column$058recover_state$1262$(_state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047src$047ecs$047column$058recover_current$1262$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0));
}

function $$$$047$$$047src$047ecs$047column$058unseal$1262$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../src/ecs/column.Owned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_recover_state$1262$(_state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047src$047ecs$047column$058indexed_recover_current$1262$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0));
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1262$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../src/ecs/column.IndexedPreparedOwned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047column$058recover_state$1263$(_state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047src$047ecs$047column$058recover_current$1263$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0));
}

function $$$$047$$$047src$047ecs$047column$058unseal$1263$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../src/ecs/column.Owned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_recover_state$1263$(_state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047src$047ecs$047column$058indexed_recover_current$1263$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0));
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1263$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../src/ecs/column.IndexedPreparedOwned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047column$058recover_state$1264$(_state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047src$047ecs$047column$058recover_current$1264$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0));
}

function $$$$047$$$047src$047ecs$047column$058unseal$1264$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../src/ecs/column.Owned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_recover_state$1264$(_state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047src$047ecs$047column$058indexed_recover_current$1264$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0));
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1264$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../src/ecs/column.IndexedPreparedOwned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047owned$045compose$058left$1261$(_observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _result_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($owned$045rows$058leave_work$(_owner_0)), "snd": _result_0};
}

function $$$$047$$$047src$047ecs$047capabilities$058invoke$1268$(_args_0, _ctx_0) {
  return $gameplay$058compose_body$1261$(_args_0, _ctx_0);
}

function $owned$045rows$058enter_work$(_frame_0) {
  const _t_0 = _frame_0["tx"];
  const _t_1 = _t_0["world"];
  const _namespace_0 = _t_1["namespace"];
  const _nextId_0 = _t_1["nextId"];
  const _highWater_0 = _t_1["highWater"];
  const _live_0 = _t_1["live"];
  const _capacity_0 = _t_1["capacity"];
  const _depth_0 = _t_1["depth"];
  const _t_2 = _t_1["store"];
  const _stock_0 = _t_2["stock"];
  const _recipe_0 = _t_2["recipe"];
  const _queue_0 = _t_2["queue"];
  const _enabled_0 = _t_2["enabled"];
  const _locked_0 = _t_2["locked"];
  const _resource_0 = _t_1["resource"];
  const _events_0 = _t_1["events"];
  const _pending_0 = _t_1["pending"];
  const _registrations_0 = _t_1["registrations"];
  const _nextSystemId_0 = _t_1["nextSystemId"];
  const _clock_0 = _t_1["clock"];
  const _undo_0 = _t_0["undo"];
  const _commands_0 = _t_0["commands"];
  const _txEvents_0 = _t_0["events"];
  const _handle_0 = _frame_0["handle"];
  const _error_0 = _frame_0["error"];
  const _cursor_0 = _frame_0["cursor"];
  return {$: "owned-rows.WorkRow", "state": {$: "owned-rows.WorkState", "header": {$: "../../src/ecs/owned-family.Header", "namespace": _namespace_0, "nextId": _nextId_0, "live": _live_0, "handle": _handle_0, "clock": _clock_0, "error": _error_0, "cursor": _cursor_0}, "stock": ($$$$047$$$047src$047ecs$047restored$045row$058detach$1260$(_stock_0, ($owned$045rows$058id$(_handle_0)))), "recipe": ($$$$047$$$047src$047ecs$047restored$045row$058detach$1261$(_recipe_0, ($owned$045rows$058id$(_handle_0)))), "queue": ($$$$047$$$047src$047ecs$047restored$045row$058detach$1262$(_queue_0, ($owned$045rows$058id$(_handle_0)))), "cold": {$: "owned-rows.WorkCold", "state": {$: "owned-rows.WorkColdState", "highWater": _highWater_0, "capacity": _capacity_0, "depth": _depth_0, "enabled": _enabled_0, "locked": _locked_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "undo": _undo_0, "commands": _commands_0, "txEvents": _txEvents_0}}}};
}

function $$$$047$$$047src$047ecs$047compose$058both$1262$(_frame_0) {
  return $$$$047$$$047src$047ecs$047compose$058and_join$1262$(($reference$045declarations$058work_required$(_frame_0)));
}

function $$$$047$$$047src$047ecs$047column$058prepared_evacuated$1261$(_stamps_0, _capacity_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _rows_0 = _result_0["snd"];
  return {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": _rows_0, "past": {$: "../../src/ecs/column.HistoryNil"}}}};
}

function $$$$047$$$047src$047ecs$047column$058evacuate$1261$(_fuel_0, _id_0, _values_0, _rows_0) {
  if (_fuel_0 === 0) {
    return {$: "Tuple", "fst": _values_0, "snd": _rows_0};
  } else {
    const _rest_0 = (_fuel_0 - 1);
    return $$$$047$$$047src$047ecs$047column$058evacuate_start$1261$(_rest_0, _id_0, _values_0, _rows_0);
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepare_sized$1261$(_metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047src$047ecs$047column$058indexed_prepared_evacuated$1261$(_metadata_0, _size_0, ($$$$047$$$047src$047ecs$047column$058evacuate$1261$(_size_0, _size_0, _values_0, {$: "../../src/ecs/owner-handoff.HandoffNil"})));
}

function $$$$047$$$047src$047ecs$047column$058prepared_evacuated$1262$(_stamps_0, _capacity_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _rows_0 = _result_0["snd"];
  return {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": _rows_0, "past": {$: "../../src/ecs/column.HistoryNil"}}}};
}

function $$$$047$$$047src$047ecs$047column$058evacuate$1262$(_fuel_0, _id_0, _values_0, _rows_0) {
  if (_fuel_0 === 0) {
    return {$: "Tuple", "fst": _values_0, "snd": _rows_0};
  } else {
    const _rest_0 = (_fuel_0 - 1);
    return $$$$047$$$047src$047ecs$047column$058evacuate_start$1262$(_rest_0, _id_0, _values_0, _rows_0);
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepare_sized$1262$(_metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047src$047ecs$047column$058indexed_prepared_evacuated$1262$(_metadata_0, _size_0, ($$$$047$$$047src$047ecs$047column$058evacuate$1262$(_size_0, _size_0, _values_0, {$: "../../src/ecs/owner-handoff.HandoffNil"})));
}

function $$$$047$$$047src$047ecs$047column$058prepared_evacuated$1263$(_stamps_0, _capacity_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _rows_0 = _result_0["snd"];
  return {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": _rows_0, "past": {$: "../../src/ecs/column.HistoryNil"}}}};
}

function $$$$047$$$047src$047ecs$047column$058evacuate$1263$(_fuel_0, _id_0, _values_0, _rows_0) {
  if (_fuel_0 === 0) {
    return {$: "Tuple", "fst": _values_0, "snd": _rows_0};
  } else {
    const _rest_0 = (_fuel_0 - 1);
    return $$$$047$$$047src$047ecs$047column$058evacuate_start$1263$(_rest_0, _id_0, _values_0, _rows_0);
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepare_sized$1263$(_metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047src$047ecs$047column$058indexed_prepared_evacuated$1263$(_metadata_0, _size_0, ($$$$047$$$047src$047ecs$047column$058evacuate$1263$(_size_0, _size_0, _values_0, {$: "../../src/ecs/owner-handoff.HandoffNil"})));
}

function $$$$047$$$047src$047ecs$047column$058prepared_evacuated$1264$(_stamps_0, _capacity_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _rows_0 = _result_0["snd"];
  return {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": _rows_0, "past": {$: "../../src/ecs/column.HistoryNil"}}}};
}

function $$$$047$$$047src$047ecs$047column$058evacuate$1264$(_fuel_0, _id_0, _values_0, _rows_0) {
  if (_fuel_0 === 0) {
    return {$: "Tuple", "fst": _values_0, "snd": _rows_0};
  } else {
    const _rest_0 = (_fuel_0 - 1);
    return $$$$047$$$047src$047ecs$047column$058evacuate_start$1264$(_rest_0, _id_0, _values_0, _rows_0);
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepare_sized$1264$(_metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047src$047ecs$047column$058indexed_prepared_evacuated$1264$(_metadata_0, _size_0, ($$$$047$$$047src$047ecs$047column$058evacuate$1264$(_size_0, _size_0, _values_0, {$: "../../src/ecs/owner-handoff.HandoffNil"})));
}

function $observe$058row_enabled$(_handle_0, _stock_0, _recipe_0, _queue_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _enabled_0 = _observed_0["snd"];
  return $observe$058row_locked$(_handle_0, _stock_0, _recipe_0, _queue_0, _enabled_0, ($schema$058get_locked$(_world_0, _handle_0)));
}

function $schema$058get_enabled$(_world_0, _handle_0) {
  return $$$$047$$$047src$047ecs$047component$058get$1263$(($schema$058enabled$()), _world_0, _handle_0);
}

function $$$$047$$$047src$047ecs$047component$058get$1262$(_family_0, _world_0, _handle_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _ns_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  return $$$$047$$$047src$047ecs$047component$058get_live_owned$1262$(_id_0, ($$$$047$$$047src$047ecs$047component$058get_live_read$(($Bool$and$((_namespace_0 === _ns_0), ($Bool$and$((0 < _id_0), (_id_0 < _nextId_0))))), _id_0, _live_0)), _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $schema$058queue$() {
  return $$$$047$$$047src$047ecs$047component$058define$1262$("Queue");
}

function $$$$047$$$047src$047ecs$047component$058get_live_owned$1261$(_id_0, _observed_0, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": {$: "../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../../src/ecs/component.MissingEntity"}};
  } else {
    return $$$$047$$$047src$047ecs$047world$058with_store_finish$1261$(($$$$047$$$047src$047ecs$047component$058get_store$1261$(_id_0, ($schema$058take_recipe$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
  }
}

function $$$$047$$$047src$047ecs$047world$058with_store_finish$1260$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047src$047ecs$047component$058get_store$1260$(_id_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047src$047ecs$047component$058get_projected$1260$(_rest_0, ($$$$047$$$047src$047ecs$047column$058view$1260$(_column_0, _id_0)));
}

function $schema$058take_stock$(_store_0) {
  const _stock_0 = _store_0["stock"];
  const _recipe_0 = _store_0["recipe"];
  const _queue_0 = _store_0["queue"];
  const _enabled_0 = _store_0["enabled"];
  const _locked_0 = _store_0["locked"];
  return {$: "Tuple", "fst": {$: "schema.StockRest", "recipe": _recipe_0, "queue": _queue_0, "enabled": _enabled_0, "locked": _locked_0}, "snd": _stock_0};
}

function $$$$047$$$047src$047ecs$047column$058recover_current$1260$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, _active_0) {
  if (!_active_0) {
    return {$: "../../src/ecs/column.Column", "values": ($$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047src$047ecs$047column$058recover_past$1260$(_past_0, _values_0)))), "stamps": _stamps_0};
  } else {
    const _x_0 = ((_current_0 - 1) >>> 0);
    return {$: "../../src/ecs/column.Column", "values": ($$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047src$047ecs$047column$058recover_past$1260$(_past_0, (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0))))), "stamps": _stamps_0};
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_recover_current$1260$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, _active_0) {
  if (!_active_0) {
    return $$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(($$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047src$047ecs$047column$058recover_past$1260$(_past_0, _values_0)))), _metadata_0);
  } else {
    const _x_0 = ((_current_0 - 1) >>> 0);
    return $$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(($$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047src$047ecs$047column$058recover_past$1260$(_past_0, (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0))))), _metadata_0);
  }
}

function $$$$047$$$047src$047ecs$047transaction$058finish_world$1260$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0) {
  if (_outcome_0.$ === "../../src/ecs/transaction.Success") {
    const _committed_0 = ($$$$047$$$047src$047ecs$047commands$058enqueue$1260$(_world_0, ($List$reverse$(_commands_0))));
    return {$: "../../src/ecs/transaction.Returned", "world": ($$$$047$$$047src$047ecs$047commands$058publish$1260$(_committed_0, ($List$reverse$(_events_0)))), "outcome": {$: "../../src/ecs/transaction.Success"}};
  } else {
    const _error_0 = _outcome_0["error"];
    return {$: "../../src/ecs/transaction.Returned", "world": ($$$$047$$$047src$047ecs$047transaction$058rollback$1260$(_undo_0, _world_0)), "outcome": {$: "../../src/ecs/transaction.Failure", "error": _error_0}};
  }
}

function $$$$047$$$047src$047ecs$047owned$045compose$058completed$1261$(_next_0, _tx_0, _value_0, _result_0) {
  if (_result_0.$ === "../../src/ecs/transaction.Success") {
    return $$$$047$$$047src$047ecs$047owned$045compose$058prepend$1261$(_value_0, _next_0(_tx_0));
  } else {
    const _error_0 = _result_0["error"];
    return {$: "Tuple", "fst": _tx_0, "snd": {$: "Tuple", "fst": {$: "../../src/ecs/transaction.Failure", "error": _error_0}, "snd": {$: "Nil"}}};
  }
}

function $$$$047$$$047src$047ecs$047compose$058outcome$1260$(_internal_0, _user_0) {
  if (_internal_0.$ === "Some") {
    const _error_0 = _internal_0["value"];
    return {$: "../../src/ecs/transaction.Failure", "error": {$: "../../src/ecs/compose.AccessError", "error": _error_0}};
  } else {
    if (_user_0.$ === "../../src/ecs/transaction.Failure") {
      const _error_1 = _user_0["error"];
      return {$: "../../src/ecs/transaction.Failure", "error": {$: "../../src/ecs/compose.UserError", "error": _error_1}};
    } else {
      return {$: "../../src/ecs/transaction.Success"};
    }
  }
}

function $owned$045rows$058leave_duplicate$($0) {
  for (;;) {
    {
      const _row_0 = $0;
      if (_row_0.$ === "owned-rows.DuplicateRow") {
        const _t_0 = _row_0["state"];
        const _header_0 = _t_0["header"];
        const _stock_0 = _t_0["stock"];
        const _cold_0 = _t_0["cold"];
        return $owned$045rows$058leave_duplicate_cold$(_header_0, run_loop($$$$047$$$047src$047ecs$047restored$045row$058attach$1260$(_stock_0)), _cold_0);
      } else {
        const _inner_0 = _row_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $gameplay$058duplicate_body$1261$(_args_0, _ctx_0) {
  return $gameplay$058duplicate_named$1261$(run_loop($$$$047$$$047src$047ecs$047capabilities$058value_read$1267$(_ctx_0)));
}

function $$$$047$$$047src$047ecs$047restored$045row$058detach$1260$(_column_0, _id_0) {
  return $$$$047$$$047src$047ecs$047restored$045row$058captured$1260$(($$$$047$$$047src$047ecs$047captured$045column$058capture$1260$(_column_0, _id_0)));
}

function $owned$045rows$058id$(_handle_0) {
  const _id_0 = _handle_0["id"];
  return _id_0;
}

function $$$$047$$$047src$047ecs$047compose$058selected_join$1263$(_mode_0, _observed_0) {
  const _frame_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _frame_0, "snd": ($$$$047$$$047src$047ecs$047compose$058selected_value$1263$(_mode_0, _value_0))};
}

function $$$$047$$$047src$047ecs$047compose$058get$1260$(_frame_0) {
  const _tx_0 = _frame_0["tx"];
  const _handle_0 = _frame_0["handle"];
  const _error_0 = _frame_0["error"];
  const _cursor_0 = _frame_0["cursor"];
  return $$$$047$$$047src$047ecs$047compose$058read_join$1260$(_handle_0, _error_0, _cursor_0, ($$$$047$$$047src$047ecs$047component$058tx_get$1260$(($schema$058stock$()), _tx_0, _handle_0)));
}

function $$$$047$$$047src$047ecs$047column$058evacuate_start$1260$(_fuel_0, _id_0, _values_0, _rows_0) {
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = {$: "None"};
  return $$$$047$$$047src$047ecs$047column$058evacuate_pending$1260$(_fuel_0, _id_0, _rows_0, array_rmw(_values_0, _x_0, () => _x_1));
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepared_evacuated$1260$(_metadata_0, _capacity_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _rows_0 = _result_0["snd"];
  return {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": _rows_0, "past": {$: "../../src/ecs/column.HistoryNil"}}}};
}

function $driver$058unit_outcome$(_result_0) {
  const _world_0 = _result_0["world"];
  const _t_0 = _result_0["outcome"];
  if (_t_0.$ === "../../src/ecs/transaction.Success") {
    return {$: "../../src/ecs/system.Succeeded", "world": _world_0, "output": {$: "Unit"}};
  } else {
    const _t_1 = _t_0["error"];
    if (_t_1.$ === "../../src/ecs/compose.UserError") {
      const _t_2 = _t_1["error"];
      if (_t_2.$ === "gameplay.Rejected") {
        return {$: "../../src/ecs/system.Failed", "world": _world_0, "error": "Rejected"};
      } else {
        return {$: "../../src/ecs/system.Failed", "world": _world_0, "error": "UnexpectedFailure"};
      }
    } else {
      return {$: "../../src/ecs/system.Failed", "world": _world_0, "error": "UnexpectedFailure"};
    }
  }
}

function $declarations$058work$(_world_0) {
  return $$$$047$$$047src$047ecs$047owned$045optimized$045compose$058each_fields$1260$({$: "Unit"}, _world_0);
}

function $String$eq$(_a_0, _b_0) {
  return $Cmp$is_eq$(($String$order$(_a_0, _b_0)));
}

function $$$$047$$$047src$047ecs$047world$058access_equal$(_xs_0, _ys_0) {
  if (_xs_0.$ === "Nil") {
    if (_ys_0.$ === "Nil") {
      return true;
    } else {
      return false;
    }
  } else {
    const __2 = _xs_0["head"];
    const __3 = _xs_0["tail"];
    if (_ys_0.$ === "Nil") {
      return false;
    } else {
      const _y_0 = _ys_0["head"];
      const _ys_1 = _ys_0["tail"];
      return $Bool$and$(($String$eq$(__2, _y_0)), ($$$$047$$$047src$047ecs$047world$058access_equal$(__3, _ys_1)));
    }
  }
}

function $$$$047$$$047src$047ecs$047commands$058clear_join$1260$(_cleared_0) {
  const _world_0 = _cleared_0["fst"];
  return _world_0;
}

function $$$$047$$$047src$047ecs$047world$058with_store$1260$(_effect_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047src$047ecs$047world$058with_store_finish$12610$(_effect_0(_store_0), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $schema$058clear$(_store_0, _handle_0) {
  const _id_0 = _handle_0["id"];
  return $schema$058clear_inner$(_store_0, _id_0);
}

function $$$$047$$$047src$047ecs$047world$058set_live_join$1260$(_value_0, _handle_0, _checked_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047src$047ecs$047world$058set_live_checked$1260$(_allowed_0, _value_0, _world_0, _handle_0);
}

function $$$$047$$$047src$047ecs$047structural$058applied$1264$(_result_0) {
  if (_result_0.$ === "../../src/ecs/component.Replaced") {
    const _world_0 = _result_0["world"];
    return _world_0;
  } else {
    const _world_1 = _result_0["world"];
    return _world_1;
  }
}

function $$$$047$$$047src$047ecs$047component$058replace$1264$(_family_0, _world_0, _handle_0, _incoming_0) {
  return $$$$047$$$047src$047ecs$047component$058replace_allowed$1264$(($$$$047$$$047src$047ecs$047world$058valid$1260$(_world_0, _handle_0)), _handle_0, _incoming_0);
}

function $$$$047$$$047src$047ecs$047structural$058applied$1263$(_result_0) {
  if (_result_0.$ === "../../src/ecs/component.Replaced") {
    const _world_0 = _result_0["world"];
    return _world_0;
  } else {
    const _world_1 = _result_0["world"];
    return _world_1;
  }
}

function $$$$047$$$047src$047ecs$047component$058replace$1263$(_family_0, _world_0, _handle_0, _incoming_0) {
  return $$$$047$$$047src$047ecs$047component$058replace_allowed$1263$(($$$$047$$$047src$047ecs$047world$058valid$1260$(_world_0, _handle_0)), _handle_0, _incoming_0);
}

function $$$$047$$$047src$047ecs$047system$058complete$1261$(_registry_0, _outcome_0) {
  return {$: "../../src/ecs/system.Completed", "registry": _registry_0, "outcome": _outcome_0};
}

function $driver$058run_retry$(_world_0, _args_0) {
  return $driver$058unit_outcome$(($declarations$058retry$(_world_0, _args_0)));
}

function $$$$047$$$047src$047ecs$047world$058enqueue$1260$(_world_0, _command_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": {$: "Con", "head": _command_0, "tail": _pending_0}, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $$$$047$$$047src$047ecs$047world$058event_publish_nonempty$1260$(_world_0, _published_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": ($$$$047$$$047src$047ecs$047world$058event_append$1260$(_events_0, _published_0)), "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $schema$058populate$(_world_0, _handle_0, _bundle_0) {
  const _namespace_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  return $schema$058populate_inner$(_world_0, {$: "../../src/ecs/world.Handle", "namespace": _namespace_0, "id": _id_0}, _bundle_0);
}

function $$$$047$$$047src$047ecs$047system$058complete$1262$(_registry_0, _outcome_0) {
  return {$: "../../src/ecs/system.Completed", "registry": _registry_0, "outcome": _outcome_0};
}

function $driver$058run_advanced$(_world_0, _cursor_0) {
  return $driver$058advanced_outcome$(($declarations$058advanced$(_world_0, _cursor_0)));
}

function $$$$047$$$047src$047ecs$047component$058replace_allowed$1260$(_checked_0, _handle_0, _incoming_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return {$: "../../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../src/ecs/world.MissingEntity"}};
  } else {
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047src$047ecs$047component$058replace_clock$1260$(_id_0, _incoming_0, ($$$$047$$$047src$047ecs$047world$058clock$1260$(_world_0)));
  }
}

function $$$$047$$$047src$047ecs$047component$058replace_allowed$1261$(_checked_0, _handle_0, _incoming_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return {$: "../../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../src/ecs/world.MissingEntity"}};
  } else {
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047src$047ecs$047component$058replace_clock$1261$(_id_0, _incoming_0, ($$$$047$$$047src$047ecs$047world$058clock$1260$(_world_0)));
  }
}

function $$$$047$$$047src$047ecs$047owned$045compose$058selected_fields$1263$(_args_0, _next_0, _observed_0) {
  const _t_0 = _observed_0["fst"];
  const _tx_0 = _t_0["tx"];
  const __0 = _t_0["handle"];
  const __1 = _t_0["error"];
  const __2 = _t_0["cursor"];
  const _t_1 = _observed_0["snd"];
  if (!_t_1) {
    return run_tail(_next_0, _tx_0);
  } else {
    return $$$$047$$$047src$047ecs$047owned$045compose$058body_returned$1261$(_next_0, ($$$$047$$$047src$047ecs$047owned$045compose$058left$1262$(($$$$047$$$047src$047ecs$047capabilities$058invoke$1269$(_args_0, ($declarations$058frame_identity$({$: "../../src/ecs/compose.Frame", "tx": _tx_0, "handle": __0, "error": __1, "cursor": __2})))))));
  }
}

function $reference$045declarations$058contradictory_match$(_frame_0) {
  return $$$$047$$$047src$047ecs$047compose$058both$1263$(_frame_0);
}

function $$$$047$$$047src$047ecs$047owned$045compose$058left$1262$(_observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _result_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($declarations$058frame_identity$(_owner_0)), "snd": _result_0};
}

function $$$$047$$$047src$047ecs$047capabilities$058invoke$1269$(_args_0, _ctx_0) {
  return $reference$045declarations$058empty_body$1262$(_args_0, _ctx_0);
}

function $declarations$058frame_identity$(_frame_0) {
  return _frame_0;
}

function $$$$047$$$047src$047ecs$047column$058recover_current$1261$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, _active_0) {
  if (!_active_0) {
    return {$: "../../src/ecs/column.Column", "values": ($$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047src$047ecs$047column$058recover_past$1261$(_past_0, _values_0)))), "stamps": _stamps_0};
  } else {
    const _x_0 = ((_current_0 - 1) >>> 0);
    return {$: "../../src/ecs/column.Column", "values": ($$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047src$047ecs$047column$058recover_past$1261$(_past_0, (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0))))), "stamps": _stamps_0};
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_recover_current$1261$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, _active_0) {
  if (!_active_0) {
    return $$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(($$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047src$047ecs$047column$058recover_past$1261$(_past_0, _values_0)))), _metadata_0);
  } else {
    const _x_0 = ((_current_0 - 1) >>> 0);
    return $$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(($$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047src$047ecs$047column$058recover_past$1261$(_past_0, (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0))))), _metadata_0);
  }
}

function $$$$047$$$047src$047ecs$047column$058recover_current$1262$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, _active_0) {
  if (!_active_0) {
    return {$: "../../src/ecs/column.Column", "values": ($$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047src$047ecs$047column$058recover_past$1262$(_past_0, _values_0)))), "stamps": _stamps_0};
  } else {
    const _x_0 = ((_current_0 - 1) >>> 0);
    return {$: "../../src/ecs/column.Column", "values": ($$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047src$047ecs$047column$058recover_past$1262$(_past_0, (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0))))), "stamps": _stamps_0};
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_recover_current$1262$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, _active_0) {
  if (!_active_0) {
    return $$$$047$$$047src$047ecs$047column$058indexed_wrap$1262$(($$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047src$047ecs$047column$058recover_past$1262$(_past_0, _values_0)))), _metadata_0);
  } else {
    const _x_0 = ((_current_0 - 1) >>> 0);
    return $$$$047$$$047src$047ecs$047column$058indexed_wrap$1262$(($$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047src$047ecs$047column$058recover_past$1262$(_past_0, (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0))))), _metadata_0);
  }
}

function $$$$047$$$047src$047ecs$047column$058recover_current$1263$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, _active_0) {
  if (!_active_0) {
    return {$: "../../src/ecs/column.Column", "values": ($$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047src$047ecs$047column$058recover_past$1263$(_past_0, _values_0)))), "stamps": _stamps_0};
  } else {
    const _x_0 = ((_current_0 - 1) >>> 0);
    return {$: "../../src/ecs/column.Column", "values": ($$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047src$047ecs$047column$058recover_past$1263$(_past_0, (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0))))), "stamps": _stamps_0};
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_recover_current$1263$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, _active_0) {
  if (!_active_0) {
    return $$$$047$$$047src$047ecs$047column$058indexed_wrap$1263$(($$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047src$047ecs$047column$058recover_past$1263$(_past_0, _values_0)))), _metadata_0);
  } else {
    const _x_0 = ((_current_0 - 1) >>> 0);
    return $$$$047$$$047src$047ecs$047column$058indexed_wrap$1263$(($$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047src$047ecs$047column$058recover_past$1263$(_past_0, (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0))))), _metadata_0);
  }
}

function $$$$047$$$047src$047ecs$047column$058recover_current$1264$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, _active_0) {
  if (!_active_0) {
    return {$: "../../src/ecs/column.Column", "values": ($$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047src$047ecs$047column$058recover_past$1264$(_past_0, _values_0)))), "stamps": _stamps_0};
  } else {
    const _x_0 = ((_current_0 - 1) >>> 0);
    return {$: "../../src/ecs/column.Column", "values": ($$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047src$047ecs$047column$058recover_past$1264$(_past_0, (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0))))), "stamps": _stamps_0};
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_recover_current$1264$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, _active_0) {
  if (!_active_0) {
    return $$$$047$$$047src$047ecs$047column$058indexed_wrap$1264$(($$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047src$047ecs$047column$058recover_past$1264$(_past_0, _values_0)))), _metadata_0);
  } else {
    const _x_0 = ((_current_0 - 1) >>> 0);
    return $$$$047$$$047src$047ecs$047column$058indexed_wrap$1264$(($$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047src$047ecs$047column$058recover_past$1264$(_past_0, (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0))))), _metadata_0);
  }
}

function $owned$045rows$058leave_work$($0) {
  for (;;) {
    {
      const _row_0 = $0;
      if (_row_0.$ === "owned-rows.WorkRow") {
        const _t_0 = _row_0["state"];
        const _header_0 = _t_0["header"];
        const _stock_0 = _t_0["stock"];
        const _recipe_0 = _t_0["recipe"];
        const _queue_0 = _t_0["queue"];
        const _cold_0 = _t_0["cold"];
        return $owned$045rows$058leave_work_cold$(_header_0, run_loop($$$$047$$$047src$047ecs$047restored$045row$058attach$1260$(_stock_0)), run_loop($$$$047$$$047src$047ecs$047restored$045row$058attach$1261$(_recipe_0)), run_loop($$$$047$$$047src$047ecs$047restored$045row$058attach$1262$(_queue_0)), _cold_0);
      } else {
        const _inner_0 = _row_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $gameplay$058compose_body$1261$(_args_0, _ctx_0) {
  return $gameplay$058compose_id$1261$(run_loop($$$$047$$$047src$047ecs$047capabilities$058value_read$1265$(_ctx_0)));
}

function $$$$047$$$047src$047ecs$047restored$045row$058detach$1261$(_column_0, _id_0) {
  return $$$$047$$$047src$047ecs$047restored$045row$058captured$1261$(($$$$047$$$047src$047ecs$047captured$045column$058capture$1261$(_column_0, _id_0)));
}

function $$$$047$$$047src$047ecs$047restored$045row$058detach$1262$(_column_0, _id_0) {
  return $$$$047$$$047src$047ecs$047restored$045row$058captured$1262$(($$$$047$$$047src$047ecs$047captured$045column$058capture$1262$(_column_0, _id_0)));
}

function $$$$047$$$047src$047ecs$047compose$058and_join$1262$(_observed_0) {
  const _frame_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": _frame_0, "snd": false};
  } else {
    return $reference$045declarations$058structural_match$(_frame_0);
  }
}

function $reference$045declarations$058work_required$(_frame_0) {
  return $$$$047$$$047src$047ecs$047compose$058both$1261$(_frame_0);
}

function $$$$047$$$047src$047ecs$047column$058evacuate_start$1261$(_fuel_0, _id_0, _values_0, _rows_0) {
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = {$: "None"};
  return $$$$047$$$047src$047ecs$047column$058evacuate_pending$1261$(_fuel_0, _id_0, _rows_0, array_rmw(_values_0, _x_0, () => _x_1));
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepared_evacuated$1261$(_metadata_0, _capacity_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _rows_0 = _result_0["snd"];
  return {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": _rows_0, "past": {$: "../../src/ecs/column.HistoryNil"}}}};
}

function $$$$047$$$047src$047ecs$047column$058evacuate_start$1262$(_fuel_0, _id_0, _values_0, _rows_0) {
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = {$: "None"};
  return $$$$047$$$047src$047ecs$047column$058evacuate_pending$1262$(_fuel_0, _id_0, _rows_0, array_rmw(_values_0, _x_0, () => _x_1));
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepared_evacuated$1262$(_metadata_0, _capacity_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _rows_0 = _result_0["snd"];
  return {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": _rows_0, "past": {$: "../../src/ecs/column.HistoryNil"}}}};
}

function $$$$047$$$047src$047ecs$047column$058evacuate_start$1263$(_fuel_0, _id_0, _values_0, _rows_0) {
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = {$: "None"};
  return $$$$047$$$047src$047ecs$047column$058evacuate_pending$1263$(_fuel_0, _id_0, _rows_0, array_rmw(_values_0, _x_0, () => _x_1));
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepared_evacuated$1263$(_metadata_0, _capacity_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _rows_0 = _result_0["snd"];
  return {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": _rows_0, "past": {$: "../../src/ecs/column.HistoryNil"}}}};
}

function $$$$047$$$047src$047ecs$047column$058evacuate_start$1264$(_fuel_0, _id_0, _values_0, _rows_0) {
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = {$: "None"};
  return $$$$047$$$047src$047ecs$047column$058evacuate_pending$1264$(_fuel_0, _id_0, _rows_0, array_rmw(_values_0, _x_0, () => _x_1));
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepared_evacuated$1264$(_metadata_0, _capacity_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _rows_0 = _result_0["snd"];
  return {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": _rows_0, "past": {$: "../../src/ecs/column.HistoryNil"}}}};
}

function $observe$058row_locked$(_handle_0, _stock_0, _recipe_0, _queue_0, _enabled_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _locked_0 = _observed_0["snd"];
  const _x_0 = ($json$058locked$(_locked_0));
  const _x_1 = (_x_0 + "}");
  const _x_2 = ($json$058enabled$(_enabled_0));
  const _x_3 = (",\"locked\":" + _x_1);
  const _x_4 = (_x_2 + _x_3);
  const _x_5 = ($json$058queue$(_queue_0));
  const _x_6 = (",\"enabled\":" + _x_4);
  const _x_7 = (_x_5 + _x_6);
  const _x_8 = ($json$058recipe$(_recipe_0));
  const _x_9 = (",\"queue\":" + _x_7);
  const _x_10 = (_x_8 + _x_9);
  const _x_11 = ($json$058stock$(_stock_0));
  const _x_12 = (",\"recipe\":" + _x_10);
  const _x_13 = (_x_11 + _x_12);
  const _x_14 = ($U32$show$(($observe$058handle_id$(_handle_0))));
  const _x_15 = (",\"stock\":" + _x_13);
  const _x_16 = (_x_14 + _x_15);
  return {$: "Tuple", "fst": _world_0, "snd": ("{\"id\":" + _x_16)};
}

function $schema$058get_locked$(_world_0, _handle_0) {
  return $$$$047$$$047src$047ecs$047component$058get$1264$(($schema$058locked$()), _world_0, _handle_0);
}

function $$$$047$$$047src$047ecs$047component$058get$1263$(_family_0, _world_0, _handle_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _ns_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  return $$$$047$$$047src$047ecs$047component$058get_live_owned$1263$(_id_0, ($$$$047$$$047src$047ecs$047component$058get_live_read$(($Bool$and$((_namespace_0 === _ns_0), ($Bool$and$((0 < _id_0), (_id_0 < _nextId_0))))), _id_0, _live_0)), _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047src$047ecs$047component$058get_live_owned$1262$(_id_0, _observed_0, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": {$: "../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../../src/ecs/component.MissingEntity"}};
  } else {
    return $$$$047$$$047src$047ecs$047world$058with_store_finish$1262$(($$$$047$$$047src$047ecs$047component$058get_store$1262$(_id_0, ($schema$058take_queue$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
  }
}

function $$$$047$$$047src$047ecs$047component$058define$1262$(_name_0) {
  return {$: "../../src/ecs/component.Family", "name": _name_0};
}

function $$$$047$$$047src$047ecs$047world$058with_store_finish$1261$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047src$047ecs$047component$058get_store$1261$(_id_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047src$047ecs$047component$058get_projected$1261$(_rest_0, ($$$$047$$$047src$047ecs$047column$058view$1261$(_column_0, _id_0)));
}

function $schema$058take_recipe$(_store_0) {
  const _stock_0 = _store_0["stock"];
  const _recipe_0 = _store_0["recipe"];
  const _queue_0 = _store_0["queue"];
  const _enabled_0 = _store_0["enabled"];
  const _locked_0 = _store_0["locked"];
  return {$: "Tuple", "fst": {$: "schema.RecipeRest", "stock": _stock_0, "queue": _queue_0, "enabled": _enabled_0, "locked": _locked_0}, "snd": _recipe_0};
}

function $$$$047$$$047src$047ecs$047component$058get_projected$1260$(_rest_0, _observed_0) {
  const _column_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($schema$058put_stock$(_rest_0, _column_0)), "snd": ($$$$047$$$047src$047ecs$047component$058access$1260$(_value_0))};
}

function $$$$047$$$047src$047ecs$047column$058view$1260$(_column_0, _id_0) {
  if (_column_0.$ === "../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047src$047ecs$047column$058plain_view_sized$1260$(_id_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058prepared_view_state$1260$(_id_0, ($$$$047$$$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
  } else if (_column_0.$ === "../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058indexed_view_state$1260$(_id_0, ($$$$047$$$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058indexed_prepared_view_state$1260$(_id_0, ($$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
  }
}

function $$$$047$$$047src$047ecs$047column$058recover_selected_rows$($0, $1) {
  for (;;) {
    {
      const _rows_0 = $0;
      const _values_0 = $1;
      if (_rows_0.$ === "../../src/ecs/owner-handoff.HandoffNil") {
        return _values_0;
      } else {
        const _id_0 = _rows_0["id"];
        const _owner_0 = _rows_0["owner"];
        const _rest_0 = _rows_0["rest"];
        const _x_0 = ((_id_0 - 1) >>> 0);
        const _x_1 = {$: "Some", "value": _owner_0};
        $0 = _rest_0;
        $1 = (_values_0[_x_0 % _values_0.length] = _x_1, _values_0);
        continue;
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047column$058recover_past$1260$($0, $1) {
  for (;;) {
    {
      const _past_0 = $0;
      const _values_0 = $1;
      if (_past_0.$ === "../../src/ecs/column.HistoryNil") {
        return _values_0;
      } else {
        const _id_0 = _past_0["id"];
        const _owner_0 = _past_0["value"];
        const _rest_0 = _past_0["rest"];
        const _x_0 = ((_id_0 - 1) >>> 0);
        $0 = _rest_0;
        $1 = (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0);
        continue;
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047owned$045compose$058prepend$1261$(_value_0, _observed_0) {
  const _tx_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  const _outcome_0 = _t_0["fst"];
  const _values_0 = _t_0["snd"];
  return {$: "Tuple", "fst": _tx_0, "snd": {$: "Tuple", "fst": _outcome_0, "snd": {$: "Con", "head": _value_0, "tail": _values_0}}};
}

function $owned$045rows$058leave_duplicate_cold$($0, $1, $2) {
  for (;;) {
    {
      const _header_0 = $0;
      const _stock_0 = $1;
      const _cold_0 = $2;
      if (_cold_0.$ === "owned-rows.DuplicateCold") {
        const _t_0 = _cold_0["state"];
        const _highWater_0 = _t_0["highWater"];
        const _capacity_0 = _t_0["capacity"];
        const _depth_0 = _t_0["depth"];
        const _recipe_0 = _t_0["recipe"];
        const _queue_0 = _t_0["queue"];
        const _enabled_0 = _t_0["enabled"];
        const _locked_0 = _t_0["locked"];
        const _resource_0 = _t_0["resource"];
        const _events_0 = _t_0["events"];
        const _pending_0 = _t_0["pending"];
        const _registrations_0 = _t_0["registrations"];
        const _nextSystemId_0 = _t_0["nextSystemId"];
        const _undo_0 = _t_0["undo"];
        const _commands_0 = _t_0["commands"];
        const _txEvents_0 = _t_0["txEvents"];
        return $owned$045rows$058leave_duplicate_header$(_stock_0, _highWater_0, _capacity_0, _depth_0, _recipe_0, _queue_0, _enabled_0, _locked_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _undo_0, _commands_0, _txEvents_0, _header_0);
      } else {
        const _inner_0 = _cold_0["inner"];
        $0 = _header_0;
        $1 = _stock_0;
        $2 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047restored$045row$058attach$1260$(_cell_0) {
  if (_cell_0.$ === "../../src/ecs/restored-row.Taken") {
    const _owner_0 = _cell_0["owner"];
    const _stamp_0 = _cell_0["stamp"];
    const _dirty_0 = _cell_0["dirty"];
    const _restore_0 = _cell_0["restore"];
    return run_tail(_restore_0, {$: "../../src/ecs/captured-column.Slot", "owner": _owner_0, "stamp": _stamp_0, "dirty": _dirty_0});
  } else {
    const _column_0 = _cell_0["column"];
    return _column_0;
  }
}

function $gameplay$058duplicate_named$1261$(_observed_0) {
  const _ctx_0 = _observed_0["fst"];
  const _id_0 = _observed_0["snd"];
  return $gameplay$058duplicate_selected$1261$((_id_0 === 1), _ctx_0);
}

function $$$$047$$$047src$047ecs$047capabilities$058value_read$1267$(_ctx_0) {
  return run_tail(($$$$047$$$047src$047ecs$047capabilities$058value_read_field$1263$(($gameplay$058duplicate_id$1261$({$: "gameplay.DuplicateCaps", "a": ($owned$045rows$058write_duplicate_stock$()), "b": ($owned$045rows$058write_duplicate_stock$()), "r": ($owned$045rows$058read_duplicate_stock$()), "id": ($owned$045rows$058id_read_duplicate$())})))), _ctx_0);
}

function $$$$047$$$047src$047ecs$047restored$045row$058captured$1260$(_result_0) {
  if (_result_0.$ === "../../src/ecs/captured-column.Captured") {
    const _id_0 = _result_0["id"];
    const _owner_0 = _result_0["owner"];
    const _stamp_0 = _result_0["stamp"];
    const _restore_0 = _result_0["restore"];
    return {$: "../../src/ecs/restored-row.Taken", "id": _id_0, "owner": _owner_0, "stamp": _stamp_0, "dirty": false, "restore": _restore_0};
  } else {
    const _column_0 = _result_0["column"];
    return {$: "../../src/ecs/restored-row.Untaken", "column": _column_0};
  }
}

function $$$$047$$$047src$047ecs$047captured$045column$058capture$1260$(_column_0, _id_0) {
  if (_column_0.$ === "../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047src$047ecs$047captured$045column$058plain_sized$1260$(_id_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047captured$045column$058prepared_state$1260$(_id_0, ($$$$047$$$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
  } else if (_column_0.$ === "../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047captured$045column$058indexed_plain_state$1260$(_id_0, ($$$$047$$$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047captured$045column$058indexed_prepared_state$1260$(_id_0, ($$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
  }
}

function $$$$047$$$047src$047ecs$047compose$058selected_value$1263$(_mode_0, _value_0) {
  if (_mode_0.$ === "../../src/ecs/compose.Required") {
    if (_value_0.$ === "../../src/ecs/component.Found") {
      return true;
    } else {
      return false;
    }
  } else if (_mode_0.$ === "../../src/ecs/compose.Present") {
    if (_value_0.$ === "../../src/ecs/component.Found") {
      return true;
    } else {
      return false;
    }
  } else if (_mode_0.$ === "../../src/ecs/compose.Absent") {
    if (_value_0.$ === "../../src/ecs/component.ComponentAbsent") {
      return true;
    } else {
      return false;
    }
  } else {
    if (_value_0.$ === "../../src/ecs/component.Found") {
      return true;
    } else if (_value_0.$ === "../../src/ecs/component.ComponentAbsent") {
      return true;
    } else {
      return false;
    }
  }
}

function $$$$047$$$047src$047ecs$047compose$058read_join$1260$(_handle_0, _error_0, _cursor_0, _observed_0) {
  const _tx_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../src/ecs/compose.Frame", "tx": _tx_0, "handle": _handle_0, "error": _error_0, "cursor": _cursor_0}, "snd": _value_0};
}

function $$$$047$$$047src$047ecs$047component$058tx_get$1260$(_family_0, _tx_0, _handle_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047src$047ecs$047component$058tx_get_join$1260$(_undo_0, _commands_0, _events_0, ($$$$047$$$047src$047ecs$047component$058get$1260$(_family_0, _world_0, _handle_0)));
}

function $$$$047$$$047src$047ecs$047column$058evacuate_pending$1260$($0, $1, $2, $3) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _id_0 = $1;
      const _rows_0 = $2;
      const _observed_0 = $3;
      if (_fuel_0 === 0) {
        const _values_0 = _observed_0["fst"];
        const _t_0 = _observed_0["snd"];
        if (_t_0.$ === "None") {
          return {$: "Tuple", "fst": _values_0, "snd": _rows_0};
        } else {
          const _owner_0 = _t_0["value"];
          return {$: "Tuple", "fst": _values_0, "snd": {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rows_0}};
        }
      } else {
        const _rest_0 = (_fuel_0 - 1);
        const _values_1 = _observed_0["fst"];
        const _t_1 = _observed_0["snd"];
        if (_t_1.$ === "None") {
          const _nextId_0 = ((_id_0 - 1) >>> 0);
          const _x_0 = ((_nextId_0 - 1) >>> 0);
          const _x_1 = {$: "None"};
          $0 = _rest_0;
          $1 = _nextId_0;
          $2 = _rows_0;
          $3 = array_rmw(_values_1, _x_0, () => _x_1);
          continue;
        } else {
          const _owner_1 = _t_1["value"];
          const _nextId_1 = ((_id_0 - 1) >>> 0);
          const _x_2 = ((_nextId_1 - 1) >>> 0);
          const _x_3 = {$: "None"};
          $0 = _rest_0;
          $1 = _nextId_1;
          $2 = {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_1, "rest": _rows_0};
          $3 = array_rmw(_values_1, _x_2, () => _x_3);
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047owned$045optimized$045compose$058each_fields$1260$(_args_0, _world_0) {
  return $$$$047$$$047src$047ecs$047optimized$045compose$058recovered$1260$(($$$$047$$$047src$047ecs$047owned$045compose$058each_fields$1260$(_args_0, ($$$$047$$$047src$047ecs$047optimized$045compose$058map_store$1261$(_world_0)))));
}

function $String$order$(_a_0, _b_0) {
  return $Pair$snd$(($String$cmp$(_a_0, _b_0)));
}

function $$$$047$$$047src$047ecs$047world$058with_store_finish$12610$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $schema$058clear_inner$(_store_0, _id_0) {
  const _stock_0 = _store_0["stock"];
  const _recipe_0 = _store_0["recipe"];
  const _queue_0 = _store_0["queue"];
  const _enabled_0 = _store_0["enabled"];
  const _locked_0 = _store_0["locked"];
  return {$: "schema.Store", "stock": ($schema$058clear_column$1260$(_id_0, _stock_0)), "recipe": ($schema$058clear_column$1261$(_id_0, _recipe_0)), "queue": ($schema$058clear_column$1262$(_id_0, _queue_0)), "enabled": ($schema$058clear_column$1263$(_id_0, _enabled_0)), "locked": ($schema$058clear_column$1264$(_id_0, _locked_0))};
}

function $$$$047$$$047src$047ecs$047world$058set_live_checked$1260$(_allowed_0, _value_0, _world_0, _handle_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../src/ecs/world.Rejected", "error": {$: "../../src/ecs/world.MissingEntity"}}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    const _id_0 = _handle_0["id"];
    return {$: "Tuple", "fst": {$: "../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": (_live_0[_id_0 % _live_0.length] = _value_0, _live_0), "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../../src/ecs/world.Accepted"}};
  }
}

function $$$$047$$$047src$047ecs$047component$058replace_allowed$1264$(_checked_0, _handle_0, _incoming_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return {$: "../../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../src/ecs/world.MissingEntity"}};
  } else {
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047src$047ecs$047component$058replace_clock$1264$(_id_0, _incoming_0, ($$$$047$$$047src$047ecs$047world$058clock$1260$(_world_0)));
  }
}

function $$$$047$$$047src$047ecs$047component$058replace_allowed$1263$(_checked_0, _handle_0, _incoming_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return {$: "../../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../src/ecs/world.MissingEntity"}};
  } else {
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047src$047ecs$047component$058replace_clock$1263$(_id_0, _incoming_0, ($$$$047$$$047src$047ecs$047world$058clock$1260$(_world_0)));
  }
}

function $declarations$058retry$(_world_0, _args_0) {
  return $$$$047$$$047src$047ecs$047owned$045optimized$045compose$058each_fields$1265$(_args_0, _world_0);
}

function $$$$047$$$047src$047ecs$047world$058event_append$1260$(_left_0, _right_0) {
  return $$$$047$$$047src$047ecs$047world$058event_append_loop$1260$(($List$reverse$(_left_0)), _right_0);
}

function $schema$058populate_inner$(_world_0, _handle_0, _bundle_0) {
  const _stock_0 = _bundle_0["stock"];
  const _recipe_0 = _bundle_0["recipe"];
  const _queue_0 = _bundle_0["queue"];
  const _enabled_0 = _bundle_0["enabled"];
  const _locked_0 = _bundle_0["locked"];
  return $schema$058populate_locked$(($schema$058populate_enabled$(($schema$058populate_queue$(($schema$058populate_recipe$(($schema$058populate_stock$(_world_0, _handle_0, _stock_0)), _handle_0, _recipe_0)), _handle_0, _queue_0)), _handle_0, _enabled_0)), _handle_0, _locked_0);
}

function $driver$058advanced_outcome$(_result_0) {
  const _world_0 = _result_0["world"];
  const _t_0 = _result_0["outcome"];
  if (_t_0.$ === "../../src/ecs/transaction.Success") {
    const _values_0 = _result_0["values"];
    return {$: "../../src/ecs/system.Succeeded", "world": _world_0, "output": _values_0};
  } else {
    return {$: "../../src/ecs/system.Failed", "world": _world_0, "error": "UnexpectedLifecycleFailure"};
  }
}

function $declarations$058advanced$(_world_0, _cursor_0) {
  return $$$$047$$$047src$047ecs$047owned$045optimized$045compose$058each_fields_since$1260$({$: "Unit"}, _world_0, _cursor_0);
}

function $$$$047$$$047src$047ecs$047component$058replace_clock$1260$(_id_0, _incoming_0, _clocked_0) {
  const _world_0 = _clocked_0["fst"];
  const _tick_0 = _clocked_0["snd"];
  return $$$$047$$$047src$047ecs$047component$058replace_clock_checked$1260$((_tick_0 < 4294967295), _world_0, _id_0, ($$$$047$$$047src$047ecs$047component$058owner_present$1260$(_incoming_0)));
}

function $$$$047$$$047src$047ecs$047component$058replace_clock$1261$(_id_0, _incoming_0, _clocked_0) {
  const _world_0 = _clocked_0["fst"];
  const _tick_0 = _clocked_0["snd"];
  return $$$$047$$$047src$047ecs$047component$058replace_clock_checked$1261$((_tick_0 < 4294967295), _world_0, _id_0, ($$$$047$$$047src$047ecs$047component$058owner_present$1261$(_incoming_0)));
}

function $$$$047$$$047src$047ecs$047compose$058both$1263$(_frame_0) {
  return $$$$047$$$047src$047ecs$047compose$058and_join$1263$(($reference$045declarations$058match_enabled$1260$(_frame_0)));
}

function $reference$045declarations$058empty_body$1262$(_args_0, _ctx_0) {
  return $reference$045declarations$058empty_join$1261$(run_loop($$$$047$$$047src$047ecs$047capabilities$058value_read$1266$(_ctx_0)));
}

function $$$$047$$$047src$047ecs$047column$058recover_past$1261$($0, $1) {
  for (;;) {
    {
      const _past_0 = $0;
      const _values_0 = $1;
      if (_past_0.$ === "../../src/ecs/column.HistoryNil") {
        return _values_0;
      } else {
        const _id_0 = _past_0["id"];
        const _owner_0 = _past_0["value"];
        const _rest_0 = _past_0["rest"];
        const _x_0 = ((_id_0 - 1) >>> 0);
        $0 = _rest_0;
        $1 = (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0);
        continue;
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047column$058recover_past$1262$($0, $1) {
  for (;;) {
    {
      const _past_0 = $0;
      const _values_0 = $1;
      if (_past_0.$ === "../../src/ecs/column.HistoryNil") {
        return _values_0;
      } else {
        const _id_0 = _past_0["id"];
        const _owner_0 = _past_0["value"];
        const _rest_0 = _past_0["rest"];
        const _x_0 = ((_id_0 - 1) >>> 0);
        $0 = _rest_0;
        $1 = (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0);
        continue;
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047column$058recover_past$1263$($0, $1) {
  for (;;) {
    {
      const _past_0 = $0;
      const _values_0 = $1;
      if (_past_0.$ === "../../src/ecs/column.HistoryNil") {
        return _values_0;
      } else {
        const _id_0 = _past_0["id"];
        const _owner_0 = _past_0["value"];
        const _rest_0 = _past_0["rest"];
        const _x_0 = ((_id_0 - 1) >>> 0);
        $0 = _rest_0;
        $1 = (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0);
        continue;
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047column$058recover_past$1264$($0, $1) {
  for (;;) {
    {
      const _past_0 = $0;
      const _values_0 = $1;
      if (_past_0.$ === "../../src/ecs/column.HistoryNil") {
        return _values_0;
      } else {
        const _id_0 = _past_0["id"];
        const _owner_0 = _past_0["value"];
        const _rest_0 = _past_0["rest"];
        const _x_0 = ((_id_0 - 1) >>> 0);
        $0 = _rest_0;
        $1 = (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0);
        continue;
      }
    }
  }
}

function $owned$045rows$058leave_work_cold$($0, $1, $2, $3, $4) {
  for (;;) {
    {
      const _header_0 = $0;
      const _stock_0 = $1;
      const _recipe_0 = $2;
      const _queue_0 = $3;
      const _cold_0 = $4;
      if (_cold_0.$ === "owned-rows.WorkCold") {
        const _t_0 = _cold_0["state"];
        const _highWater_0 = _t_0["highWater"];
        const _capacity_0 = _t_0["capacity"];
        const _depth_0 = _t_0["depth"];
        const _enabled_0 = _t_0["enabled"];
        const _locked_0 = _t_0["locked"];
        const _resource_0 = _t_0["resource"];
        const _events_0 = _t_0["events"];
        const _pending_0 = _t_0["pending"];
        const _registrations_0 = _t_0["registrations"];
        const _nextSystemId_0 = _t_0["nextSystemId"];
        const _undo_0 = _t_0["undo"];
        const _commands_0 = _t_0["commands"];
        const _txEvents_0 = _t_0["txEvents"];
        return $owned$045rows$058leave_work_header$(_stock_0, _recipe_0, _queue_0, _highWater_0, _capacity_0, _depth_0, _enabled_0, _locked_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _undo_0, _commands_0, _txEvents_0, _header_0);
      } else {
        const _inner_0 = _cold_0["inner"];
        $0 = _header_0;
        $1 = _stock_0;
        $2 = _recipe_0;
        $3 = _queue_0;
        $4 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047restored$045row$058attach$1261$(_cell_0) {
  if (_cell_0.$ === "../../src/ecs/restored-row.Taken") {
    const _owner_0 = _cell_0["owner"];
    const _stamp_0 = _cell_0["stamp"];
    const _dirty_0 = _cell_0["dirty"];
    const _restore_0 = _cell_0["restore"];
    return run_tail(_restore_0, {$: "../../src/ecs/captured-column.Slot", "owner": _owner_0, "stamp": _stamp_0, "dirty": _dirty_0});
  } else {
    const _column_0 = _cell_0["column"];
    return _column_0;
  }
}

function $$$$047$$$047src$047ecs$047restored$045row$058attach$1262$(_cell_0) {
  if (_cell_0.$ === "../../src/ecs/restored-row.Taken") {
    const _owner_0 = _cell_0["owner"];
    const _stamp_0 = _cell_0["stamp"];
    const _dirty_0 = _cell_0["dirty"];
    const _restore_0 = _cell_0["restore"];
    return run_tail(_restore_0, {$: "../../src/ecs/captured-column.Slot", "owner": _owner_0, "stamp": _stamp_0, "dirty": _dirty_0});
  } else {
    const _column_0 = _cell_0["column"];
    return _column_0;
  }
}

function $gameplay$058compose_id$1261$(_observed_0) {
  const _ctx_0 = _observed_0["fst"];
  const _id_0 = _observed_0["snd"];
  return $gameplay$058compose_stock$1261$(_id_0, run_loop($$$$047$$$047src$047ecs$047capabilities$058get$1262$(_ctx_0)));
}

function $$$$047$$$047src$047ecs$047capabilities$058value_read$1265$(_ctx_0) {
  return run_tail(($$$$047$$$047src$047ecs$047capabilities$058value_read_field$1261$(($gameplay$058work_id$1261$({$: "gameplay.WorkCaps", "stock": ($owned$045rows$058write_work_stock$()), "recipe": ($owned$045rows$058read_work_recipe$()), "queue": ($owned$045rows$058read_work_queue$()), "id": ($owned$045rows$058id_read_work$())})))), _ctx_0);
}

function $$$$047$$$047src$047ecs$047restored$045row$058captured$1261$(_result_0) {
  if (_result_0.$ === "../../src/ecs/captured-column.Captured") {
    const _id_0 = _result_0["id"];
    const _owner_0 = _result_0["owner"];
    const _stamp_0 = _result_0["stamp"];
    const _restore_0 = _result_0["restore"];
    return {$: "../../src/ecs/restored-row.Taken", "id": _id_0, "owner": _owner_0, "stamp": _stamp_0, "dirty": false, "restore": _restore_0};
  } else {
    const _column_0 = _result_0["column"];
    return {$: "../../src/ecs/restored-row.Untaken", "column": _column_0};
  }
}

function $$$$047$$$047src$047ecs$047captured$045column$058capture$1261$(_column_0, _id_0) {
  if (_column_0.$ === "../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047src$047ecs$047captured$045column$058plain_sized$1261$(_id_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047captured$045column$058prepared_state$1261$(_id_0, ($$$$047$$$047src$047ecs$047column$058unseal$1261$(_carrier_0)));
  } else if (_column_0.$ === "../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047captured$045column$058indexed_plain_state$1261$(_id_0, ($$$$047$$$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047captured$045column$058indexed_prepared_state$1261$(_id_0, ($$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1261$(_carrier_2)));
  }
}

function $$$$047$$$047src$047ecs$047restored$045row$058captured$1262$(_result_0) {
  if (_result_0.$ === "../../src/ecs/captured-column.Captured") {
    const _id_0 = _result_0["id"];
    const _owner_0 = _result_0["owner"];
    const _stamp_0 = _result_0["stamp"];
    const _restore_0 = _result_0["restore"];
    return {$: "../../src/ecs/restored-row.Taken", "id": _id_0, "owner": _owner_0, "stamp": _stamp_0, "dirty": false, "restore": _restore_0};
  } else {
    const _column_0 = _result_0["column"];
    return {$: "../../src/ecs/restored-row.Untaken", "column": _column_0};
  }
}

function $$$$047$$$047src$047ecs$047captured$045column$058capture$1262$(_column_0, _id_0) {
  if (_column_0.$ === "../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047src$047ecs$047captured$045column$058plain_sized$1262$(_id_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047captured$045column$058prepared_state$1262$(_id_0, ($$$$047$$$047src$047ecs$047column$058unseal$1262$(_carrier_0)));
  } else if (_column_0.$ === "../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047captured$045column$058indexed_plain_state$1262$(_id_0, ($$$$047$$$047src$047ecs$047column$058indexed_unseal$1262$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047captured$045column$058indexed_prepared_state$1262$(_id_0, ($$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1262$(_carrier_2)));
  }
}

function $reference$045declarations$058structural_match$(_frame_0) {
  return $$$$047$$$047src$047ecs$047compose$058both$1260$(_frame_0);
}

function $$$$047$$$047src$047ecs$047compose$058both$1261$(_frame_0) {
  return $$$$047$$$047src$047ecs$047compose$058and_join$1261$(($reference$045declarations$058match_stock$1260$(_frame_0)));
}

function $$$$047$$$047src$047ecs$047column$058evacuate_pending$1261$($0, $1, $2, $3) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _id_0 = $1;
      const _rows_0 = $2;
      const _observed_0 = $3;
      if (_fuel_0 === 0) {
        const _values_0 = _observed_0["fst"];
        const _t_0 = _observed_0["snd"];
        if (_t_0.$ === "None") {
          return {$: "Tuple", "fst": _values_0, "snd": _rows_0};
        } else {
          const _owner_0 = _t_0["value"];
          return {$: "Tuple", "fst": _values_0, "snd": {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rows_0}};
        }
      } else {
        const _rest_0 = (_fuel_0 - 1);
        const _values_1 = _observed_0["fst"];
        const _t_1 = _observed_0["snd"];
        if (_t_1.$ === "None") {
          const _nextId_0 = ((_id_0 - 1) >>> 0);
          const _x_0 = ((_nextId_0 - 1) >>> 0);
          const _x_1 = {$: "None"};
          $0 = _rest_0;
          $1 = _nextId_0;
          $2 = _rows_0;
          $3 = array_rmw(_values_1, _x_0, () => _x_1);
          continue;
        } else {
          const _owner_1 = _t_1["value"];
          const _nextId_1 = ((_id_0 - 1) >>> 0);
          const _x_2 = ((_nextId_1 - 1) >>> 0);
          const _x_3 = {$: "None"};
          $0 = _rest_0;
          $1 = _nextId_1;
          $2 = {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_1, "rest": _rows_0};
          $3 = array_rmw(_values_1, _x_2, () => _x_3);
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047column$058evacuate_pending$1262$($0, $1, $2, $3) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _id_0 = $1;
      const _rows_0 = $2;
      const _observed_0 = $3;
      if (_fuel_0 === 0) {
        const _values_0 = _observed_0["fst"];
        const _t_0 = _observed_0["snd"];
        if (_t_0.$ === "None") {
          return {$: "Tuple", "fst": _values_0, "snd": _rows_0};
        } else {
          const _owner_0 = _t_0["value"];
          return {$: "Tuple", "fst": _values_0, "snd": {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rows_0}};
        }
      } else {
        const _rest_0 = (_fuel_0 - 1);
        const _values_1 = _observed_0["fst"];
        const _t_1 = _observed_0["snd"];
        if (_t_1.$ === "None") {
          const _nextId_0 = ((_id_0 - 1) >>> 0);
          const _x_0 = ((_nextId_0 - 1) >>> 0);
          const _x_1 = {$: "None"};
          $0 = _rest_0;
          $1 = _nextId_0;
          $2 = _rows_0;
          $3 = array_rmw(_values_1, _x_0, () => _x_1);
          continue;
        } else {
          const _owner_1 = _t_1["value"];
          const _nextId_1 = ((_id_0 - 1) >>> 0);
          const _x_2 = ((_nextId_1 - 1) >>> 0);
          const _x_3 = {$: "None"};
          $0 = _rest_0;
          $1 = _nextId_1;
          $2 = {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_1, "rest": _rows_0};
          $3 = array_rmw(_values_1, _x_2, () => _x_3);
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047column$058evacuate_pending$1263$($0, $1, $2, $3) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _id_0 = $1;
      const _rows_0 = $2;
      const _observed_0 = $3;
      if (_fuel_0 === 0) {
        const _values_0 = _observed_0["fst"];
        const _t_0 = _observed_0["snd"];
        if (_t_0.$ === "None") {
          return {$: "Tuple", "fst": _values_0, "snd": _rows_0};
        } else {
          const _owner_0 = _t_0["value"];
          return {$: "Tuple", "fst": _values_0, "snd": {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rows_0}};
        }
      } else {
        const _rest_0 = (_fuel_0 - 1);
        const _values_1 = _observed_0["fst"];
        const _t_1 = _observed_0["snd"];
        if (_t_1.$ === "None") {
          const _nextId_0 = ((_id_0 - 1) >>> 0);
          const _x_0 = ((_nextId_0 - 1) >>> 0);
          const _x_1 = {$: "None"};
          $0 = _rest_0;
          $1 = _nextId_0;
          $2 = _rows_0;
          $3 = array_rmw(_values_1, _x_0, () => _x_1);
          continue;
        } else {
          const _owner_1 = _t_1["value"];
          const _nextId_1 = ((_id_0 - 1) >>> 0);
          const _x_2 = ((_nextId_1 - 1) >>> 0);
          const _x_3 = {$: "None"};
          $0 = _rest_0;
          $1 = _nextId_1;
          $2 = {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_1, "rest": _rows_0};
          $3 = array_rmw(_values_1, _x_2, () => _x_3);
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047column$058evacuate_pending$1264$($0, $1, $2, $3) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _id_0 = $1;
      const _rows_0 = $2;
      const _observed_0 = $3;
      if (_fuel_0 === 0) {
        const _values_0 = _observed_0["fst"];
        const _t_0 = _observed_0["snd"];
        if (_t_0.$ === "None") {
          return {$: "Tuple", "fst": _values_0, "snd": _rows_0};
        } else {
          const _owner_0 = _t_0["value"];
          return {$: "Tuple", "fst": _values_0, "snd": {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rows_0}};
        }
      } else {
        const _rest_0 = (_fuel_0 - 1);
        const _values_1 = _observed_0["fst"];
        const _t_1 = _observed_0["snd"];
        if (_t_1.$ === "None") {
          const _nextId_0 = ((_id_0 - 1) >>> 0);
          const _x_0 = ((_nextId_0 - 1) >>> 0);
          const _x_1 = {$: "None"};
          $0 = _rest_0;
          $1 = _nextId_0;
          $2 = _rows_0;
          $3 = array_rmw(_values_1, _x_0, () => _x_1);
          continue;
        } else {
          const _owner_1 = _t_1["value"];
          const _nextId_1 = ((_id_0 - 1) >>> 0);
          const _x_2 = ((_nextId_1 - 1) >>> 0);
          const _x_3 = {$: "None"};
          $0 = _rest_0;
          $1 = _nextId_1;
          $2 = {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_1, "rest": _rows_0};
          $3 = array_rmw(_values_1, _x_2, () => _x_3);
          continue;
        }
      }
    }
  }
}

function $observe$058handle_id$(_handle_0) {
  const _id_0 = _handle_0["id"];
  return _id_0;
}

function $json$058stock$(_value_0) {
  if (_value_0.$ === "../../src/ecs/component.Found") {
    const _t_0 = _value_0["value"];
    const _value_1 = _t_0["value"];
    const _owned_0 = _t_0["owned"];
    const _x_0 = ($json$058numbers$(_owned_0));
    const _x_1 = (_x_0 + "}");
    const _x_2 = ($U32$show$(_value_1));
    const _x_3 = (",\"owned\":" + _x_1);
    const _x_4 = (_x_2 + _x_3);
    return ("{\"value\":" + _x_4);
  } else if (_value_0.$ === "../../src/ecs/component.ComponentAbsent") {
    return "null";
  } else {
    return "{\"missingEntity\":true}";
  }
}

function $json$058recipe$(_value_0) {
  if (_value_0.$ === "../../src/ecs/component.Found") {
    const _t_0 = _value_0["value"];
    const _value_1 = _t_0["value"];
    const _owned_0 = _t_0["owned"];
    const _x_0 = ($json$058numbers$(_owned_0));
    const _x_1 = (_x_0 + "}");
    const _x_2 = ($U32$show$(_value_1));
    const _x_3 = (",\"owned\":" + _x_1);
    const _x_4 = (_x_2 + _x_3);
    return ("{\"value\":" + _x_4);
  } else if (_value_0.$ === "../../src/ecs/component.ComponentAbsent") {
    return "null";
  } else {
    return "{\"missingEntity\":true}";
  }
}

function $json$058queue$(_value_0) {
  if (_value_0.$ === "../../src/ecs/component.Found") {
    const _t_0 = _value_0["value"];
    const _value_1 = _t_0["value"];
    const _owned_0 = _t_0["owned"];
    const _x_0 = ($json$058numbers$(_owned_0));
    const _x_1 = (_x_0 + "}");
    const _x_2 = ($U32$show$(_value_1));
    const _x_3 = (",\"owned\":" + _x_1);
    const _x_4 = (_x_2 + _x_3);
    return ("{\"value\":" + _x_4);
  } else if (_value_0.$ === "../../src/ecs/component.ComponentAbsent") {
    return "null";
  } else {
    return "{\"missingEntity\":true}";
  }
}

function $json$058enabled$(_value_0) {
  if (_value_0.$ === "../../src/ecs/component.Found") {
    return "{}";
  } else if (_value_0.$ === "../../src/ecs/component.ComponentAbsent") {
    return "null";
  } else {
    return "{\"missingEntity\":true}";
  }
}

function $json$058locked$(_value_0) {
  if (_value_0.$ === "../../src/ecs/component.Found") {
    return "{}";
  } else if (_value_0.$ === "../../src/ecs/component.ComponentAbsent") {
    return "null";
  } else {
    return "{\"missingEntity\":true}";
  }
}

function $$$$047$$$047src$047ecs$047component$058get$1264$(_family_0, _world_0, _handle_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _ns_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  return $$$$047$$$047src$047ecs$047component$058get_live_owned$1264$(_id_0, ($$$$047$$$047src$047ecs$047component$058get_live_read$(($Bool$and$((_namespace_0 === _ns_0), ($Bool$and$((0 < _id_0), (_id_0 < _nextId_0))))), _id_0, _live_0)), _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047src$047ecs$047component$058get_live_owned$1263$(_id_0, _observed_0, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": {$: "../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../../src/ecs/component.MissingEntity"}};
  } else {
    return $$$$047$$$047src$047ecs$047world$058with_store_finish$1263$(($$$$047$$$047src$047ecs$047component$058get_store$1263$(_id_0, ($schema$058take_enabled$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
  }
}

function $$$$047$$$047src$047ecs$047world$058with_store_finish$1262$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047src$047ecs$047component$058get_store$1262$(_id_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047src$047ecs$047component$058get_projected$1262$(_rest_0, ($$$$047$$$047src$047ecs$047column$058view$1262$(_column_0, _id_0)));
}

function $schema$058take_queue$(_store_0) {
  const _stock_0 = _store_0["stock"];
  const _recipe_0 = _store_0["recipe"];
  const _queue_0 = _store_0["queue"];
  const _enabled_0 = _store_0["enabled"];
  const _locked_0 = _store_0["locked"];
  return {$: "Tuple", "fst": {$: "schema.QueueRest", "stock": _stock_0, "recipe": _recipe_0, "enabled": _enabled_0, "locked": _locked_0}, "snd": _queue_0};
}

function $$$$047$$$047src$047ecs$047component$058get_projected$1261$(_rest_0, _observed_0) {
  const _column_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($schema$058put_recipe$(_rest_0, _column_0)), "snd": ($$$$047$$$047src$047ecs$047component$058access$1261$(_value_0))};
}

function $$$$047$$$047src$047ecs$047column$058view$1261$(_column_0, _id_0) {
  if (_column_0.$ === "../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047src$047ecs$047column$058plain_view_sized$1261$(_id_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058prepared_view_state$1261$(_id_0, ($$$$047$$$047src$047ecs$047column$058unseal$1261$(_carrier_0)));
  } else if (_column_0.$ === "../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058indexed_view_state$1261$(_id_0, ($$$$047$$$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058indexed_prepared_view_state$1261$(_id_0, ($$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1261$(_carrier_2)));
  }
}

function $schema$058put_stock$(_rest_0, _column_0) {
  const _recipe_0 = _rest_0["recipe"];
  const _queue_0 = _rest_0["queue"];
  const _enabled_0 = _rest_0["enabled"];
  const _locked_0 = _rest_0["locked"];
  return {$: "schema.Store", "stock": _column_0, "recipe": _recipe_0, "queue": _queue_0, "enabled": _enabled_0, "locked": _locked_0};
}

function $$$$047$$$047src$047ecs$047component$058access$1260$(_value_0) {
  if (_value_0.$ === "None") {
    return {$: "../../src/ecs/component.ComponentAbsent"};
  } else {
    const _value_1 = _value_0["value"];
    return {$: "../../src/ecs/component.Found", "value": _value_1};
  }
}

function $$$$047$$$047src$047ecs$047column$058plain_view_sized$1260$(_id_0, _stamps_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047src$047ecs$047column$058plain_view_checked$1260$(_values_0, _stamps_0, _id_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047src$047ecs$047column$058prepared_view_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047src$047ecs$047column$058prepared_view_checked$1260$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0));
}

function $$$$047$$$047src$047ecs$047column$058indexed_view_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047src$047ecs$047column$058indexed_view_sized$1260$(_id_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepared_view_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047src$047ecs$047column$058indexed_prepared_view_checked$1260$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0));
}

function $owned$045rows$058leave_duplicate_header$(_stock_0, _highWater_0, _capacity_0, _depth_0, _recipe_0, _queue_0, _enabled_0, _locked_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _undo_0, _commands_0, _txEvents_0, _header_0) {
  const _namespace_0 = _header_0["namespace"];
  const _nextId_0 = _header_0["nextId"];
  const _live_0 = _header_0["live"];
  const _handle_0 = _header_0["handle"];
  const _clock_0 = _header_0["clock"];
  const _error_0 = _header_0["error"];
  const _cursor_0 = _header_0["cursor"];
  return {$: "../../src/ecs/compose.Frame", "tx": {$: "../../src/ecs/transaction.Tx", "world": {$: "../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": {$: "schema.Store", "stock": _stock_0, "recipe": _recipe_0, "queue": _queue_0, "enabled": _enabled_0, "locked": _locked_0}, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "undo": _undo_0, "commands": _commands_0, "events": _txEvents_0}, "handle": _handle_0, "error": _error_0, "cursor": _cursor_0};
}

function $gameplay$058duplicate_selected$1261$(_selected_0, _ctx_0) {
  if (!_selected_0) {
    return {$: "Tuple", "fst": _ctx_0, "snd": {$: "Tuple", "fst": {$: "../../src/ecs/transaction.Success"}, "snd": ""}};
  } else {
    return $gameplay$058duplicate_after_a$1261$(run_loop($$$$047$$$047src$047ecs$047capabilities$058get$1263$(run_loop($$$$047$$$047src$047ecs$047capabilities$058set$1268$(_ctx_0, ($schema$058stock_payload$(70)))))));
  }
}

function $$$$047$$$047src$047ecs$047capabilities$058value_read_field$1263$(_cap_0) {
  const _get_0 = _cap_0["get"];
  return _get_0;
}

function $gameplay$058duplicate_id$1261$(_caps_0) {
  const _id_0 = _caps_0["id"];
  return _id_0;
}

function $owned$045rows$058write_duplicate_stock$() {
  return {$: "../../src/ecs/capabilities.Write", "get": run_clo((_x_0) => {
  return $owned$045rows$058get_duplicate_stock$(_x_0);
}), "set": run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $owned$045rows$058set_duplicate_stock$(_x_1, _x_2);
});
})};
}

function $owned$045rows$058read_duplicate_stock$() {
  return {$: "../../src/ecs/capabilities.Read", "get": run_clo((_x_0) => {
  return $owned$045rows$058get_duplicate_stock$(_x_0);
})};
}

function $owned$045rows$058id_read_duplicate$() {
  return {$: "../../src/ecs/capabilities.ValueRead", "get": run_clo((_x_0) => {
  return $owned$045rows$058id_duplicate$(_x_0);
})};
}

function $$$$047$$$047src$047ecs$047captured$045column$058plain_sized$1260$(_id_0, _stamps_0, _sized_0) {
  const _values_0 = _sized_0["fst"];
  const _size_0 = _sized_0["snd"];
  return $$$$047$$$047src$047ecs$047captured$045column$058plain_checked$1260$(_id_0, _stamps_0, _values_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047src$047ecs$047captured$045column$058prepared_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047src$047ecs$047captured$045column$058prepared_checked$1260$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0), (_id_0 < _current_0));
}

function $$$$047$$$047src$047ecs$047captured$045column$058indexed_plain_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047src$047ecs$047captured$045column$058indexed_plain_sized$1260$(_id_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047src$047ecs$047captured$045column$058indexed_prepared_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047src$047ecs$047captured$045column$058indexed_prepared_checked$1260$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0), (_id_0 < _current_0));
}

function $$$$047$$$047src$047ecs$047component$058tx_get_join$1260$(_undo_0, _commands_0, _events_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "snd": _value_0};
}

function $$$$047$$$047src$047ecs$047optimized$045compose$058recovered$1260$(_result_0) {
  const _world_0 = _result_0["world"];
  const _outcome_0 = _result_0["outcome"];
  const _values_0 = _result_0["values"];
  return {$: "../../src/ecs/compose.Executed", "world": ($$$$047$$$047src$047ecs$047optimized$045compose$058map_store$1260$(_world_0)), "outcome": _outcome_0, "values": _values_0};
}

function $$$$047$$$047src$047ecs$047owned$045compose$058each_fields$1260$(_args_0, _world_0) {
  return $$$$047$$$047src$047ecs$047owned$045compose$058reserved_fields$1260$(_args_0, 0, ($$$$047$$$047src$047ecs$047world$058handles$1260$(_world_0)));
}

function $Pair$snd$(_p_0) {
  const _b_0 = _p_0["snd"];
  return _b_0;
}

function $String$cmp$(_a_0, _b_0) {
  if (_a_0 === "") {
    if (_b_0 === "") {
      return {$: "Tuple", "fst": {$: "Tuple", "fst": "", "snd": ""}, "snd": {$: "EQ"}};
    } else {
      const _h_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(0, 2) : _b_0[0]);
      const _t_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(2) : _b_0.slice(1));
      return {$: "Tuple", "fst": {$: "Tuple", "fst": "", "snd": (_h_0 + _t_0)}, "snd": {$: "LT"}};
    }
  } else {
    const _h_1 = (_a_0.codePointAt(0) > 0xFFFF ? _a_0.slice(0, 2) : _a_0[0]);
    const _t_1 = (_a_0.codePointAt(0) > 0xFFFF ? _a_0.slice(2) : _a_0.slice(1));
    if (_b_0 === "") {
      return {$: "Tuple", "fst": {$: "Tuple", "fst": (_h_1 + _t_1), "snd": ""}, "snd": {$: "GT"}};
    } else {
      const _h2_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(0, 2) : _b_0[0]);
      const _t2_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(2) : _b_0.slice(1));
      return $String$cmp$fin$(_t_1, _t2_0, ($Char$cmp$(_h_1, _h2_0)));
    }
  }
}

function $schema$058clear_column$1260$(_id_0, _column_0) {
  return $schema$058clear_column_result$1260$(($$$$047$$$047src$047ecs$047column$058clear$1260$(_column_0, _id_0)));
}

function $schema$058clear_column$1261$(_id_0, _column_0) {
  return $schema$058clear_column_result$1261$(($$$$047$$$047src$047ecs$047column$058clear$1261$(_column_0, _id_0)));
}

function $schema$058clear_column$1262$(_id_0, _column_0) {
  return $schema$058clear_column_result$1262$(($$$$047$$$047src$047ecs$047column$058clear$1262$(_column_0, _id_0)));
}

function $schema$058clear_column$1263$(_id_0, _column_0) {
  return $schema$058clear_column_result$1263$(($$$$047$$$047src$047ecs$047column$058clear$1263$(_column_0, _id_0)));
}

function $schema$058clear_column$1264$(_id_0, _column_0) {
  return $schema$058clear_column_result$1264$(($$$$047$$$047src$047ecs$047column$058clear$1264$(_column_0, _id_0)));
}

function $$$$047$$$047src$047ecs$047component$058replace_clock$1264$(_id_0, _incoming_0, _clocked_0) {
  const _world_0 = _clocked_0["fst"];
  const _tick_0 = _clocked_0["snd"];
  return $$$$047$$$047src$047ecs$047component$058replace_clock_checked$1264$((_tick_0 < 4294967295), _world_0, _id_0, ($$$$047$$$047src$047ecs$047component$058owner_present$1264$(_incoming_0)));
}

function $$$$047$$$047src$047ecs$047component$058replace_clock$1263$(_id_0, _incoming_0, _clocked_0) {
  const _world_0 = _clocked_0["fst"];
  const _tick_0 = _clocked_0["snd"];
  return $$$$047$$$047src$047ecs$047component$058replace_clock_checked$1263$((_tick_0 < 4294967295), _world_0, _id_0, ($$$$047$$$047src$047ecs$047component$058owner_present$1263$(_incoming_0)));
}

function $$$$047$$$047src$047ecs$047owned$045optimized$045compose$058each_fields$1265$(_args_0, _world_0) {
  return $$$$047$$$047src$047ecs$047optimized$045compose$058recovered$1260$(($$$$047$$$047src$047ecs$047owned$045compose$058each_fields$1265$(_args_0, ($$$$047$$$047src$047ecs$047optimized$045compose$058map_store$1261$(_world_0)))));
}

function $$$$047$$$047src$047ecs$047world$058event_append_loop$1260$($0, $1) {
  for (;;) {
    {
      const _reversed_0 = $0;
      const _output_0 = $1;
      if (_reversed_0.$ === "Nil") {
        return _output_0;
      } else {
        const _head_0 = _reversed_0["head"];
        const _rest_0 = _reversed_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _output_0};
        continue;
      }
    }
  }
}

function $schema$058populate_locked$(_world_0, _handle_0, _incoming_0) {
  return $schema$058replaced$1264$(($$$$047$$$047src$047ecs$047component$058structural_replace$1264$(($schema$058locked$()), _world_0, _handle_0, _incoming_0)));
}

function $schema$058populate_enabled$(_world_0, _handle_0, _incoming_0) {
  return $schema$058replaced$1263$(($$$$047$$$047src$047ecs$047component$058structural_replace$1263$(($schema$058enabled$()), _world_0, _handle_0, _incoming_0)));
}

function $schema$058populate_queue$(_world_0, _handle_0, _incoming_0) {
  return $schema$058replaced$1262$(($$$$047$$$047src$047ecs$047component$058structural_replace$1262$(($schema$058queue$()), _world_0, _handle_0, _incoming_0)));
}

function $schema$058populate_recipe$(_world_0, _handle_0, _incoming_0) {
  return $schema$058replaced$1261$(($$$$047$$$047src$047ecs$047component$058structural_replace$1261$(($schema$058recipe$()), _world_0, _handle_0, _incoming_0)));
}

function $schema$058populate_stock$(_world_0, _handle_0, _incoming_0) {
  return $schema$058replaced$1260$(($$$$047$$$047src$047ecs$047component$058structural_replace$1260$(($schema$058stock$()), _world_0, _handle_0, _incoming_0)));
}

function $$$$047$$$047src$047ecs$047owned$045optimized$045compose$058each_fields_since$1260$(_args_0, _world_0, _cursor_0) {
  return $$$$047$$$047src$047ecs$047optimized$045compose$058recovered$1265$(($$$$047$$$047src$047ecs$047owned$045compose$058each_fields_since$1260$(_args_0, ($$$$047$$$047src$047ecs$047optimized$045compose$058map_store$1268$(_world_0)), _cursor_0)));
}

function $$$$047$$$047src$047ecs$047component$058replace_clock_checked$1260$(_allowed_0, _world_0, _id_0, _observed_0) {
  if (!_allowed_0) {
    const _incoming_0 = _observed_0["fst"];
    return {$: "../../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../src/ecs/world.CapacityExceeded"}};
  } else {
    const _incoming_1 = _observed_0["fst"];
    const _present_0 = _observed_0["snd"];
    return $$$$047$$$047src$047ecs$047component$058replace_clock_advanced$1260$(_id_0, _present_0, _incoming_1, ($$$$047$$$047src$047ecs$047world$058advance_clock$1260$(_world_0)));
  }
}

function $$$$047$$$047src$047ecs$047component$058owner_present$1260$(_owner_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "None"}, "snd": false};
  } else {
    const _owner_1 = _owner_0["value"];
    return {$: "Tuple", "fst": {$: "Some", "value": _owner_1}, "snd": true};
  }
}

function $$$$047$$$047src$047ecs$047component$058replace_clock_checked$1261$(_allowed_0, _world_0, _id_0, _observed_0) {
  if (!_allowed_0) {
    const _incoming_0 = _observed_0["fst"];
    return {$: "../../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../src/ecs/world.CapacityExceeded"}};
  } else {
    const _incoming_1 = _observed_0["fst"];
    const _present_0 = _observed_0["snd"];
    return $$$$047$$$047src$047ecs$047component$058replace_clock_advanced$1261$(_id_0, _present_0, _incoming_1, ($$$$047$$$047src$047ecs$047world$058advance_clock$1260$(_world_0)));
  }
}

function $$$$047$$$047src$047ecs$047component$058owner_present$1261$(_owner_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "None"}, "snd": false};
  } else {
    const _owner_1 = _owner_0["value"];
    return {$: "Tuple", "fst": {$: "Some", "value": _owner_1}, "snd": true};
  }
}

function $$$$047$$$047src$047ecs$047compose$058and_join$1263$(_observed_0) {
  const _frame_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": _frame_0, "snd": false};
  } else {
    return $reference$045declarations$058match_enabled$1261$(_frame_0);
  }
}

function $reference$045declarations$058match_enabled$1260$(_frame_0) {
  return $$$$047$$$047src$047ecs$047compose$058family_match$1261$(_frame_0);
}

function $reference$045declarations$058empty_join$1261$(_observed_0) {
  const _ctx_0 = _observed_0["fst"];
  const _id_0 = _observed_0["snd"];
  const _x_0 = ($U32$show$(_id_0));
  const _x_1 = (_x_0 + ",\"data\":{}}");
  return {$: "Tuple", "fst": _ctx_0, "snd": {$: "Tuple", "fst": {$: "../../src/ecs/transaction.Success"}, "snd": ("{\"id\":" + _x_1)}};
}

function $$$$047$$$047src$047ecs$047capabilities$058value_read$1266$(_ctx_0) {
  return run_tail(($$$$047$$$047src$047ecs$047capabilities$058value_read_field$1262$(($reference$045declarations$058id_read$()))), _ctx_0);
}

function $owned$045rows$058leave_work_header$(_stock_0, _recipe_0, _queue_0, _highWater_0, _capacity_0, _depth_0, _enabled_0, _locked_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _undo_0, _commands_0, _txEvents_0, _header_0) {
  const _namespace_0 = _header_0["namespace"];
  const _nextId_0 = _header_0["nextId"];
  const _live_0 = _header_0["live"];
  const _handle_0 = _header_0["handle"];
  const _clock_0 = _header_0["clock"];
  const _error_0 = _header_0["error"];
  const _cursor_0 = _header_0["cursor"];
  return {$: "../../src/ecs/compose.Frame", "tx": {$: "../../src/ecs/transaction.Tx", "world": {$: "../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": {$: "schema.Store", "stock": _stock_0, "recipe": _recipe_0, "queue": _queue_0, "enabled": _enabled_0, "locked": _locked_0}, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "undo": _undo_0, "commands": _commands_0, "events": _txEvents_0}, "handle": _handle_0, "error": _error_0, "cursor": _cursor_0};
}

function $gameplay$058compose_stock$1261$(_id_0, _observed_0) {
  const _ctx_0 = _observed_0["fst"];
  const _stock_0 = _observed_0["snd"];
  return $gameplay$058compose_recipe$1261$(_id_0, _stock_0, run_loop($$$$047$$$047src$047ecs$047capabilities$058read$1266$(_ctx_0)));
}

function $$$$047$$$047src$047ecs$047capabilities$058get$1262$(_ctx_0) {
  return run_tail(($$$$047$$$047src$047ecs$047capabilities$058write_read_field$1261$(($gameplay$058work_stock$1261$({$: "gameplay.WorkCaps", "stock": ($owned$045rows$058write_work_stock$()), "recipe": ($owned$045rows$058read_work_recipe$()), "queue": ($owned$045rows$058read_work_queue$()), "id": ($owned$045rows$058id_read_work$())})))), _ctx_0);
}

function $$$$047$$$047src$047ecs$047capabilities$058value_read_field$1261$(_cap_0) {
  const _get_0 = _cap_0["get"];
  return _get_0;
}

function $gameplay$058work_id$1261$(_caps_0) {
  const _id_0 = _caps_0["id"];
  return _id_0;
}

function $owned$045rows$058write_work_stock$() {
  return {$: "../../src/ecs/capabilities.Write", "get": run_clo((_x_0) => {
  return $owned$045rows$058get_work_stock$(_x_0);
}), "set": run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $owned$045rows$058set_work_stock$(_x_1, _x_2);
});
})};
}

function $owned$045rows$058read_work_recipe$() {
  return {$: "../../src/ecs/capabilities.Read", "get": run_clo((_x_0) => {
  return $owned$045rows$058get_work_recipe$(_x_0);
})};
}

function $owned$045rows$058read_work_queue$() {
  return {$: "../../src/ecs/capabilities.Read", "get": run_clo((_x_0) => {
  return $owned$045rows$058get_work_queue$(_x_0);
})};
}

function $owned$045rows$058id_read_work$() {
  return {$: "../../src/ecs/capabilities.ValueRead", "get": run_clo((_x_0) => {
  return $owned$045rows$058id_work$(_x_0);
})};
}

function $$$$047$$$047src$047ecs$047captured$045column$058plain_sized$1261$(_id_0, _stamps_0, _sized_0) {
  const _values_0 = _sized_0["fst"];
  const _size_0 = _sized_0["snd"];
  return $$$$047$$$047src$047ecs$047captured$045column$058plain_checked$1261$(_id_0, _stamps_0, _values_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047src$047ecs$047captured$045column$058prepared_state$1261$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047src$047ecs$047captured$045column$058prepared_checked$1261$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0), (_id_0 < _current_0));
}

function $$$$047$$$047src$047ecs$047captured$045column$058indexed_plain_state$1261$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047src$047ecs$047captured$045column$058indexed_plain_sized$1261$(_id_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047src$047ecs$047captured$045column$058indexed_prepared_state$1261$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047src$047ecs$047captured$045column$058indexed_prepared_checked$1261$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0), (_id_0 < _current_0));
}

function $$$$047$$$047src$047ecs$047captured$045column$058plain_sized$1262$(_id_0, _stamps_0, _sized_0) {
  const _values_0 = _sized_0["fst"];
  const _size_0 = _sized_0["snd"];
  return $$$$047$$$047src$047ecs$047captured$045column$058plain_checked$1262$(_id_0, _stamps_0, _values_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047src$047ecs$047captured$045column$058prepared_state$1262$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047src$047ecs$047captured$045column$058prepared_checked$1262$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0), (_id_0 < _current_0));
}

function $$$$047$$$047src$047ecs$047captured$045column$058indexed_plain_state$1262$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047src$047ecs$047captured$045column$058indexed_plain_sized$1262$(_id_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047src$047ecs$047captured$045column$058indexed_prepared_state$1262$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047src$047ecs$047captured$045column$058indexed_prepared_checked$1262$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0), (_id_0 < _current_0));
}

function $$$$047$$$047src$047ecs$047compose$058both$1260$(_frame_0) {
  return $$$$047$$$047src$047ecs$047compose$058and_join$1260$(($reference$045declarations$058match_enabled$1260$(_frame_0)));
}

function $$$$047$$$047src$047ecs$047compose$058and_join$1261$(_observed_0) {
  const _frame_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": _frame_0, "snd": false};
  } else {
    return $reference$045declarations$058match_recipe$1260$(_frame_0);
  }
}

function $$$$047$$$047src$047ecs$047component$058get_live_owned$1264$(_id_0, _observed_0, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": {$: "../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../../src/ecs/component.MissingEntity"}};
  } else {
    return $$$$047$$$047src$047ecs$047world$058with_store_finish$1264$(($$$$047$$$047src$047ecs$047component$058get_store$1264$(_id_0, ($schema$058take_locked$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
  }
}

function $$$$047$$$047src$047ecs$047world$058with_store_finish$1263$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047src$047ecs$047component$058get_store$1263$(_id_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047src$047ecs$047component$058get_projected$1263$(_rest_0, ($$$$047$$$047src$047ecs$047column$058view$1263$(_column_0, _id_0)));
}

function $schema$058take_enabled$(_store_0) {
  const _stock_0 = _store_0["stock"];
  const _recipe_0 = _store_0["recipe"];
  const _queue_0 = _store_0["queue"];
  const _enabled_0 = _store_0["enabled"];
  const _locked_0 = _store_0["locked"];
  return {$: "Tuple", "fst": {$: "schema.EnabledRest", "stock": _stock_0, "recipe": _recipe_0, "queue": _queue_0, "locked": _locked_0}, "snd": _enabled_0};
}

function $$$$047$$$047src$047ecs$047component$058get_projected$1262$(_rest_0, _observed_0) {
  const _column_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($schema$058put_queue$(_rest_0, _column_0)), "snd": ($$$$047$$$047src$047ecs$047component$058access$1262$(_value_0))};
}

function $$$$047$$$047src$047ecs$047column$058view$1262$(_column_0, _id_0) {
  if (_column_0.$ === "../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047src$047ecs$047column$058plain_view_sized$1262$(_id_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058prepared_view_state$1262$(_id_0, ($$$$047$$$047src$047ecs$047column$058unseal$1262$(_carrier_0)));
  } else if (_column_0.$ === "../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058indexed_view_state$1262$(_id_0, ($$$$047$$$047src$047ecs$047column$058indexed_unseal$1262$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058indexed_prepared_view_state$1262$(_id_0, ($$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1262$(_carrier_2)));
  }
}

function $schema$058put_recipe$(_rest_0, _column_0) {
  const _stock_0 = _rest_0["stock"];
  const _queue_0 = _rest_0["queue"];
  const _enabled_0 = _rest_0["enabled"];
  const _locked_0 = _rest_0["locked"];
  return {$: "schema.Store", "stock": _stock_0, "recipe": _column_0, "queue": _queue_0, "enabled": _enabled_0, "locked": _locked_0};
}

function $$$$047$$$047src$047ecs$047component$058access$1261$(_value_0) {
  if (_value_0.$ === "None") {
    return {$: "../../src/ecs/component.ComponentAbsent"};
  } else {
    const _value_1 = _value_0["value"];
    return {$: "../../src/ecs/component.Found", "value": _value_1};
  }
}

function $$$$047$$$047src$047ecs$047column$058plain_view_sized$1261$(_id_0, _stamps_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047src$047ecs$047column$058plain_view_checked$1261$(_values_0, _stamps_0, _id_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047src$047ecs$047column$058prepared_view_state$1261$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047src$047ecs$047column$058prepared_view_checked$1261$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0));
}

function $$$$047$$$047src$047ecs$047column$058indexed_view_state$1261$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047src$047ecs$047column$058indexed_view_sized$1261$(_id_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepared_view_state$1261$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047src$047ecs$047column$058indexed_prepared_view_checked$1261$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0));
}

function $$$$047$$$047src$047ecs$047column$058plain_view_checked$1260$(_values_0, _stamps_0, _id_0, _valid_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "None"}};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $$$$047$$$047src$047ecs$047column$058plain_view_taken$1260$(_stamps_0, _id_0, array_rmw(_values_0, _x_0, () => _x_1));
  }
}

function $$$$047$$$047src$047ecs$047column$058prepared_view_checked$1260$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _valid_0, _same_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    if (_same_0) {
      return $$$$047$$$047src$047ecs$047column$058prepared_view_current$1260$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0);
    } else {
      return $$$$047$$$047src$047ecs$047column$058prepared_view_different$1260$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, (_id_0 < _current_0));
    }
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_view_sized$1260$(_id_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047src$047ecs$047column$058indexed_view_checked$1260$(_id_0, _values_0, _metadata_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepared_view_checked$1260$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _valid_0, _same_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    if (_same_0) {
      return $$$$047$$$047src$047ecs$047column$058indexed_prepared_view_current$1260$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0);
    } else {
      return $$$$047$$$047src$047ecs$047column$058indexed_prepared_view_different$1260$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, (_id_0 < _current_0));
    }
  }
}

function $gameplay$058duplicate_after_a$1261$(_observed_0) {
  const _ctx_0 = _observed_0["fst"];
  const _afterA_0 = _observed_0["snd"];
  return $gameplay$058duplicate_after_b$1261$(_afterA_0, run_loop($$$$047$$$047src$047ecs$047capabilities$058read$1267$(run_loop($$$$047$$$047src$047ecs$047capabilities$058set$1267$(_ctx_0, ($schema$058stock_payload$(71)))))));
}

function $$$$047$$$047src$047ecs$047capabilities$058get$1263$(_ctx_0) {
  return run_tail(($$$$047$$$047src$047ecs$047capabilities$058write_read_field$1262$(($gameplay$058duplicate_b$1261$({$: "gameplay.DuplicateCaps", "a": ($owned$045rows$058write_duplicate_stock$()), "b": ($owned$045rows$058write_duplicate_stock$()), "r": ($owned$045rows$058read_duplicate_stock$()), "id": ($owned$045rows$058id_read_duplicate$())})))), _ctx_0);
}

function $$$$047$$$047src$047ecs$047capabilities$058set$1268$(_ctx_0, _value_0) {
  return run_tail(($$$$047$$$047src$047ecs$047capabilities$058write_field$1264$(($gameplay$058duplicate_a$1261$({$: "gameplay.DuplicateCaps", "a": ($owned$045rows$058write_duplicate_stock$()), "b": ($owned$045rows$058write_duplicate_stock$()), "r": ($owned$045rows$058read_duplicate_stock$()), "id": ($owned$045rows$058id_read_duplicate$())}))))(_ctx_0), _value_0);
}

function $owned$045rows$058get_duplicate_stock$(_row_0) {
  return $$$$047$$$047src$047ecs$047owned$045family$058get$1263$(_row_0);
}

function $owned$045rows$058set_duplicate_stock$(_row_0, _incoming_0) {
  return $$$$047$$$047src$047ecs$047owned$045family$058write_owner$1263$(($$$$047$$$047src$047ecs$047owned$045family$058write$1263$(_row_0, _incoming_0)));
}

function $owned$045rows$058id_duplicate$($0) {
  for (;;) {
    {
      const _row_0 = $0;
      if (_row_0.$ === "owned-rows.DuplicateRow") {
        const _t_0 = _row_0["state"];
        const _header_0 = _t_0["header"];
        const _stock_0 = _t_0["stock"];
        const _cold_0 = _t_0["cold"];
        return $owned$045rows$058id_duplicate_header$(_stock_0, _cold_0, _header_0);
      } else {
        const _inner_0 = _row_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047captured$045column$058plain_checked$1260$(_id_0, _stamps_0, _values_0, _valid_0) {
  if (!_valid_0) {
    return {$: "../../src/ecs/captured-column.Unavailable", "column": {$: "../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $$$$047$$$047src$047ecs$047captured$045column$058plain_taken$1260$(_id_0, _stamps_0, array_rmw(_values_0, _x_0, () => _x_1));
  }
}

function $$$$047$$$047src$047ecs$047captured$045column$058prepared_checked$1260$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _valid_0, _same_0, _backwards_0) {
  if (!_valid_0) {
    return {$: "../../src/ecs/captured-column.Unavailable", "column": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}};
  } else {
    if (_same_0) {
      return $$$$047$$$047src$047ecs$047captured$045column$058captured_prepared$1260$(_id_0, _values_0, _stamps_0, _capacity_0, _owner_0, _remaining_0, _past_0);
    } else {
      if (_backwards_0) {
        return $$$$047$$$047src$047ecs$047captured$045column$058recovered_capture$1260$(_id_0, ($$$$047$$$047src$047ecs$047column$058recover$1260$({$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}})));
      } else {
        const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
        const _x_1 = ((_x_0 + 1) >>> 0);
        return $$$$047$$$047src$047ecs$047captured$045column$058capture_seek$1260$(_x_1, _values_0, _stamps_0, _capacity_0, _id_0, _remaining_0, ($$$$047$$$047src$047ecs$047column$058past_current$1260$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../src/ecs/column.Inspect"});
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047captured$045column$058indexed_plain_sized$1260$(_id_0, _metadata_0, _sized_0) {
  const _values_0 = _sized_0["fst"];
  const _size_0 = _sized_0["snd"];
  return $$$$047$$$047src$047ecs$047captured$045column$058indexed_plain_checked$1260$(_id_0, _metadata_0, _values_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047src$047ecs$047captured$045column$058indexed_prepared_checked$1260$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _valid_0, _same_0, _backwards_0) {
  if (!_valid_0) {
    return {$: "../../src/ecs/captured-column.Unavailable", "column": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}};
  } else {
    if (_same_0) {
      return $$$$047$$$047src$047ecs$047captured$045column$058indexed_captured_prepared$1260$(_id_0, _values_0, _metadata_0, _capacity_0, _owner_0, _remaining_0, _past_0);
    } else {
      if (_backwards_0) {
        return $$$$047$$$047src$047ecs$047captured$045column$058recovered_capture$1260$(_id_0, ($$$$047$$$047src$047ecs$047column$058recover$1260$({$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}})));
      } else {
        const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
        const _x_1 = ((_x_0 + 1) >>> 0);
        return $$$$047$$$047src$047ecs$047captured$045column$058indexed_capture_seek$1260$(_x_1, _values_0, _metadata_0, _capacity_0, _id_0, _remaining_0, ($$$$047$$$047src$047ecs$047column$058past_current$1260$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../src/ecs/column.Inspect"});
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047owned$045compose$058reserved_fields$1260$(_args_0, _cursor_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _handles_0 = _observed_0["snd"];
  return $$$$047$$$047src$047ecs$047owned$045compose$058finished$1260$(run_loop($$$$047$$$047src$047ecs$047owned$045compose$058run_handles_fields$1260$(_handles_0, _args_0, _cursor_0, ($$$$047$$$047src$047ecs$047transaction$058begin$1260$(_world_0)))));
}

function $String$cmp$fin$(_t1_0, _t2_0, _hc_0) {
  const _t_0 = _hc_0["fst"];
  const _h1b_0 = _t_0["fst"];
  const _h2b_0 = _t_0["snd"];
  const _t_1 = _hc_0["snd"];
  if (_t_1.$ === "LT") {
    return {$: "Tuple", "fst": {$: "Tuple", "fst": (_h1b_0 + _t1_0), "snd": (_h2b_0 + _t2_0)}, "snd": {$: "LT"}};
  } else if (_t_1.$ === "EQ") {
    return $String$cmp$rec$(_h1b_0, _h2b_0, ($String$cmp$(_t1_0, _t2_0)));
  } else {
    return {$: "Tuple", "fst": {$: "Tuple", "fst": (_h1b_0 + _t1_0), "snd": (_h2b_0 + _t2_0)}, "snd": {$: "GT"}};
  }
}

function $Char$cmp$(_a_0, _b_0) {
  const _x_0 = _a_0.codePointAt(0);
  const _x_1 = _b_0.codePointAt(0);
  return {$: "Tuple", "fst": {$: "Tuple", "fst": _a_0, "snd": _b_0}, "snd": cmp_new(_x_0, _x_1)};
}

function $schema$058clear_column_result$1260$(_result_0) {
  if (_result_0.$ === "../../src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    return _column_0;
  } else {
    const _column_1 = _result_0["column"];
    return _column_1;
  }
}

function $$$$047$$$047src$047ecs$047column$058clear$1260$(_column_0, _id_0) {
  return $$$$047$$$047src$047ecs$047column$058cleared$1260$(_id_0, ($$$$047$$$047src$047ecs$047column$058swap$1260$(_column_0, _id_0, {$: "None"})));
}

function $schema$058clear_column_result$1261$(_result_0) {
  if (_result_0.$ === "../../src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    return _column_0;
  } else {
    const _column_1 = _result_0["column"];
    return _column_1;
  }
}

function $$$$047$$$047src$047ecs$047column$058clear$1261$(_column_0, _id_0) {
  return $$$$047$$$047src$047ecs$047column$058cleared$1261$(_id_0, ($$$$047$$$047src$047ecs$047column$058swap$1261$(_column_0, _id_0, {$: "None"})));
}

function $schema$058clear_column_result$1262$(_result_0) {
  if (_result_0.$ === "../../src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    return _column_0;
  } else {
    const _column_1 = _result_0["column"];
    return _column_1;
  }
}

function $$$$047$$$047src$047ecs$047column$058clear$1262$(_column_0, _id_0) {
  return $$$$047$$$047src$047ecs$047column$058cleared$1262$(_id_0, ($$$$047$$$047src$047ecs$047column$058swap$1262$(_column_0, _id_0, {$: "None"})));
}

function $schema$058clear_column_result$1263$(_result_0) {
  if (_result_0.$ === "../../src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    return _column_0;
  } else {
    const _column_1 = _result_0["column"];
    return _column_1;
  }
}

function $$$$047$$$047src$047ecs$047column$058clear$1263$(_column_0, _id_0) {
  return $$$$047$$$047src$047ecs$047column$058cleared$1263$(_id_0, ($$$$047$$$047src$047ecs$047column$058swap$1263$(_column_0, _id_0, {$: "None"})));
}

function $schema$058clear_column_result$1264$(_result_0) {
  if (_result_0.$ === "../../src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    return _column_0;
  } else {
    const _column_1 = _result_0["column"];
    return _column_1;
  }
}

function $$$$047$$$047src$047ecs$047column$058clear$1264$(_column_0, _id_0) {
  return $$$$047$$$047src$047ecs$047column$058cleared$1264$(_id_0, ($$$$047$$$047src$047ecs$047column$058swap$1264$(_column_0, _id_0, {$: "None"})));
}

function $$$$047$$$047src$047ecs$047component$058replace_clock_checked$1264$(_allowed_0, _world_0, _id_0, _observed_0) {
  if (!_allowed_0) {
    const _incoming_0 = _observed_0["fst"];
    return {$: "../../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../src/ecs/world.CapacityExceeded"}};
  } else {
    const _incoming_1 = _observed_0["fst"];
    const _present_0 = _observed_0["snd"];
    return $$$$047$$$047src$047ecs$047component$058replace_clock_advanced$1264$(_id_0, _present_0, _incoming_1, ($$$$047$$$047src$047ecs$047world$058advance_clock$1260$(_world_0)));
  }
}

function $$$$047$$$047src$047ecs$047component$058owner_present$1264$(_owner_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "None"}, "snd": false};
  } else {
    const _owner_1 = _owner_0["value"];
    return {$: "Tuple", "fst": {$: "Some", "value": _owner_1}, "snd": true};
  }
}

function $$$$047$$$047src$047ecs$047component$058replace_clock_checked$1263$(_allowed_0, _world_0, _id_0, _observed_0) {
  if (!_allowed_0) {
    const _incoming_0 = _observed_0["fst"];
    return {$: "../../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../src/ecs/world.CapacityExceeded"}};
  } else {
    const _incoming_1 = _observed_0["fst"];
    const _present_0 = _observed_0["snd"];
    return $$$$047$$$047src$047ecs$047component$058replace_clock_advanced$1263$(_id_0, _present_0, _incoming_1, ($$$$047$$$047src$047ecs$047world$058advance_clock$1260$(_world_0)));
  }
}

function $$$$047$$$047src$047ecs$047component$058owner_present$1263$(_owner_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "None"}, "snd": false};
  } else {
    const _owner_1 = _owner_0["value"];
    return {$: "Tuple", "fst": {$: "Some", "value": _owner_1}, "snd": true};
  }
}

function $$$$047$$$047src$047ecs$047owned$045compose$058each_fields$1265$(_args_0, _world_0) {
  return $$$$047$$$047src$047ecs$047owned$045compose$058reserved_fields$1266$(_args_0, 0, ($$$$047$$$047src$047ecs$047world$058handles$1260$(_world_0)));
}

function $schema$058replaced$1264$(_result_0) {
  if (_result_0.$ === "../../src/ecs/component.Replaced") {
    const _world_0 = _result_0["world"];
    return _world_0;
  } else {
    const _world_1 = _result_0["world"];
    return _world_1;
  }
}

function $$$$047$$$047src$047ecs$047component$058structural_replace$1264$(_family_0, _world_0, _handle_0, _incoming_0) {
  return $$$$047$$$047src$047ecs$047component$058replace_allowed$1264$(($$$$047$$$047src$047ecs$047world$058metadata_valid$1260$(_world_0, _handle_0)), _handle_0, _incoming_0);
}

function $schema$058replaced$1263$(_result_0) {
  if (_result_0.$ === "../../src/ecs/component.Replaced") {
    const _world_0 = _result_0["world"];
    return _world_0;
  } else {
    const _world_1 = _result_0["world"];
    return _world_1;
  }
}

function $$$$047$$$047src$047ecs$047component$058structural_replace$1263$(_family_0, _world_0, _handle_0, _incoming_0) {
  return $$$$047$$$047src$047ecs$047component$058replace_allowed$1263$(($$$$047$$$047src$047ecs$047world$058metadata_valid$1260$(_world_0, _handle_0)), _handle_0, _incoming_0);
}

function $schema$058replaced$1262$(_result_0) {
  if (_result_0.$ === "../../src/ecs/component.Replaced") {
    const _world_0 = _result_0["world"];
    return _world_0;
  } else {
    const _world_1 = _result_0["world"];
    return _world_1;
  }
}

function $$$$047$$$047src$047ecs$047component$058structural_replace$1262$(_family_0, _world_0, _handle_0, _incoming_0) {
  return $$$$047$$$047src$047ecs$047component$058replace_allowed$1262$(($$$$047$$$047src$047ecs$047world$058metadata_valid$1260$(_world_0, _handle_0)), _handle_0, _incoming_0);
}

function $schema$058replaced$1261$(_result_0) {
  if (_result_0.$ === "../../src/ecs/component.Replaced") {
    const _world_0 = _result_0["world"];
    return _world_0;
  } else {
    const _world_1 = _result_0["world"];
    return _world_1;
  }
}

function $$$$047$$$047src$047ecs$047component$058structural_replace$1261$(_family_0, _world_0, _handle_0, _incoming_0) {
  return $$$$047$$$047src$047ecs$047component$058replace_allowed$1261$(($$$$047$$$047src$047ecs$047world$058metadata_valid$1260$(_world_0, _handle_0)), _handle_0, _incoming_0);
}

function $schema$058replaced$1260$(_result_0) {
  if (_result_0.$ === "../../src/ecs/component.Replaced") {
    const _world_0 = _result_0["world"];
    return _world_0;
  } else {
    const _world_1 = _result_0["world"];
    return _world_1;
  }
}

function $$$$047$$$047src$047ecs$047component$058structural_replace$1260$(_family_0, _world_0, _handle_0, _incoming_0) {
  return $$$$047$$$047src$047ecs$047component$058replace_allowed$1260$(($$$$047$$$047src$047ecs$047world$058metadata_valid$1260$(_world_0, _handle_0)), _handle_0, _incoming_0);
}

function $$$$047$$$047src$047ecs$047optimized$045compose$058recovered$1265$(_result_0) {
  const _world_0 = _result_0["world"];
  const _outcome_0 = _result_0["outcome"];
  const _values_0 = _result_0["values"];
  return {$: "../../src/ecs/compose.Executed", "world": ($$$$047$$$047src$047ecs$047optimized$045compose$058map_store$1267$(_world_0)), "outcome": _outcome_0, "values": _values_0};
}

function $$$$047$$$047src$047ecs$047owned$045compose$058each_fields_since$1260$(_args_0, _world_0, _cursor_0) {
  return $$$$047$$$047src$047ecs$047owned$045compose$058reserved_fields$1265$(_args_0, _cursor_0, ($$$$047$$$047src$047ecs$047world$058handles$1260$(_world_0)));
}

function $$$$047$$$047src$047ecs$047optimized$045compose$058map_store$1268$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": ($schema$058prepare_advanced$(_store_0)), "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $$$$047$$$047src$047ecs$047component$058replace_clock_advanced$1260$(_id_0, _incomingPresent_0, _incoming_0, _advanced_0) {
  const _world_0 = _advanced_0["fst"];
  const _tick_0 = _advanced_0["snd"];
  return $$$$047$$$047src$047ecs$047component$058replaced$1260$(($$$$047$$$047src$047ecs$047component$058swap_world$1260$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _world_0)));
}

function $$$$047$$$047src$047ecs$047world$058advance_clock$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": ($$$$047$$$047src$047ecs$047world$058next_clock$((_clock_0 < 4294967295), _clock_0))}, "snd": ($$$$047$$$047src$047ecs$047world$058next_clock$((_clock_0 < 4294967295), _clock_0))};
}

function $$$$047$$$047src$047ecs$047component$058replace_clock_advanced$1261$(_id_0, _incomingPresent_0, _incoming_0, _advanced_0) {
  const _world_0 = _advanced_0["fst"];
  const _tick_0 = _advanced_0["snd"];
  return $$$$047$$$047src$047ecs$047component$058replaced$1261$(($$$$047$$$047src$047ecs$047component$058swap_world$1261$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _world_0)));
}

function $reference$045declarations$058match_enabled$1261$(_frame_0) {
  return $$$$047$$$047src$047ecs$047compose$058family_match$1264$(_frame_0);
}

function $$$$047$$$047src$047ecs$047compose$058family_match$1261$(_frame_0) {
  return $$$$047$$$047src$047ecs$047compose$058selected_join$1261$({$: "../../src/ecs/compose.Present"}, ($$$$047$$$047src$047ecs$047compose$058get$1263$(_frame_0)));
}

function $$$$047$$$047src$047ecs$047capabilities$058value_read_field$1262$(_cap_0) {
  const _get_0 = _cap_0["get"];
  return _get_0;
}

function $reference$045declarations$058id_read$() {
  return {$: "../../src/ecs/capabilities.ValueRead", "get": run_clo((_x_0) => {
  return $reference$045declarations$058id_get$(_x_0);
})};
}

function $gameplay$058compose_recipe$1261$(_id_0, _stock_0, _observed_0) {
  const _ctx_0 = _observed_0["fst"];
  const _recipe_0 = _observed_0["snd"];
  return $gameplay$058compose_queue$1261$(_id_0, _stock_0, _recipe_0, run_loop($$$$047$$$047src$047ecs$047capabilities$058read$1265$(_ctx_0)));
}

function $$$$047$$$047src$047ecs$047capabilities$058read$1266$(_ctx_0) {
  return run_tail(($$$$047$$$047src$047ecs$047capabilities$058read_field$1264$(($gameplay$058work_recipe$1261$({$: "gameplay.WorkCaps", "stock": ($owned$045rows$058write_work_stock$()), "recipe": ($owned$045rows$058read_work_recipe$()), "queue": ($owned$045rows$058read_work_queue$()), "id": ($owned$045rows$058id_read_work$())})))), _ctx_0);
}

function $$$$047$$$047src$047ecs$047capabilities$058write_read_field$1261$(_cap_0) {
  const _get_0 = _cap_0["get"];
  return _get_0;
}

function $gameplay$058work_stock$1261$(_caps_0) {
  const _stock_0 = _caps_0["stock"];
  return _stock_0;
}

function $owned$045rows$058get_work_stock$(_row_0) {
  return $$$$047$$$047src$047ecs$047owned$045family$058get$1260$(_row_0);
}

function $owned$045rows$058set_work_stock$(_row_0, _incoming_0) {
  return $$$$047$$$047src$047ecs$047owned$045family$058write_owner$1260$(($$$$047$$$047src$047ecs$047owned$045family$058write$1260$(_row_0, _incoming_0)));
}

function $owned$045rows$058get_work_recipe$(_row_0) {
  return $$$$047$$$047src$047ecs$047owned$045family$058get$1261$(_row_0);
}

function $owned$045rows$058get_work_queue$(_row_0) {
  return $$$$047$$$047src$047ecs$047owned$045family$058get$1262$(_row_0);
}

function $owned$045rows$058id_work$($0) {
  for (;;) {
    {
      const _row_0 = $0;
      if (_row_0.$ === "owned-rows.WorkRow") {
        const _t_0 = _row_0["state"];
        const _header_0 = _t_0["header"];
        const _stock_0 = _t_0["stock"];
        const _recipe_0 = _t_0["recipe"];
        const _queue_0 = _t_0["queue"];
        const _cold_0 = _t_0["cold"];
        return $owned$045rows$058id_work_header$(_stock_0, _recipe_0, _queue_0, _cold_0, _header_0);
      } else {
        const _inner_0 = _row_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047captured$045column$058plain_checked$1261$(_id_0, _stamps_0, _values_0, _valid_0) {
  if (!_valid_0) {
    return {$: "../../src/ecs/captured-column.Unavailable", "column": {$: "../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $$$$047$$$047src$047ecs$047captured$045column$058plain_taken$1261$(_id_0, _stamps_0, array_rmw(_values_0, _x_0, () => _x_1));
  }
}

function $$$$047$$$047src$047ecs$047captured$045column$058prepared_checked$1261$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _valid_0, _same_0, _backwards_0) {
  if (!_valid_0) {
    return {$: "../../src/ecs/captured-column.Unavailable", "column": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}};
  } else {
    if (_same_0) {
      return $$$$047$$$047src$047ecs$047captured$045column$058captured_prepared$1261$(_id_0, _values_0, _stamps_0, _capacity_0, _owner_0, _remaining_0, _past_0);
    } else {
      if (_backwards_0) {
        return $$$$047$$$047src$047ecs$047captured$045column$058recovered_capture$1261$(_id_0, ($$$$047$$$047src$047ecs$047column$058recover$1261$({$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}})));
      } else {
        const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
        const _x_1 = ((_x_0 + 1) >>> 0);
        return $$$$047$$$047src$047ecs$047captured$045column$058capture_seek$1261$(_x_1, _values_0, _stamps_0, _capacity_0, _id_0, _remaining_0, ($$$$047$$$047src$047ecs$047column$058past_current$1261$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../src/ecs/column.Inspect"});
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047captured$045column$058indexed_plain_sized$1261$(_id_0, _metadata_0, _sized_0) {
  const _values_0 = _sized_0["fst"];
  const _size_0 = _sized_0["snd"];
  return $$$$047$$$047src$047ecs$047captured$045column$058indexed_plain_checked$1261$(_id_0, _metadata_0, _values_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047src$047ecs$047captured$045column$058indexed_prepared_checked$1261$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _valid_0, _same_0, _backwards_0) {
  if (!_valid_0) {
    return {$: "../../src/ecs/captured-column.Unavailable", "column": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}};
  } else {
    if (_same_0) {
      return $$$$047$$$047src$047ecs$047captured$045column$058indexed_captured_prepared$1261$(_id_0, _values_0, _metadata_0, _capacity_0, _owner_0, _remaining_0, _past_0);
    } else {
      if (_backwards_0) {
        return $$$$047$$$047src$047ecs$047captured$045column$058recovered_capture$1261$(_id_0, ($$$$047$$$047src$047ecs$047column$058recover$1261$({$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}})));
      } else {
        const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
        const _x_1 = ((_x_0 + 1) >>> 0);
        return $$$$047$$$047src$047ecs$047captured$045column$058indexed_capture_seek$1261$(_x_1, _values_0, _metadata_0, _capacity_0, _id_0, _remaining_0, ($$$$047$$$047src$047ecs$047column$058past_current$1261$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../src/ecs/column.Inspect"});
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047captured$045column$058plain_checked$1262$(_id_0, _stamps_0, _values_0, _valid_0) {
  if (!_valid_0) {
    return {$: "../../src/ecs/captured-column.Unavailable", "column": {$: "../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $$$$047$$$047src$047ecs$047captured$045column$058plain_taken$1262$(_id_0, _stamps_0, array_rmw(_values_0, _x_0, () => _x_1));
  }
}

function $$$$047$$$047src$047ecs$047captured$045column$058prepared_checked$1262$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _valid_0, _same_0, _backwards_0) {
  if (!_valid_0) {
    return {$: "../../src/ecs/captured-column.Unavailable", "column": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}};
  } else {
    if (_same_0) {
      return $$$$047$$$047src$047ecs$047captured$045column$058captured_prepared$1262$(_id_0, _values_0, _stamps_0, _capacity_0, _owner_0, _remaining_0, _past_0);
    } else {
      if (_backwards_0) {
        return $$$$047$$$047src$047ecs$047captured$045column$058recovered_capture$1262$(_id_0, ($$$$047$$$047src$047ecs$047column$058recover$1262$({$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}})));
      } else {
        const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
        const _x_1 = ((_x_0 + 1) >>> 0);
        return $$$$047$$$047src$047ecs$047captured$045column$058capture_seek$1262$(_x_1, _values_0, _stamps_0, _capacity_0, _id_0, _remaining_0, ($$$$047$$$047src$047ecs$047column$058past_current$1262$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../src/ecs/column.Inspect"});
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047captured$045column$058indexed_plain_sized$1262$(_id_0, _metadata_0, _sized_0) {
  const _values_0 = _sized_0["fst"];
  const _size_0 = _sized_0["snd"];
  return $$$$047$$$047src$047ecs$047captured$045column$058indexed_plain_checked$1262$(_id_0, _metadata_0, _values_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047src$047ecs$047captured$045column$058indexed_prepared_checked$1262$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _valid_0, _same_0, _backwards_0) {
  if (!_valid_0) {
    return {$: "../../src/ecs/captured-column.Unavailable", "column": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}};
  } else {
    if (_same_0) {
      return $$$$047$$$047src$047ecs$047captured$045column$058indexed_captured_prepared$1262$(_id_0, _values_0, _metadata_0, _capacity_0, _owner_0, _remaining_0, _past_0);
    } else {
      if (_backwards_0) {
        return $$$$047$$$047src$047ecs$047captured$045column$058recovered_capture$1262$(_id_0, ($$$$047$$$047src$047ecs$047column$058recover$1262$({$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}})));
      } else {
        const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
        const _x_1 = ((_x_0 + 1) >>> 0);
        return $$$$047$$$047src$047ecs$047captured$045column$058indexed_capture_seek$1262$(_x_1, _values_0, _metadata_0, _capacity_0, _id_0, _remaining_0, ($$$$047$$$047src$047ecs$047column$058past_current$1262$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../src/ecs/column.Inspect"});
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047compose$058and_join$1260$(_observed_0) {
  const _frame_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": _frame_0, "snd": false};
  } else {
    return $reference$045declarations$058match_locked$1260$(_frame_0);
  }
}

function $reference$045declarations$058match_recipe$1260$(_frame_0) {
  return $$$$047$$$047src$047ecs$047compose$058family_match$1262$(_frame_0);
}

function $$$$047$$$047src$047ecs$047world$058with_store_finish$1264$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047src$047ecs$047component$058get_store$1264$(_id_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047src$047ecs$047component$058get_projected$1264$(_rest_0, ($$$$047$$$047src$047ecs$047column$058view$1264$(_column_0, _id_0)));
}

function $schema$058take_locked$(_store_0) {
  const _stock_0 = _store_0["stock"];
  const _recipe_0 = _store_0["recipe"];
  const _queue_0 = _store_0["queue"];
  const _enabled_0 = _store_0["enabled"];
  const _locked_0 = _store_0["locked"];
  return {$: "Tuple", "fst": {$: "schema.LockedRest", "stock": _stock_0, "recipe": _recipe_0, "queue": _queue_0, "enabled": _enabled_0}, "snd": _locked_0};
}

function $$$$047$$$047src$047ecs$047component$058get_projected$1263$(_rest_0, _observed_0) {
  const _column_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($schema$058put_enabled$(_rest_0, _column_0)), "snd": ($$$$047$$$047src$047ecs$047component$058access$1263$(_value_0))};
}

function $$$$047$$$047src$047ecs$047column$058view$1263$(_column_0, _id_0) {
  if (_column_0.$ === "../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047src$047ecs$047column$058plain_view_sized$1263$(_id_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058prepared_view_state$1263$(_id_0, ($$$$047$$$047src$047ecs$047column$058unseal$1263$(_carrier_0)));
  } else if (_column_0.$ === "../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058indexed_view_state$1263$(_id_0, ($$$$047$$$047src$047ecs$047column$058indexed_unseal$1263$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058indexed_prepared_view_state$1263$(_id_0, ($$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1263$(_carrier_2)));
  }
}

function $schema$058put_queue$(_rest_0, _column_0) {
  const _stock_0 = _rest_0["stock"];
  const _recipe_0 = _rest_0["recipe"];
  const _enabled_0 = _rest_0["enabled"];
  const _locked_0 = _rest_0["locked"];
  return {$: "schema.Store", "stock": _stock_0, "recipe": _recipe_0, "queue": _column_0, "enabled": _enabled_0, "locked": _locked_0};
}

function $$$$047$$$047src$047ecs$047component$058access$1262$(_value_0) {
  if (_value_0.$ === "None") {
    return {$: "../../src/ecs/component.ComponentAbsent"};
  } else {
    const _value_1 = _value_0["value"];
    return {$: "../../src/ecs/component.Found", "value": _value_1};
  }
}

function $$$$047$$$047src$047ecs$047column$058plain_view_sized$1262$(_id_0, _stamps_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047src$047ecs$047column$058plain_view_checked$1262$(_values_0, _stamps_0, _id_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047src$047ecs$047column$058prepared_view_state$1262$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047src$047ecs$047column$058prepared_view_checked$1262$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0));
}

function $$$$047$$$047src$047ecs$047column$058indexed_view_state$1262$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047src$047ecs$047column$058indexed_view_sized$1262$(_id_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepared_view_state$1262$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047src$047ecs$047column$058indexed_prepared_view_checked$1262$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0));
}

function $$$$047$$$047src$047ecs$047column$058plain_view_checked$1261$(_values_0, _stamps_0, _id_0, _valid_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "None"}};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $$$$047$$$047src$047ecs$047column$058plain_view_taken$1261$(_stamps_0, _id_0, array_rmw(_values_0, _x_0, () => _x_1));
  }
}

function $$$$047$$$047src$047ecs$047column$058prepared_view_checked$1261$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _valid_0, _same_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    if (_same_0) {
      return $$$$047$$$047src$047ecs$047column$058prepared_view_current$1261$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0);
    } else {
      return $$$$047$$$047src$047ecs$047column$058prepared_view_different$1261$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, (_id_0 < _current_0));
    }
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_view_sized$1261$(_id_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047src$047ecs$047column$058indexed_view_checked$1261$(_id_0, _values_0, _metadata_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepared_view_checked$1261$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _valid_0, _same_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    if (_same_0) {
      return $$$$047$$$047src$047ecs$047column$058indexed_prepared_view_current$1261$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0);
    } else {
      return $$$$047$$$047src$047ecs$047column$058indexed_prepared_view_different$1261$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, (_id_0 < _current_0));
    }
  }
}

function $$$$047$$$047src$047ecs$047column$058plain_view_taken$1260$(_stamps_0, _id_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "None"}};
  } else {
    const _owner_0 = _t_0["value"];
    return $$$$047$$$047src$047ecs$047column$058plain_view_projected$1260$(_values_0, _stamps_0, _id_0, ($schema$058project_stock$(_owner_0)));
  }
}

function $$$$047$$$047src$047ecs$047column$058prepared_view_current$1260$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "None"}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    const _owned_0 = _owner_0["value"];
    return $$$$047$$$047src$047ecs$047column$058prepared_view_projected$1260$(_values_0, _stamps_0, _capacity_0, _current_0, _remaining_0, _past_0, ($schema$058project_stock$(_owned_0)));
  }
}

function $$$$047$$$047src$047ecs$047column$058prepared_view_different$1260$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _backwards_0) {
  if (_backwards_0) {
    return $$$$047$$$047src$047ecs$047column$058view_taken$1260$(_id_0, ($$$$047$$$047src$047ecs$047column$058swap_recovered$1260$(_id_0, {$: "None"}, ($$$$047$$$047src$047ecs$047column$058recover_current$1260$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0))))));
  } else {
    const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
    const _x_1 = ((_x_0 + 1) >>> 0);
    return $$$$047$$$047src$047ecs$047column$058seek_view$1260$(_x_1, _values_0, _stamps_0, _capacity_0, _id_0, _remaining_0, ($$$$047$$$047src$047ecs$047column$058past_current$1260$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../src/ecs/column.Inspect"});
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_view_checked$1260$(_id_0, _values_0, _metadata_0, _valid_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": ($$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "snd": {$: "None"}};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $$$$047$$$047src$047ecs$047column$058indexed_view_taken$1260$(_id_0, _metadata_0, array_rmw(_values_0, _x_0, () => _x_1));
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepared_view_current$1260$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "None"}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    const _owned_0 = _owner_0["value"];
    return $$$$047$$$047src$047ecs$047column$058indexed_prepared_view_projected$1260$(_values_0, _metadata_0, _capacity_0, _current_0, _remaining_0, _past_0, ($schema$058project_stock$(_owned_0)));
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepared_view_different$1260$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _backwards_0) {
  if (_backwards_0) {
    return $$$$047$$$047src$047ecs$047column$058view_taken$1260$(_id_0, ($$$$047$$$047src$047ecs$047column$058swap_recovered$1260$(_id_0, {$: "None"}, ($$$$047$$$047src$047ecs$047column$058indexed_recover_current$1260$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0))))));
  } else {
    const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
    const _x_1 = ((_x_0 + 1) >>> 0);
    return $$$$047$$$047src$047ecs$047column$058indexed_seek_view$1260$(_x_1, _values_0, _metadata_0, _capacity_0, _id_0, _remaining_0, ($$$$047$$$047src$047ecs$047column$058past_current$1260$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../src/ecs/column.Inspect"});
  }
}

function $gameplay$058duplicate_after_b$1261$(_afterA_0, _observed_0) {
  const _ctx_0 = _observed_0["fst"];
  const _afterB_0 = _observed_0["snd"];
  const _x_0 = ($json$058stock$(_afterB_0));
  const _x_1 = (_x_0 + ",\"readHasSet\":false}");
  const _x_2 = ($json$058stock$(_afterA_0));
  const _x_3 = (",\"afterB\":" + _x_1);
  const _x_4 = (_x_2 + _x_3);
  return {$: "Tuple", "fst": _ctx_0, "snd": {$: "Tuple", "fst": {$: "../../src/ecs/transaction.Success"}, "snd": ("{\"label\":\"duplicate-family-reference\",\"afterA\":" + _x_4)}};
}

function $$$$047$$$047src$047ecs$047capabilities$058read$1267$(_ctx_0) {
  return run_tail(($$$$047$$$047src$047ecs$047capabilities$058read_field$1265$(($gameplay$058duplicate_r$1261$({$: "gameplay.DuplicateCaps", "a": ($owned$045rows$058write_duplicate_stock$()), "b": ($owned$045rows$058write_duplicate_stock$()), "r": ($owned$045rows$058read_duplicate_stock$()), "id": ($owned$045rows$058id_read_duplicate$())})))), _ctx_0);
}

function $$$$047$$$047src$047ecs$047capabilities$058set$1267$(_ctx_0, _value_0) {
  return run_tail(($$$$047$$$047src$047ecs$047capabilities$058write_field$1264$(($gameplay$058duplicate_b$1261$({$: "gameplay.DuplicateCaps", "a": ($owned$045rows$058write_duplicate_stock$()), "b": ($owned$045rows$058write_duplicate_stock$()), "r": ($owned$045rows$058read_duplicate_stock$()), "id": ($owned$045rows$058id_read_duplicate$())}))))(_ctx_0), _value_0);
}

function $$$$047$$$047src$047ecs$047capabilities$058write_read_field$1262$(_cap_0) {
  const _get_0 = _cap_0["get"];
  return _get_0;
}

function $gameplay$058duplicate_b$1261$(_caps_0) {
  const _b_0 = _caps_0["b"];
  return _b_0;
}

function $$$$047$$$047src$047ecs$047capabilities$058write_field$1264$(_cap_0) {
  const _set_0 = _cap_0["set"];
  return _set_0;
}

function $gameplay$058duplicate_a$1261$(_caps_0) {
  const _a_0 = _caps_0["a"];
  return _a_0;
}

function $$$$047$$$047src$047ecs$047owned$045family$058get$1263$(_owner_0) {
  return $$$$047$$$047src$047ecs$047owned$045family$058get_taken$1263$(($owned$045rows$058take_duplicate_stock$(_owner_0)));
}

function $$$$047$$$047src$047ecs$047owned$045family$058write_owner$1263$(_result_0) {
  if (_result_0.$ === "../../src/ecs/owned-family.Written") {
    const _owner_0 = _result_0["owner"];
    return _owner_0;
  } else {
    const _owner_1 = _result_0["owner"];
    return _owner_1;
  }
}

function $$$$047$$$047src$047ecs$047owned$045family$058write$1263$(_owner_0, _incoming_0) {
  return $$$$047$$$047src$047ecs$047owned$045family$058write_taken$1263$(_incoming_0, ($owned$045rows$058take_duplicate_stock$(_owner_0)));
}

function $owned$045rows$058id_duplicate_header$(_stock_0, _cold_0, _header_0) {
  const _namespace_0 = _header_0["namespace"];
  const _nextId_0 = _header_0["nextId"];
  const _live_0 = _header_0["live"];
  const _t_0 = _header_0["handle"];
  const _ns_0 = _t_0["namespace"];
  const _key_0 = _t_0["id"];
  const _clock_0 = _header_0["clock"];
  const _error_0 = _header_0["error"];
  const _cursor_0 = _header_0["cursor"];
  return {$: "Tuple", "fst": {$: "owned-rows.DuplicateRow", "state": {$: "owned-rows.DuplicateState", "header": {$: "../../src/ecs/owned-family.Header", "namespace": _namespace_0, "nextId": _nextId_0, "live": _live_0, "handle": {$: "../../src/ecs/world.Handle", "namespace": _ns_0, "id": _key_0}, "clock": _clock_0, "error": _error_0, "cursor": _cursor_0}, "stock": _stock_0, "cold": _cold_0}}, "snd": _key_0};
}

function $$$$047$$$047src$047ecs$047captured$045column$058plain_taken$1260$(_id_0, _stamps_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _owner_0 = _result_0["snd"];
  return {$: "../../src/ecs/captured-column.Captured", "id": _id_0, "owner": _owner_0, "stamp": ($$$$047$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0)), "restore": run_clo((_x_0) => {
  return $$$$047$$$047src$047ecs$047captured$045column$058restore_plain$1260$(_id_0, _values_0, _stamps_0, _x_0);
})};
}

function $$$$047$$$047src$047ecs$047captured$045column$058captured_prepared$1260$(_id_0, _values_0, _stamps_0, _capacity_0, _owner_0, _remaining_0, _past_0) {
  return {$: "../../src/ecs/captured-column.Captured", "id": _id_0, "owner": _owner_0, "stamp": ($$$$047$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0)), "restore": run_clo((_x_0) => {
  return $$$$047$$$047src$047ecs$047captured$045column$058restore_prepared$1260$(_id_0, _values_0, _stamps_0, _capacity_0, _remaining_0, _past_0, _x_0);
})};
}

function $$$$047$$$047src$047ecs$047captured$045column$058recovered_capture$1260$(_id_0, _column_0) {
  if (_column_0.$ === "../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047src$047ecs$047captured$045column$058plain_sized$1260$(_id_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../src/ecs/column.Indexed") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047captured$045column$058indexed_plain_state$1260$(_id_0, ($$$$047$$$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_0)));
  } else {
    return {$: "../../src/ecs/captured-column.Unavailable", "column": _column_0};
  }
}

function $$$$047$$$047src$047ecs$047captured$045column$058capture_seek$1260$($0, $1, $2, $3, $4, $5, $6, $7) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _remaining_0 = $5;
      const _past_0 = $6;
      const _phase_0 = $7;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../src/ecs/owner-handoff.HandoffNil") {
          return $$$$047$$$047src$047ecs$047captured$045column$058captured_prepared$1260$(_target_0, _values_0, _stamps_0, _capacity_0, {$: "None"}, {$: "../../src/ecs/owner-handoff.HandoffNil"}, _past_0);
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "../../src/ecs/captured-column.Unavailable", "column": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../src/ecs/owner-handoff.HandoffNil") {
          return $$$$047$$$047src$047ecs$047captured$045column$058captured_prepared$1260$(_target_0, _values_0, _stamps_0, _capacity_0, {$: "None"}, {$: "../../src/ecs/owner-handoff.HandoffNil"}, _past_0);
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _stamps_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $6 = _past_0;
            $7 = {$: "../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return $$$$047$$$047src$047ecs$047captured$045column$058captured_prepared$1260$(_target_0, _values_0, _stamps_0, _capacity_0, {$: "Some", "value": _owner_1}, _rest_1, _past_0);
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return $$$$047$$$047src$047ecs$047captured$045column$058captured_prepared$1260$(_target_0, _values_0, _stamps_0, _capacity_0, {$: "None"}, {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, _past_0);
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _stamps_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _rest_1;
                $6 = {$: "../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $7 = {$: "../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047column$058past_current$1260$(_current_0, _owner_0, _past_0, _active_0) {
  if (!_active_0) {
    return _past_0;
  } else {
    return {$: "../../src/ecs/column.HistoryCon", "id": _current_0, "value": _owner_0, "rest": _past_0};
  }
}

function $$$$047$$$047src$047ecs$047captured$045column$058indexed_plain_checked$1260$(_id_0, _metadata_0, _values_0, _valid_0) {
  if (!_valid_0) {
    return {$: "../../src/ecs/captured-column.Unavailable", "column": ($$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0))};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $$$$047$$$047src$047ecs$047captured$045column$058indexed_plain_taken$1260$(_id_0, _metadata_0, array_rmw(_values_0, _x_0, () => _x_1));
  }
}

function $$$$047$$$047src$047ecs$047captured$045column$058indexed_captured_prepared$1260$(_id_0, _values_0, _metadata_0, _capacity_0, _owner_0, _remaining_0, _past_0) {
  return $$$$047$$$047src$047ecs$047captured$045column$058indexed_captured_got$1260$(_id_0, _values_0, _capacity_0, _owner_0, _remaining_0, _past_0, ($$$$047$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047src$047ecs$047captured$045column$058indexed_capture_seek$1260$($0, $1, $2, $3, $4, $5, $6, $7) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _remaining_0 = $5;
      const _past_0 = $6;
      const _phase_0 = $7;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../src/ecs/owner-handoff.HandoffNil") {
          return $$$$047$$$047src$047ecs$047captured$045column$058indexed_captured_prepared$1260$(_target_0, _values_0, _metadata_0, _capacity_0, {$: "None"}, {$: "../../src/ecs/owner-handoff.HandoffNil"}, _past_0);
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "../../src/ecs/captured-column.Unavailable", "column": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../src/ecs/owner-handoff.HandoffNil") {
          return $$$$047$$$047src$047ecs$047captured$045column$058indexed_captured_prepared$1260$(_target_0, _values_0, _metadata_0, _capacity_0, {$: "None"}, {$: "../../src/ecs/owner-handoff.HandoffNil"}, _past_0);
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _metadata_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $6 = _past_0;
            $7 = {$: "../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return $$$$047$$$047src$047ecs$047captured$045column$058indexed_captured_prepared$1260$(_target_0, _values_0, _metadata_0, _capacity_0, {$: "Some", "value": _owner_1}, _rest_1, _past_0);
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return $$$$047$$$047src$047ecs$047captured$045column$058indexed_captured_prepared$1260$(_target_0, _values_0, _metadata_0, _capacity_0, {$: "None"}, {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, _past_0);
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _metadata_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _rest_1;
                $6 = {$: "../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $7 = {$: "../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047owned$045compose$058finished$1260$(_observed_0) {
  const _tx_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  const _result_0 = _t_0["fst"];
  const _values_0 = _t_0["snd"];
  return $$$$047$$$047src$047ecs$047owned$045compose$058finish_returned$1260$(_values_0, ($$$$047$$$047src$047ecs$047commands$058tx_finish$1260$(_tx_0, _result_0)));
}

function $$$$047$$$047src$047ecs$047owned$045compose$058run_handles_fields$1260$(_handles_0, _args_0, _cursor_0, _tx_0) {
  if (_handles_0.$ === "Nil") {
    return {$: "Tuple", "fst": _tx_0, "snd": {$: "Tuple", "fst": {$: "../../src/ecs/transaction.Success"}, "snd": {$: "Nil"}}};
  } else {
    const _handle_0 = _handles_0["head"];
    const _rest_0 = _handles_0["tail"];
    return $$$$047$$$047src$047ecs$047owned$045compose$058selected_fields$1260$(_args_0, run_clo((_x_0) => {
  return $$$$047$$$047src$047ecs$047owned$045compose$058run_handles_fields$1260$(_rest_0, _args_0, _cursor_0, _x_0);
}), ($reference$045declarations$058work_match$({$: "../../src/ecs/compose.Frame", "tx": _tx_0, "handle": _handle_0, "error": {$: "None"}, "cursor": _cursor_0})));
  }
}

function $String$cmp$rec$(_h1b_0, _h2b_0, _rr_0) {
  const _t_0 = _rr_0["fst"];
  const _t1b_0 = _t_0["fst"];
  const _t2b_0 = _t_0["snd"];
  const _r_0 = _rr_0["snd"];
  return {$: "Tuple", "fst": {$: "Tuple", "fst": (_h1b_0 + _t1b_0), "snd": (_h2b_0 + _t2b_0)}, "snd": _r_0};
}

function $$$$047$$$047src$047ecs$047column$058cleared$1260$(_id_0, _outcome_0) {
  if (_outcome_0.$ === "../../src/ecs/column.Accepted") {
    const _column_0 = _outcome_0["column"];
    const _previous_0 = _outcome_0["previous"];
    return {$: "../../src/ecs/column.Accepted", "column": ($$$$047$$$047src$047ecs$047column$058clear_stamp$1260$(_column_0, _id_0)), "previous": _previous_0};
  } else {
    const _column_1 = _outcome_0["column"];
    const _incoming_0 = _outcome_0["incoming"];
    return {$: "../../src/ecs/column.Rejected", "column": _column_1, "incoming": _incoming_0};
  }
}

function $$$$047$$$047src$047ecs$047column$058swap$1260$(_column_0, _id_0, _incoming_0) {
  if (_column_0.$ === "../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047src$047ecs$047column$058swap_sized$1260$(_id_0, _incoming_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058swap_state$1260$(_id_0, _incoming_0, ($$$$047$$$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
  } else if (_column_0.$ === "../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058indexed_swap_state$1260$(_id_0, _incoming_0, ($$$$047$$$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058indexed_prepared_swap_state$1260$(_id_0, _incoming_0, ($$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
  }
}

function $$$$047$$$047src$047ecs$047column$058cleared$1261$(_id_0, _outcome_0) {
  if (_outcome_0.$ === "../../src/ecs/column.Accepted") {
    const _column_0 = _outcome_0["column"];
    const _previous_0 = _outcome_0["previous"];
    return {$: "../../src/ecs/column.Accepted", "column": ($$$$047$$$047src$047ecs$047column$058clear_stamp$1261$(_column_0, _id_0)), "previous": _previous_0};
  } else {
    const _column_1 = _outcome_0["column"];
    const _incoming_0 = _outcome_0["incoming"];
    return {$: "../../src/ecs/column.Rejected", "column": _column_1, "incoming": _incoming_0};
  }
}

function $$$$047$$$047src$047ecs$047column$058swap$1261$(_column_0, _id_0, _incoming_0) {
  if (_column_0.$ === "../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047src$047ecs$047column$058swap_sized$1261$(_id_0, _incoming_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058swap_state$1261$(_id_0, _incoming_0, ($$$$047$$$047src$047ecs$047column$058unseal$1261$(_carrier_0)));
  } else if (_column_0.$ === "../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058indexed_swap_state$1261$(_id_0, _incoming_0, ($$$$047$$$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058indexed_prepared_swap_state$1261$(_id_0, _incoming_0, ($$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1261$(_carrier_2)));
  }
}

function $$$$047$$$047src$047ecs$047column$058cleared$1262$(_id_0, _outcome_0) {
  if (_outcome_0.$ === "../../src/ecs/column.Accepted") {
    const _column_0 = _outcome_0["column"];
    const _previous_0 = _outcome_0["previous"];
    return {$: "../../src/ecs/column.Accepted", "column": ($$$$047$$$047src$047ecs$047column$058clear_stamp$1262$(_column_0, _id_0)), "previous": _previous_0};
  } else {
    const _column_1 = _outcome_0["column"];
    const _incoming_0 = _outcome_0["incoming"];
    return {$: "../../src/ecs/column.Rejected", "column": _column_1, "incoming": _incoming_0};
  }
}

function $$$$047$$$047src$047ecs$047column$058swap$1262$(_column_0, _id_0, _incoming_0) {
  if (_column_0.$ === "../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047src$047ecs$047column$058swap_sized$1262$(_id_0, _incoming_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058swap_state$1262$(_id_0, _incoming_0, ($$$$047$$$047src$047ecs$047column$058unseal$1262$(_carrier_0)));
  } else if (_column_0.$ === "../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058indexed_swap_state$1262$(_id_0, _incoming_0, ($$$$047$$$047src$047ecs$047column$058indexed_unseal$1262$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058indexed_prepared_swap_state$1262$(_id_0, _incoming_0, ($$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1262$(_carrier_2)));
  }
}

function $$$$047$$$047src$047ecs$047column$058cleared$1263$(_id_0, _outcome_0) {
  if (_outcome_0.$ === "../../src/ecs/column.Accepted") {
    const _column_0 = _outcome_0["column"];
    const _previous_0 = _outcome_0["previous"];
    return {$: "../../src/ecs/column.Accepted", "column": ($$$$047$$$047src$047ecs$047column$058clear_stamp$1263$(_column_0, _id_0)), "previous": _previous_0};
  } else {
    const _column_1 = _outcome_0["column"];
    const _incoming_0 = _outcome_0["incoming"];
    return {$: "../../src/ecs/column.Rejected", "column": _column_1, "incoming": _incoming_0};
  }
}

function $$$$047$$$047src$047ecs$047column$058swap$1263$(_column_0, _id_0, _incoming_0) {
  if (_column_0.$ === "../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047src$047ecs$047column$058swap_sized$1263$(_id_0, _incoming_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058swap_state$1263$(_id_0, _incoming_0, ($$$$047$$$047src$047ecs$047column$058unseal$1263$(_carrier_0)));
  } else if (_column_0.$ === "../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058indexed_swap_state$1263$(_id_0, _incoming_0, ($$$$047$$$047src$047ecs$047column$058indexed_unseal$1263$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058indexed_prepared_swap_state$1263$(_id_0, _incoming_0, ($$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1263$(_carrier_2)));
  }
}

function $$$$047$$$047src$047ecs$047column$058cleared$1264$(_id_0, _outcome_0) {
  if (_outcome_0.$ === "../../src/ecs/column.Accepted") {
    const _column_0 = _outcome_0["column"];
    const _previous_0 = _outcome_0["previous"];
    return {$: "../../src/ecs/column.Accepted", "column": ($$$$047$$$047src$047ecs$047column$058clear_stamp$1264$(_column_0, _id_0)), "previous": _previous_0};
  } else {
    const _column_1 = _outcome_0["column"];
    const _incoming_0 = _outcome_0["incoming"];
    return {$: "../../src/ecs/column.Rejected", "column": _column_1, "incoming": _incoming_0};
  }
}

function $$$$047$$$047src$047ecs$047column$058swap$1264$(_column_0, _id_0, _incoming_0) {
  if (_column_0.$ === "../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047src$047ecs$047column$058swap_sized$1264$(_id_0, _incoming_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058swap_state$1264$(_id_0, _incoming_0, ($$$$047$$$047src$047ecs$047column$058unseal$1264$(_carrier_0)));
  } else if (_column_0.$ === "../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058indexed_swap_state$1264$(_id_0, _incoming_0, ($$$$047$$$047src$047ecs$047column$058indexed_unseal$1264$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058indexed_prepared_swap_state$1264$(_id_0, _incoming_0, ($$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1264$(_carrier_2)));
  }
}

function $$$$047$$$047src$047ecs$047component$058replace_clock_advanced$1264$(_id_0, _incomingPresent_0, _incoming_0, _advanced_0) {
  const _world_0 = _advanced_0["fst"];
  const _tick_0 = _advanced_0["snd"];
  return $$$$047$$$047src$047ecs$047component$058replaced$1264$(($$$$047$$$047src$047ecs$047component$058swap_world$1264$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _world_0)));
}

function $$$$047$$$047src$047ecs$047component$058replace_clock_advanced$1263$(_id_0, _incomingPresent_0, _incoming_0, _advanced_0) {
  const _world_0 = _advanced_0["fst"];
  const _tick_0 = _advanced_0["snd"];
  return $$$$047$$$047src$047ecs$047component$058replaced$1263$(($$$$047$$$047src$047ecs$047component$058swap_world$1263$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _world_0)));
}

function $$$$047$$$047src$047ecs$047owned$045compose$058reserved_fields$1266$(_args_0, _cursor_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _handles_0 = _observed_0["snd"];
  return $$$$047$$$047src$047ecs$047owned$045compose$058finished$1260$(run_loop($$$$047$$$047src$047ecs$047owned$045compose$058run_handles_fields$1266$(_handles_0, _args_0, _cursor_0, ($$$$047$$$047src$047ecs$047transaction$058begin$1260$(_world_0)))));
}

function $$$$047$$$047src$047ecs$047component$058replace_allowed$1262$(_checked_0, _handle_0, _incoming_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return {$: "../../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../src/ecs/world.MissingEntity"}};
  } else {
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047src$047ecs$047component$058replace_clock$1262$(_id_0, _incoming_0, ($$$$047$$$047src$047ecs$047world$058clock$1260$(_world_0)));
  }
}

function $$$$047$$$047src$047ecs$047optimized$045compose$058map_store$1267$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": ($schema$058recover_advanced$(_store_0)), "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $$$$047$$$047src$047ecs$047owned$045compose$058reserved_fields$1265$(_args_0, _cursor_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _handles_0 = _observed_0["snd"];
  return $$$$047$$$047src$047ecs$047owned$045compose$058finished$1262$(run_loop($$$$047$$$047src$047ecs$047owned$045compose$058run_handles_fields$1265$(_handles_0, _args_0, _cursor_0, ($$$$047$$$047src$047ecs$047transaction$058begin$1260$(_world_0)))));
}

function $schema$058prepare_advanced$(_store_0) {
  const _stock_0 = _store_0["stock"];
  const _recipe_0 = _store_0["recipe"];
  const _queue_0 = _store_0["queue"];
  const _enabled_0 = _store_0["enabled"];
  const _locked_0 = _store_0["locked"];
  return {$: "schema.Store", "stock": ($$$$047$$$047src$047ecs$047column$058prepare$1260$(_stock_0)), "recipe": _recipe_0, "queue": ($$$$047$$$047src$047ecs$047column$058prepare$1262$(_queue_0)), "enabled": ($$$$047$$$047src$047ecs$047column$058prepare$1263$(_enabled_0)), "locked": ($$$$047$$$047src$047ecs$047column$058prepare$1264$(_locked_0))};
}

function $$$$047$$$047src$047ecs$047component$058replaced$1260$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../../src/ecs/component.Swapped") {
    const _previous_0 = _t_0["previous"];
    return {$: "../../src/ecs/component.Replaced", "world": _world_0, "previous": _previous_0};
  } else {
    const _incoming_0 = _t_0["incoming"];
    return {$: "../../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../src/ecs/world.CapacityExceeded"}};
  }
}

function $$$$047$$$047src$047ecs$047component$058swap_world$1260$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047src$047ecs$047world$058with_store_finish$1265$(($$$$047$$$047src$047ecs$047component$058swap_store$1260$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, ($schema$058take_stock$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047src$047ecs$047world$058next_clock$(_available_0, _clock_0) {
  if (!_available_0) {
    return _clock_0;
  } else {
    return ((_clock_0 + 1) >>> 0);
  }
}

function $$$$047$$$047src$047ecs$047component$058replaced$1261$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../../src/ecs/component.Swapped") {
    const _previous_0 = _t_0["previous"];
    return {$: "../../src/ecs/component.Replaced", "world": _world_0, "previous": _previous_0};
  } else {
    const _incoming_0 = _t_0["incoming"];
    return {$: "../../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../src/ecs/world.CapacityExceeded"}};
  }
}

function $$$$047$$$047src$047ecs$047component$058swap_world$1261$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047src$047ecs$047world$058with_store_finish$1266$(($$$$047$$$047src$047ecs$047component$058swap_store$1261$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, ($schema$058take_recipe$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047src$047ecs$047compose$058family_match$1264$(_frame_0) {
  return $$$$047$$$047src$047ecs$047compose$058selected_join$1261$({$: "../../src/ecs/compose.Absent"}, ($$$$047$$$047src$047ecs$047compose$058get$1263$(_frame_0)));
}

function $$$$047$$$047src$047ecs$047compose$058selected_join$1261$(_mode_0, _observed_0) {
  const _frame_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _frame_0, "snd": ($$$$047$$$047src$047ecs$047compose$058selected_value$1261$(_mode_0, _value_0))};
}

function $$$$047$$$047src$047ecs$047compose$058get$1263$(_frame_0) {
  const _tx_0 = _frame_0["tx"];
  const _handle_0 = _frame_0["handle"];
  const _error_0 = _frame_0["error"];
  const _cursor_0 = _frame_0["cursor"];
  return $$$$047$$$047src$047ecs$047compose$058read_join$1263$(_handle_0, _error_0, _cursor_0, ($$$$047$$$047src$047ecs$047component$058tx_get$1263$(($schema$058enabled$()), _tx_0, _handle_0)));
}

function $reference$045declarations$058id_get$(_frame_0) {
  return $reference$045declarations$058id_join$(($$$$047$$$047src$047ecs$047compose$058handle_get$1260$(_frame_0)));
}

function $gameplay$058compose_queue$1261$(_id_0, _stock_0, _recipe_0, _observed_0) {
  const _ctx_0 = _observed_0["fst"];
  const _queue_0 = _observed_0["snd"];
  const _x_0 = ($json$058queue$(_queue_0));
  const _x_1 = (_x_0 + "}");
  const _x_2 = ($json$058recipe$(_recipe_0));
  const _x_3 = (",\"queue\":" + _x_1);
  const _x_4 = (_x_2 + _x_3);
  const _x_5 = ($json$058stock$(_stock_0));
  const _x_6 = (",\"recipe\":" + _x_4);
  const _x_7 = (_x_5 + _x_6);
  const _x_8 = ($U32$show$(_id_0));
  const _x_9 = (",\"stock\":" + _x_7);
  const _x_10 = (_x_8 + _x_9);
  return {$: "Tuple", "fst": _ctx_0, "snd": {$: "Tuple", "fst": {$: "../../src/ecs/transaction.Success"}, "snd": ("{\"id\":" + _x_10)}};
}

function $$$$047$$$047src$047ecs$047capabilities$058read$1265$(_ctx_0) {
  return run_tail(($$$$047$$$047src$047ecs$047capabilities$058read_field$1263$(($gameplay$058work_queue$1261$({$: "gameplay.WorkCaps", "stock": ($owned$045rows$058write_work_stock$()), "recipe": ($owned$045rows$058read_work_recipe$()), "queue": ($owned$045rows$058read_work_queue$()), "id": ($owned$045rows$058id_read_work$())})))), _ctx_0);
}

function $$$$047$$$047src$047ecs$047capabilities$058read_field$1264$(_cap_0) {
  const _get_0 = _cap_0["get"];
  return _get_0;
}

function $gameplay$058work_recipe$1261$(_caps_0) {
  const _recipe_0 = _caps_0["recipe"];
  return _recipe_0;
}

function $$$$047$$$047src$047ecs$047owned$045family$058get$1260$(_owner_0) {
  return $$$$047$$$047src$047ecs$047owned$045family$058get_taken$1260$(($owned$045rows$058take_work_stock$(_owner_0)));
}

function $$$$047$$$047src$047ecs$047owned$045family$058write_owner$1260$(_result_0) {
  if (_result_0.$ === "../../src/ecs/owned-family.Written") {
    const _owner_0 = _result_0["owner"];
    return _owner_0;
  } else {
    const _owner_1 = _result_0["owner"];
    return _owner_1;
  }
}

function $$$$047$$$047src$047ecs$047owned$045family$058write$1260$(_owner_0, _incoming_0) {
  return $$$$047$$$047src$047ecs$047owned$045family$058write_taken$1260$(_incoming_0, ($owned$045rows$058take_work_stock$(_owner_0)));
}

function $$$$047$$$047src$047ecs$047owned$045family$058get$1261$(_owner_0) {
  return $$$$047$$$047src$047ecs$047owned$045family$058get_taken$1261$(($owned$045rows$058take_work_recipe$(_owner_0)));
}

function $$$$047$$$047src$047ecs$047owned$045family$058get$1262$(_owner_0) {
  return $$$$047$$$047src$047ecs$047owned$045family$058get_taken$1262$(($owned$045rows$058take_work_queue$(_owner_0)));
}

function $owned$045rows$058id_work_header$(_stock_0, _recipe_0, _queue_0, _cold_0, _header_0) {
  const _namespace_0 = _header_0["namespace"];
  const _nextId_0 = _header_0["nextId"];
  const _live_0 = _header_0["live"];
  const _t_0 = _header_0["handle"];
  const _ns_0 = _t_0["namespace"];
  const _key_0 = _t_0["id"];
  const _clock_0 = _header_0["clock"];
  const _error_0 = _header_0["error"];
  const _cursor_0 = _header_0["cursor"];
  return {$: "Tuple", "fst": {$: "owned-rows.WorkRow", "state": {$: "owned-rows.WorkState", "header": {$: "../../src/ecs/owned-family.Header", "namespace": _namespace_0, "nextId": _nextId_0, "live": _live_0, "handle": {$: "../../src/ecs/world.Handle", "namespace": _ns_0, "id": _key_0}, "clock": _clock_0, "error": _error_0, "cursor": _cursor_0}, "stock": _stock_0, "recipe": _recipe_0, "queue": _queue_0, "cold": _cold_0}}, "snd": _key_0};
}

function $$$$047$$$047src$047ecs$047captured$045column$058plain_taken$1261$(_id_0, _stamps_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _owner_0 = _result_0["snd"];
  return {$: "../../src/ecs/captured-column.Captured", "id": _id_0, "owner": _owner_0, "stamp": ($$$$047$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0)), "restore": run_clo((_x_0) => {
  return $$$$047$$$047src$047ecs$047captured$045column$058restore_plain$1261$(_id_0, _values_0, _stamps_0, _x_0);
})};
}

function $$$$047$$$047src$047ecs$047captured$045column$058captured_prepared$1261$(_id_0, _values_0, _stamps_0, _capacity_0, _owner_0, _remaining_0, _past_0) {
  return {$: "../../src/ecs/captured-column.Captured", "id": _id_0, "owner": _owner_0, "stamp": ($$$$047$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0)), "restore": run_clo((_x_0) => {
  return $$$$047$$$047src$047ecs$047captured$045column$058restore_prepared$1261$(_id_0, _values_0, _stamps_0, _capacity_0, _remaining_0, _past_0, _x_0);
})};
}

function $$$$047$$$047src$047ecs$047captured$045column$058recovered_capture$1261$(_id_0, _column_0) {
  if (_column_0.$ === "../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047src$047ecs$047captured$045column$058plain_sized$1261$(_id_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../src/ecs/column.Indexed") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047captured$045column$058indexed_plain_state$1261$(_id_0, ($$$$047$$$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_0)));
  } else {
    return {$: "../../src/ecs/captured-column.Unavailable", "column": _column_0};
  }
}

function $$$$047$$$047src$047ecs$047captured$045column$058capture_seek$1261$($0, $1, $2, $3, $4, $5, $6, $7) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _remaining_0 = $5;
      const _past_0 = $6;
      const _phase_0 = $7;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../src/ecs/owner-handoff.HandoffNil") {
          return $$$$047$$$047src$047ecs$047captured$045column$058captured_prepared$1261$(_target_0, _values_0, _stamps_0, _capacity_0, {$: "None"}, {$: "../../src/ecs/owner-handoff.HandoffNil"}, _past_0);
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "../../src/ecs/captured-column.Unavailable", "column": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../src/ecs/owner-handoff.HandoffNil") {
          return $$$$047$$$047src$047ecs$047captured$045column$058captured_prepared$1261$(_target_0, _values_0, _stamps_0, _capacity_0, {$: "None"}, {$: "../../src/ecs/owner-handoff.HandoffNil"}, _past_0);
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _stamps_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $6 = _past_0;
            $7 = {$: "../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return $$$$047$$$047src$047ecs$047captured$045column$058captured_prepared$1261$(_target_0, _values_0, _stamps_0, _capacity_0, {$: "Some", "value": _owner_1}, _rest_1, _past_0);
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return $$$$047$$$047src$047ecs$047captured$045column$058captured_prepared$1261$(_target_0, _values_0, _stamps_0, _capacity_0, {$: "None"}, {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, _past_0);
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _stamps_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _rest_1;
                $6 = {$: "../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $7 = {$: "../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047column$058past_current$1261$(_current_0, _owner_0, _past_0, _active_0) {
  if (!_active_0) {
    return _past_0;
  } else {
    return {$: "../../src/ecs/column.HistoryCon", "id": _current_0, "value": _owner_0, "rest": _past_0};
  }
}

function $$$$047$$$047src$047ecs$047captured$045column$058indexed_plain_checked$1261$(_id_0, _metadata_0, _values_0, _valid_0) {
  if (!_valid_0) {
    return {$: "../../src/ecs/captured-column.Unavailable", "column": ($$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0))};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $$$$047$$$047src$047ecs$047captured$045column$058indexed_plain_taken$1261$(_id_0, _metadata_0, array_rmw(_values_0, _x_0, () => _x_1));
  }
}

function $$$$047$$$047src$047ecs$047captured$045column$058indexed_captured_prepared$1261$(_id_0, _values_0, _metadata_0, _capacity_0, _owner_0, _remaining_0, _past_0) {
  return $$$$047$$$047src$047ecs$047captured$045column$058indexed_captured_got$1261$(_id_0, _values_0, _capacity_0, _owner_0, _remaining_0, _past_0, ($$$$047$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047src$047ecs$047captured$045column$058indexed_capture_seek$1261$($0, $1, $2, $3, $4, $5, $6, $7) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _remaining_0 = $5;
      const _past_0 = $6;
      const _phase_0 = $7;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../src/ecs/owner-handoff.HandoffNil") {
          return $$$$047$$$047src$047ecs$047captured$045column$058indexed_captured_prepared$1261$(_target_0, _values_0, _metadata_0, _capacity_0, {$: "None"}, {$: "../../src/ecs/owner-handoff.HandoffNil"}, _past_0);
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "../../src/ecs/captured-column.Unavailable", "column": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../src/ecs/owner-handoff.HandoffNil") {
          return $$$$047$$$047src$047ecs$047captured$045column$058indexed_captured_prepared$1261$(_target_0, _values_0, _metadata_0, _capacity_0, {$: "None"}, {$: "../../src/ecs/owner-handoff.HandoffNil"}, _past_0);
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _metadata_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $6 = _past_0;
            $7 = {$: "../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return $$$$047$$$047src$047ecs$047captured$045column$058indexed_captured_prepared$1261$(_target_0, _values_0, _metadata_0, _capacity_0, {$: "Some", "value": _owner_1}, _rest_1, _past_0);
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return $$$$047$$$047src$047ecs$047captured$045column$058indexed_captured_prepared$1261$(_target_0, _values_0, _metadata_0, _capacity_0, {$: "None"}, {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, _past_0);
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _metadata_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _rest_1;
                $6 = {$: "../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $7 = {$: "../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047captured$045column$058plain_taken$1262$(_id_0, _stamps_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _owner_0 = _result_0["snd"];
  return {$: "../../src/ecs/captured-column.Captured", "id": _id_0, "owner": _owner_0, "stamp": ($$$$047$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0)), "restore": run_clo((_x_0) => {
  return $$$$047$$$047src$047ecs$047captured$045column$058restore_plain$1262$(_id_0, _values_0, _stamps_0, _x_0);
})};
}

function $$$$047$$$047src$047ecs$047captured$045column$058captured_prepared$1262$(_id_0, _values_0, _stamps_0, _capacity_0, _owner_0, _remaining_0, _past_0) {
  return {$: "../../src/ecs/captured-column.Captured", "id": _id_0, "owner": _owner_0, "stamp": ($$$$047$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0)), "restore": run_clo((_x_0) => {
  return $$$$047$$$047src$047ecs$047captured$045column$058restore_prepared$1262$(_id_0, _values_0, _stamps_0, _capacity_0, _remaining_0, _past_0, _x_0);
})};
}

function $$$$047$$$047src$047ecs$047captured$045column$058recovered_capture$1262$(_id_0, _column_0) {
  if (_column_0.$ === "../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047src$047ecs$047captured$045column$058plain_sized$1262$(_id_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../src/ecs/column.Indexed") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047captured$045column$058indexed_plain_state$1262$(_id_0, ($$$$047$$$047src$047ecs$047column$058indexed_unseal$1262$(_carrier_0)));
  } else {
    return {$: "../../src/ecs/captured-column.Unavailable", "column": _column_0};
  }
}

function $$$$047$$$047src$047ecs$047captured$045column$058capture_seek$1262$($0, $1, $2, $3, $4, $5, $6, $7) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _remaining_0 = $5;
      const _past_0 = $6;
      const _phase_0 = $7;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../src/ecs/owner-handoff.HandoffNil") {
          return $$$$047$$$047src$047ecs$047captured$045column$058captured_prepared$1262$(_target_0, _values_0, _stamps_0, _capacity_0, {$: "None"}, {$: "../../src/ecs/owner-handoff.HandoffNil"}, _past_0);
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "../../src/ecs/captured-column.Unavailable", "column": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../src/ecs/owner-handoff.HandoffNil") {
          return $$$$047$$$047src$047ecs$047captured$045column$058captured_prepared$1262$(_target_0, _values_0, _stamps_0, _capacity_0, {$: "None"}, {$: "../../src/ecs/owner-handoff.HandoffNil"}, _past_0);
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _stamps_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $6 = _past_0;
            $7 = {$: "../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return $$$$047$$$047src$047ecs$047captured$045column$058captured_prepared$1262$(_target_0, _values_0, _stamps_0, _capacity_0, {$: "Some", "value": _owner_1}, _rest_1, _past_0);
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return $$$$047$$$047src$047ecs$047captured$045column$058captured_prepared$1262$(_target_0, _values_0, _stamps_0, _capacity_0, {$: "None"}, {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, _past_0);
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _stamps_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _rest_1;
                $6 = {$: "../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $7 = {$: "../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047column$058past_current$1262$(_current_0, _owner_0, _past_0, _active_0) {
  if (!_active_0) {
    return _past_0;
  } else {
    return {$: "../../src/ecs/column.HistoryCon", "id": _current_0, "value": _owner_0, "rest": _past_0};
  }
}

function $$$$047$$$047src$047ecs$047captured$045column$058indexed_plain_checked$1262$(_id_0, _metadata_0, _values_0, _valid_0) {
  if (!_valid_0) {
    return {$: "../../src/ecs/captured-column.Unavailable", "column": ($$$$047$$$047src$047ecs$047column$058indexed_wrap$1262$(_values_0, _metadata_0))};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $$$$047$$$047src$047ecs$047captured$045column$058indexed_plain_taken$1262$(_id_0, _metadata_0, array_rmw(_values_0, _x_0, () => _x_1));
  }
}

function $$$$047$$$047src$047ecs$047captured$045column$058indexed_captured_prepared$1262$(_id_0, _values_0, _metadata_0, _capacity_0, _owner_0, _remaining_0, _past_0) {
  return $$$$047$$$047src$047ecs$047captured$045column$058indexed_captured_got$1262$(_id_0, _values_0, _capacity_0, _owner_0, _remaining_0, _past_0, ($$$$047$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047src$047ecs$047captured$045column$058indexed_capture_seek$1262$($0, $1, $2, $3, $4, $5, $6, $7) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _remaining_0 = $5;
      const _past_0 = $6;
      const _phase_0 = $7;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../src/ecs/owner-handoff.HandoffNil") {
          return $$$$047$$$047src$047ecs$047captured$045column$058indexed_captured_prepared$1262$(_target_0, _values_0, _metadata_0, _capacity_0, {$: "None"}, {$: "../../src/ecs/owner-handoff.HandoffNil"}, _past_0);
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "../../src/ecs/captured-column.Unavailable", "column": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../src/ecs/owner-handoff.HandoffNil") {
          return $$$$047$$$047src$047ecs$047captured$045column$058indexed_captured_prepared$1262$(_target_0, _values_0, _metadata_0, _capacity_0, {$: "None"}, {$: "../../src/ecs/owner-handoff.HandoffNil"}, _past_0);
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _metadata_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $6 = _past_0;
            $7 = {$: "../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return $$$$047$$$047src$047ecs$047captured$045column$058indexed_captured_prepared$1262$(_target_0, _values_0, _metadata_0, _capacity_0, {$: "Some", "value": _owner_1}, _rest_1, _past_0);
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return $$$$047$$$047src$047ecs$047captured$045column$058indexed_captured_prepared$1262$(_target_0, _values_0, _metadata_0, _capacity_0, {$: "None"}, {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, _past_0);
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _metadata_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _rest_1;
                $6 = {$: "../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $7 = {$: "../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $reference$045declarations$058match_locked$1260$(_frame_0) {
  return $$$$047$$$047src$047ecs$047compose$058family_match$1260$(_frame_0);
}

function $$$$047$$$047src$047ecs$047compose$058family_match$1262$(_frame_0) {
  return $$$$047$$$047src$047ecs$047compose$058selected_join$1262$({$: "../../src/ecs/compose.Required"}, ($$$$047$$$047src$047ecs$047compose$058get$1261$(_frame_0)));
}

function $$$$047$$$047src$047ecs$047component$058get_projected$1264$(_rest_0, _observed_0) {
  const _column_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($schema$058put_locked$(_rest_0, _column_0)), "snd": ($$$$047$$$047src$047ecs$047component$058access$1264$(_value_0))};
}

function $$$$047$$$047src$047ecs$047column$058view$1264$(_column_0, _id_0) {
  if (_column_0.$ === "../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047src$047ecs$047column$058plain_view_sized$1264$(_id_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058prepared_view_state$1264$(_id_0, ($$$$047$$$047src$047ecs$047column$058unseal$1264$(_carrier_0)));
  } else if (_column_0.$ === "../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058indexed_view_state$1264$(_id_0, ($$$$047$$$047src$047ecs$047column$058indexed_unseal$1264$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058indexed_prepared_view_state$1264$(_id_0, ($$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1264$(_carrier_2)));
  }
}

function $schema$058put_enabled$(_rest_0, _column_0) {
  const _stock_0 = _rest_0["stock"];
  const _recipe_0 = _rest_0["recipe"];
  const _queue_0 = _rest_0["queue"];
  const _locked_0 = _rest_0["locked"];
  return {$: "schema.Store", "stock": _stock_0, "recipe": _recipe_0, "queue": _queue_0, "enabled": _column_0, "locked": _locked_0};
}

function $$$$047$$$047src$047ecs$047component$058access$1263$(_value_0) {
  if (_value_0.$ === "None") {
    return {$: "../../src/ecs/component.ComponentAbsent"};
  } else {
    const _value_1 = _value_0["value"];
    return {$: "../../src/ecs/component.Found", "value": _value_1};
  }
}

function $$$$047$$$047src$047ecs$047column$058plain_view_sized$1263$(_id_0, _stamps_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047src$047ecs$047column$058plain_view_checked$1263$(_values_0, _stamps_0, _id_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047src$047ecs$047column$058prepared_view_state$1263$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047src$047ecs$047column$058prepared_view_checked$1263$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0));
}

function $$$$047$$$047src$047ecs$047column$058indexed_view_state$1263$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047src$047ecs$047column$058indexed_view_sized$1263$(_id_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepared_view_state$1263$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047src$047ecs$047column$058indexed_prepared_view_checked$1263$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0));
}

function $$$$047$$$047src$047ecs$047column$058plain_view_checked$1262$(_values_0, _stamps_0, _id_0, _valid_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "None"}};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $$$$047$$$047src$047ecs$047column$058plain_view_taken$1262$(_stamps_0, _id_0, array_rmw(_values_0, _x_0, () => _x_1));
  }
}

function $$$$047$$$047src$047ecs$047column$058prepared_view_checked$1262$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _valid_0, _same_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    if (_same_0) {
      return $$$$047$$$047src$047ecs$047column$058prepared_view_current$1262$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0);
    } else {
      return $$$$047$$$047src$047ecs$047column$058prepared_view_different$1262$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, (_id_0 < _current_0));
    }
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_view_sized$1262$(_id_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047src$047ecs$047column$058indexed_view_checked$1262$(_id_0, _values_0, _metadata_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepared_view_checked$1262$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _valid_0, _same_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    if (_same_0) {
      return $$$$047$$$047src$047ecs$047column$058indexed_prepared_view_current$1262$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0);
    } else {
      return $$$$047$$$047src$047ecs$047column$058indexed_prepared_view_different$1262$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, (_id_0 < _current_0));
    }
  }
}

function $$$$047$$$047src$047ecs$047column$058plain_view_taken$1261$(_stamps_0, _id_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "None"}};
  } else {
    const _owner_0 = _t_0["value"];
    return $$$$047$$$047src$047ecs$047column$058plain_view_projected$1261$(_values_0, _stamps_0, _id_0, ($schema$058project_recipe$(_owner_0)));
  }
}

function $$$$047$$$047src$047ecs$047column$058prepared_view_current$1261$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "None"}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    const _owned_0 = _owner_0["value"];
    return $$$$047$$$047src$047ecs$047column$058prepared_view_projected$1261$(_values_0, _stamps_0, _capacity_0, _current_0, _remaining_0, _past_0, ($schema$058project_recipe$(_owned_0)));
  }
}

function $$$$047$$$047src$047ecs$047column$058prepared_view_different$1261$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _backwards_0) {
  if (_backwards_0) {
    return $$$$047$$$047src$047ecs$047column$058view_taken$1261$(_id_0, ($$$$047$$$047src$047ecs$047column$058swap_recovered$1261$(_id_0, {$: "None"}, ($$$$047$$$047src$047ecs$047column$058recover_current$1261$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0))))));
  } else {
    const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
    const _x_1 = ((_x_0 + 1) >>> 0);
    return $$$$047$$$047src$047ecs$047column$058seek_view$1261$(_x_1, _values_0, _stamps_0, _capacity_0, _id_0, _remaining_0, ($$$$047$$$047src$047ecs$047column$058past_current$1261$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../src/ecs/column.Inspect"});
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_view_checked$1261$(_id_0, _values_0, _metadata_0, _valid_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": ($$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0)), "snd": {$: "None"}};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $$$$047$$$047src$047ecs$047column$058indexed_view_taken$1261$(_id_0, _metadata_0, array_rmw(_values_0, _x_0, () => _x_1));
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepared_view_current$1261$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "None"}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    const _owned_0 = _owner_0["value"];
    return $$$$047$$$047src$047ecs$047column$058indexed_prepared_view_projected$1261$(_values_0, _metadata_0, _capacity_0, _current_0, _remaining_0, _past_0, ($schema$058project_recipe$(_owned_0)));
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepared_view_different$1261$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _backwards_0) {
  if (_backwards_0) {
    return $$$$047$$$047src$047ecs$047column$058view_taken$1261$(_id_0, ($$$$047$$$047src$047ecs$047column$058swap_recovered$1261$(_id_0, {$: "None"}, ($$$$047$$$047src$047ecs$047column$058indexed_recover_current$1261$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0))))));
  } else {
    const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
    const _x_1 = ((_x_0 + 1) >>> 0);
    return $$$$047$$$047src$047ecs$047column$058indexed_seek_view$1261$(_x_1, _values_0, _metadata_0, _capacity_0, _id_0, _remaining_0, ($$$$047$$$047src$047ecs$047column$058past_current$1261$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../src/ecs/column.Inspect"});
  }
}

function $$$$047$$$047src$047ecs$047column$058plain_view_projected$1260$(_values_0, _stamps_0, _id_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = {$: "Some", "value": _owner_0};
  return $$$$047$$$047src$047ecs$047column$058restored$1260$(array_rmw(_values_0, _x_0, () => _x_1), _projection_0, _stamps_0);
}

function $schema$058project_stock$(_owner_0) {
  const _value_0 = _owner_0["value"];
  const _array_0 = _owner_0["owned"];
  const _length_0 = _owner_0["length"];
  return $schema$058project_stock_join$(_value_0, _length_0, ($schema$058array_view$(_array_0)));
}

function $$$$047$$$047src$047ecs$047column$058prepared_view_projected$1260$(_values_0, _stamps_0, _capacity_0, _current_0, _remaining_0, _past_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "Some", "value": _owner_0}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047$$$047src$047ecs$047column$058view_taken$1260$(_id_0, _outcome_0) {
  if (_outcome_0.$ === "../../src/ecs/column.Rejected") {
    const _column_0 = _outcome_0["column"];
    return {$: "Tuple", "fst": _column_0, "snd": {$: "None"}};
  } else {
    const _column_1 = _outcome_0["column"];
    const _t_0 = _outcome_0["previous"];
    if (_t_0.$ === "None") {
      return {$: "Tuple", "fst": _column_1, "snd": {$: "None"}};
    } else {
      const _owner_0 = _t_0["value"];
      return $$$$047$$$047src$047ecs$047column$058viewed$1260$(($schema$058project_stock$(_owner_0)), _column_1, _id_0);
    }
  }
}

function $$$$047$$$047src$047ecs$047column$058swap_recovered$1260$(_id_0, _incoming_0, _column_0) {
  if (_column_0.$ === "../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047src$047ecs$047column$058swap_sized$1260$(_id_0, _incoming_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../src/ecs/column.Indexed") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058indexed_swap_state$1260$(_id_0, _incoming_0, ($$$$047$$$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_0)));
  } else {
    return {$: "../../src/ecs/column.Rejected", "column": _column_0, "incoming": _incoming_0};
  }
}

function $$$$047$$$047src$047ecs$047column$058seek_view$1260$($0, $1, $2, $3, $4, $5, $6, $7) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _remaining_0 = $5;
      const _past_0 = $6;
      const _phase_0 = $7;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "Tuple", "fst": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "snd": {$: "None"}};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _stamps_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $6 = _past_0;
            $7 = {$: "../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return $$$$047$$$047src$047ecs$047column$058prepared_view_projected$1260$(_values_0, _stamps_0, _capacity_0, _target_0, _rest_1, _past_0, ($schema$058project_stock$(_owner_1)));
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "Tuple", "fst": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "snd": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _stamps_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _rest_1;
                $6 = {$: "../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $7 = {$: "../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_view_taken$1260$(_id_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "Tuple", "fst": ($$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "snd": {$: "None"}};
  } else {
    const _owner_0 = _t_0["value"];
    return $$$$047$$$047src$047ecs$047column$058indexed_view_projected$1260$(_id_0, _values_0, _metadata_0, ($schema$058project_stock$(_owner_0)));
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepared_view_projected$1260$(_values_0, _metadata_0, _capacity_0, _current_0, _remaining_0, _past_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "Some", "value": _owner_0}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047$$$047src$047ecs$047column$058indexed_seek_view$1260$($0, $1, $2, $3, $4, $5, $6, $7) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _remaining_0 = $5;
      const _past_0 = $6;
      const _phase_0 = $7;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "Tuple", "fst": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "snd": {$: "None"}};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _metadata_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $6 = _past_0;
            $7 = {$: "../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return $$$$047$$$047src$047ecs$047column$058indexed_prepared_view_projected$1260$(_values_0, _metadata_0, _capacity_0, _target_0, _rest_1, _past_0, ($schema$058project_stock$(_owner_1)));
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "Tuple", "fst": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "snd": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _metadata_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _rest_1;
                $6 = {$: "../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $7 = {$: "../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047capabilities$058read_field$1265$(_cap_0) {
  const _get_0 = _cap_0["get"];
  return _get_0;
}

function $gameplay$058duplicate_r$1261$(_caps_0) {
  const _r_0 = _caps_0["r"];
  return _r_0;
}

function $$$$047$$$047src$047ecs$047owned$045family$058get_taken$1263$(_observed_0) {
  const _rest_0 = _observed_0["fst"];
  const _cell_0 = _observed_0["snd"];
  return $$$$047$$$047src$047ecs$047owned$045family$058get_split$1263$(_cell_0, ($owned$045rows$058header_duplicate_stock$(_rest_0)));
}

function $owned$045rows$058take_duplicate_stock$($0) {
  for (;;) {
    {
      const _row_0 = $0;
      if (_row_0.$ === "owned-rows.DuplicateRow") {
        const _t_0 = _row_0["state"];
        const _header_0 = _t_0["header"];
        const _stock_0 = _t_0["stock"];
        const _cold_0 = _t_0["cold"];
        return {$: "Tuple", "fst": {$: "owned-rows.DuplicateStockRest", "header": _header_0, "cold": _cold_0}, "snd": _stock_0};
      } else {
        const _inner_0 = _row_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047owned$045family$058write_taken$1263$(_incoming_0, _observed_0) {
  const _rest_0 = _observed_0["fst"];
  const _cell_0 = _observed_0["snd"];
  return $$$$047$$$047src$047ecs$047owned$045family$058write_split$1263$(_cell_0, _incoming_0, ($owned$045rows$058header_duplicate_stock$(_rest_0)));
}

function $$$$047$$$047src$047ecs$047lifecycle$058get$(_entries_0, _id_0) {
  if (_entries_0.$ === "Nil") {
    return {$: "../../src/ecs/lifecycle.Stamp", "added": 0, "changed": 0};
  } else {
    const _t_0 = _entries_0["head"];
    const _key_0 = _t_0["id"];
    const _stamp_0 = _t_0["stamp"];
    const _rest_0 = _entries_0["tail"];
    return $$$$047$$$047src$047ecs$047lifecycle$058choose$((_key_0 === _id_0), _stamp_0, ($$$$047$$$047src$047ecs$047lifecycle$058get$(_rest_0, _id_0)));
  }
}

function $$$$047$$$047src$047ecs$047captured$045column$058restore_plain$1260$(_id_0, _values_0, _stamps_0, _slot_0) {
  const _owner_0 = _slot_0["owner"];
  const _stamp_0 = _slot_0["stamp"];
  const _dirty_0 = _slot_0["dirty"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  return $$$$047$$$047src$047ecs$047captured$045column$058stamped$1260$(_id_0, {$: "../../src/ecs/column.Column", "values": (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0), "stamps": _stamps_0}, _stamp_0, _dirty_0);
}

function $$$$047$$$047src$047ecs$047captured$045column$058restore_prepared$1260$(_id_0, _values_0, _stamps_0, _capacity_0, _remaining_0, _past_0, _slot_0) {
  const _owner_0 = _slot_0["owner"];
  const _stamp_0 = _slot_0["stamp"];
  const _dirty_0 = _slot_0["dirty"];
  return $$$$047$$$047src$047ecs$047captured$045column$058stamped$1260$(_id_0, {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _id_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, _stamp_0, _dirty_0);
}

function $$$$047$$$047src$047ecs$047captured$045column$058indexed_plain_taken$1260$(_id_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _owner_0 = _result_0["snd"];
  return $$$$047$$$047src$047ecs$047captured$045column$058indexed_plain_got$1260$(_id_0, _values_0, _owner_0, ($$$$047$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047src$047ecs$047captured$045column$058indexed_captured_got$1260$(_id_0, _values_0, _capacity_0, _owner_0, _remaining_0, _past_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "../../src/ecs/captured-column.Captured", "id": _id_0, "owner": _owner_0, "stamp": _stamp_0, "restore": run_clo((_x_0) => {
  return $$$$047$$$047src$047ecs$047captured$045column$058indexed_restore_prepared$1260$(_id_0, _values_0, _metadata_0, _capacity_0, _remaining_0, _past_0, _x_0);
})};
}

function $$$$047$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0) {
  const _added_0 = _metadata_0["added"];
  const _changed_0 = _metadata_0["changed"];
  const _capacity_0 = _metadata_0["capacity"];
  const _depth_0 = _metadata_0["depth"];
  const _exceptional_0 = _metadata_0["exceptional"];
  return $$$$047$$$047src$047ecs$047indexed$045lifecycle$058get_checked$(_id_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, ($$$$047$$$047src$047ecs$047indexed$045lifecycle$058normal$(_id_0)), (_id_0 <= _capacity_0));
}

function $$$$047$$$047src$047ecs$047owned$045compose$058finish_returned$1260$(_values_0, _returned_0) {
  const _world_0 = _returned_0["world"];
  const _t_0 = _returned_0["outcome"];
  if (_t_0.$ === "../../src/ecs/transaction.Success") {
    return {$: "../../src/ecs/compose.Executed", "world": _world_0, "outcome": {$: "../../src/ecs/transaction.Success"}, "values": _values_0};
  } else {
    const _error_0 = _t_0["error"];
    return {$: "../../src/ecs/compose.Executed", "world": _world_0, "outcome": {$: "../../src/ecs/transaction.Failure", "error": _error_0}, "values": {$: "Nil"}};
  }
}

function $$$$047$$$047src$047ecs$047owned$045compose$058selected_fields$1260$(_args_0, _next_0, _observed_0) {
  const _t_0 = _observed_0["fst"];
  const _tx_0 = _t_0["tx"];
  const __0 = _t_0["handle"];
  const __1 = _t_0["error"];
  const __2 = _t_0["cursor"];
  const _t_1 = _observed_0["snd"];
  if (!_t_1) {
    return run_tail(_next_0, _tx_0);
  } else {
    return $$$$047$$$047src$047ecs$047owned$045compose$058body_returned$1260$(_next_0, ($$$$047$$$047src$047ecs$047owned$045compose$058left$1260$(($$$$047$$$047src$047ecs$047capabilities$058invoke$1267$(_args_0, ($owned$045rows$058enter_work$({$: "../../src/ecs/compose.Frame", "tx": _tx_0, "handle": __0, "error": __1, "cursor": __2})))))));
  }
}

function $$$$047$$$047src$047ecs$047column$058clear_stamp$1260$(_column_0, _id_0) {
  if (_column_0.$ === "../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../src/ecs/column.Column", "values": _values_0, "stamps": ($$$$047$$$047src$047ecs$047lifecycle$058clear$(_stamps_0, _id_0))};
  } else if (_column_0.$ === "../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058clear_state$1260$(_id_0, ($$$$047$$$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
  } else if (_column_0.$ === "../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058indexed_clear_state$1260$(_id_0, ($$$$047$$$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058indexed_prepared_clear_state$1260$(_id_0, ($$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
  }
}

function $$$$047$$$047src$047ecs$047column$058swap_sized$1260$(_id_0, _incoming_0, _stamps_0, _sized_0) {
  const _values_0 = _sized_0["fst"];
  const _size_0 = _sized_0["snd"];
  return $$$$047$$$047src$047ecs$047column$058swap_checked$1260$(_values_0, _stamps_0, _id_0, _incoming_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047src$047ecs$047column$058swap_state$1260$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047src$047ecs$047column$058prepared_swap$1260$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0), (_id_0 < _current_0));
}

function $$$$047$$$047src$047ecs$047column$058indexed_swap_state$1260$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047src$047ecs$047column$058indexed_swap_sized$1260$(_id_0, _incoming_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepared_swap_state$1260$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047src$047ecs$047column$058indexed_prepared_swap$1260$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0), (_id_0 < _current_0));
}

function $$$$047$$$047src$047ecs$047column$058clear_stamp$1261$(_column_0, _id_0) {
  if (_column_0.$ === "../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../src/ecs/column.Column", "values": _values_0, "stamps": ($$$$047$$$047src$047ecs$047lifecycle$058clear$(_stamps_0, _id_0))};
  } else if (_column_0.$ === "../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058clear_state$1261$(_id_0, ($$$$047$$$047src$047ecs$047column$058unseal$1261$(_carrier_0)));
  } else if (_column_0.$ === "../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058indexed_clear_state$1261$(_id_0, ($$$$047$$$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058indexed_prepared_clear_state$1261$(_id_0, ($$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1261$(_carrier_2)));
  }
}

function $$$$047$$$047src$047ecs$047column$058swap_sized$1261$(_id_0, _incoming_0, _stamps_0, _sized_0) {
  const _values_0 = _sized_0["fst"];
  const _size_0 = _sized_0["snd"];
  return $$$$047$$$047src$047ecs$047column$058swap_checked$1261$(_values_0, _stamps_0, _id_0, _incoming_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047src$047ecs$047column$058swap_state$1261$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047src$047ecs$047column$058prepared_swap$1261$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0), (_id_0 < _current_0));
}

function $$$$047$$$047src$047ecs$047column$058indexed_swap_state$1261$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047src$047ecs$047column$058indexed_swap_sized$1261$(_id_0, _incoming_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepared_swap_state$1261$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047src$047ecs$047column$058indexed_prepared_swap$1261$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0), (_id_0 < _current_0));
}

function $$$$047$$$047src$047ecs$047column$058clear_stamp$1262$(_column_0, _id_0) {
  if (_column_0.$ === "../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../src/ecs/column.Column", "values": _values_0, "stamps": ($$$$047$$$047src$047ecs$047lifecycle$058clear$(_stamps_0, _id_0))};
  } else if (_column_0.$ === "../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058clear_state$1262$(_id_0, ($$$$047$$$047src$047ecs$047column$058unseal$1262$(_carrier_0)));
  } else if (_column_0.$ === "../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058indexed_clear_state$1262$(_id_0, ($$$$047$$$047src$047ecs$047column$058indexed_unseal$1262$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058indexed_prepared_clear_state$1262$(_id_0, ($$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1262$(_carrier_2)));
  }
}

function $$$$047$$$047src$047ecs$047column$058swap_sized$1262$(_id_0, _incoming_0, _stamps_0, _sized_0) {
  const _values_0 = _sized_0["fst"];
  const _size_0 = _sized_0["snd"];
  return $$$$047$$$047src$047ecs$047column$058swap_checked$1262$(_values_0, _stamps_0, _id_0, _incoming_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047src$047ecs$047column$058swap_state$1262$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047src$047ecs$047column$058prepared_swap$1262$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0), (_id_0 < _current_0));
}

function $$$$047$$$047src$047ecs$047column$058indexed_swap_state$1262$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047src$047ecs$047column$058indexed_swap_sized$1262$(_id_0, _incoming_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepared_swap_state$1262$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047src$047ecs$047column$058indexed_prepared_swap$1262$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0), (_id_0 < _current_0));
}

function $$$$047$$$047src$047ecs$047column$058clear_stamp$1263$(_column_0, _id_0) {
  if (_column_0.$ === "../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../src/ecs/column.Column", "values": _values_0, "stamps": ($$$$047$$$047src$047ecs$047lifecycle$058clear$(_stamps_0, _id_0))};
  } else if (_column_0.$ === "../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058clear_state$1263$(_id_0, ($$$$047$$$047src$047ecs$047column$058unseal$1263$(_carrier_0)));
  } else if (_column_0.$ === "../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058indexed_clear_state$1263$(_id_0, ($$$$047$$$047src$047ecs$047column$058indexed_unseal$1263$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058indexed_prepared_clear_state$1263$(_id_0, ($$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1263$(_carrier_2)));
  }
}

function $$$$047$$$047src$047ecs$047column$058swap_sized$1263$(_id_0, _incoming_0, _stamps_0, _sized_0) {
  const _values_0 = _sized_0["fst"];
  const _size_0 = _sized_0["snd"];
  return $$$$047$$$047src$047ecs$047column$058swap_checked$1263$(_values_0, _stamps_0, _id_0, _incoming_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047src$047ecs$047column$058swap_state$1263$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047src$047ecs$047column$058prepared_swap$1263$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0), (_id_0 < _current_0));
}

function $$$$047$$$047src$047ecs$047column$058indexed_swap_state$1263$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047src$047ecs$047column$058indexed_swap_sized$1263$(_id_0, _incoming_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepared_swap_state$1263$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047src$047ecs$047column$058indexed_prepared_swap$1263$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0), (_id_0 < _current_0));
}

function $$$$047$$$047src$047ecs$047column$058clear_stamp$1264$(_column_0, _id_0) {
  if (_column_0.$ === "../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../src/ecs/column.Column", "values": _values_0, "stamps": ($$$$047$$$047src$047ecs$047lifecycle$058clear$(_stamps_0, _id_0))};
  } else if (_column_0.$ === "../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058clear_state$1264$(_id_0, ($$$$047$$$047src$047ecs$047column$058unseal$1264$(_carrier_0)));
  } else if (_column_0.$ === "../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058indexed_clear_state$1264$(_id_0, ($$$$047$$$047src$047ecs$047column$058indexed_unseal$1264$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058indexed_prepared_clear_state$1264$(_id_0, ($$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1264$(_carrier_2)));
  }
}

function $$$$047$$$047src$047ecs$047column$058swap_sized$1264$(_id_0, _incoming_0, _stamps_0, _sized_0) {
  const _values_0 = _sized_0["fst"];
  const _size_0 = _sized_0["snd"];
  return $$$$047$$$047src$047ecs$047column$058swap_checked$1264$(_values_0, _stamps_0, _id_0, _incoming_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047src$047ecs$047column$058swap_state$1264$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047src$047ecs$047column$058prepared_swap$1264$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0), (_id_0 < _current_0));
}

function $$$$047$$$047src$047ecs$047column$058indexed_swap_state$1264$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047src$047ecs$047column$058indexed_swap_sized$1264$(_id_0, _incoming_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepared_swap_state$1264$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047src$047ecs$047column$058indexed_prepared_swap$1264$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0), (_id_0 < _current_0));
}

function $$$$047$$$047src$047ecs$047component$058replaced$1264$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../../src/ecs/component.Swapped") {
    const _previous_0 = _t_0["previous"];
    return {$: "../../src/ecs/component.Replaced", "world": _world_0, "previous": _previous_0};
  } else {
    const _incoming_0 = _t_0["incoming"];
    return {$: "../../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../src/ecs/world.CapacityExceeded"}};
  }
}

function $$$$047$$$047src$047ecs$047component$058swap_world$1264$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047src$047ecs$047world$058with_store_finish$1269$(($$$$047$$$047src$047ecs$047component$058swap_store$1264$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, ($schema$058take_locked$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047src$047ecs$047component$058replaced$1263$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../../src/ecs/component.Swapped") {
    const _previous_0 = _t_0["previous"];
    return {$: "../../src/ecs/component.Replaced", "world": _world_0, "previous": _previous_0};
  } else {
    const _incoming_0 = _t_0["incoming"];
    return {$: "../../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../src/ecs/world.CapacityExceeded"}};
  }
}

function $$$$047$$$047src$047ecs$047component$058swap_world$1263$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047src$047ecs$047world$058with_store_finish$1268$(($$$$047$$$047src$047ecs$047component$058swap_store$1263$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, ($schema$058take_enabled$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047src$047ecs$047owned$045compose$058run_handles_fields$1266$(_handles_0, _args_0, _cursor_0, _tx_0) {
  if (_handles_0.$ === "Nil") {
    return {$: "Tuple", "fst": _tx_0, "snd": {$: "Tuple", "fst": {$: "../../src/ecs/transaction.Success"}, "snd": {$: "Nil"}}};
  } else {
    const _handle_0 = _handles_0["head"];
    const _rest_0 = _handles_0["tail"];
    return $$$$047$$$047src$047ecs$047owned$045compose$058selected_fields$1266$(_args_0, run_clo((_x_0) => {
  return $$$$047$$$047src$047ecs$047owned$045compose$058run_handles_fields$1266$(_rest_0, _args_0, _cursor_0, _x_0);
}), ($reference$045declarations$058triple_match$({$: "../../src/ecs/compose.Frame", "tx": _tx_0, "handle": _handle_0, "error": {$: "None"}, "cursor": _cursor_0})));
  }
}

function $$$$047$$$047src$047ecs$047component$058replace_clock$1262$(_id_0, _incoming_0, _clocked_0) {
  const _world_0 = _clocked_0["fst"];
  const _tick_0 = _clocked_0["snd"];
  return $$$$047$$$047src$047ecs$047component$058replace_clock_checked$1262$((_tick_0 < 4294967295), _world_0, _id_0, ($$$$047$$$047src$047ecs$047component$058owner_present$1262$(_incoming_0)));
}

function $schema$058recover_advanced$(_store_0) {
  const _stock_0 = _store_0["stock"];
  const _recipe_0 = _store_0["recipe"];
  const _queue_0 = _store_0["queue"];
  const _enabled_0 = _store_0["enabled"];
  const _locked_0 = _store_0["locked"];
  return {$: "schema.Store", "stock": ($$$$047$$$047src$047ecs$047column$058recover$1260$(_stock_0)), "recipe": _recipe_0, "queue": ($$$$047$$$047src$047ecs$047column$058recover$1262$(_queue_0)), "enabled": ($$$$047$$$047src$047ecs$047column$058recover$1263$(_enabled_0)), "locked": ($$$$047$$$047src$047ecs$047column$058recover$1264$(_locked_0))};
}

function $$$$047$$$047src$047ecs$047owned$045compose$058finished$1262$(_observed_0) {
  const _tx_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  const _result_0 = _t_0["fst"];
  const _values_0 = _t_0["snd"];
  return $$$$047$$$047src$047ecs$047owned$045compose$058finish_returned$1262$(_values_0, ($$$$047$$$047src$047ecs$047commands$058tx_finish$1260$(_tx_0, _result_0)));
}

function $$$$047$$$047src$047ecs$047owned$045compose$058run_handles_fields$1265$(_handles_0, _args_0, _cursor_0, _tx_0) {
  if (_handles_0.$ === "Nil") {
    return {$: "Tuple", "fst": _tx_0, "snd": {$: "Tuple", "fst": {$: "../../src/ecs/transaction.Success"}, "snd": {$: "Nil"}}};
  } else {
    const _handle_0 = _handles_0["head"];
    const _rest_0 = _handles_0["tail"];
    return $$$$047$$$047src$047ecs$047owned$045compose$058selected_fields$1265$(_args_0, run_clo((_x_0) => {
  return $$$$047$$$047src$047ecs$047owned$045compose$058run_handles_fields$1265$(_rest_0, _args_0, _cursor_0, _x_0);
}), ($reference$045declarations$058advanced_match$({$: "../../src/ecs/compose.Frame", "tx": _tx_0, "handle": _handle_0, "error": {$: "None"}, "cursor": _cursor_0})));
  }
}

function $$$$047$$$047src$047ecs$047world$058with_store_finish$1265$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047src$047ecs$047component$058swap_store$1260$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047src$047ecs$047component$058swap_join$1260$(_rest_0, _id_0, _incomingPresent_0, _tick_0, ($$$$047$$$047src$047ecs$047column$058swap$1260$(($$$$047$$$047src$047ecs$047column$058ensure$1260$(_column_0, _id_0)), _id_0, _incoming_0)));
}

function $$$$047$$$047src$047ecs$047world$058with_store_finish$1266$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047src$047ecs$047component$058swap_store$1261$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047src$047ecs$047component$058swap_join$1261$(_rest_0, _id_0, _incomingPresent_0, _tick_0, ($$$$047$$$047src$047ecs$047column$058swap$1261$(($$$$047$$$047src$047ecs$047column$058ensure$1261$(_column_0, _id_0)), _id_0, _incoming_0)));
}

function $$$$047$$$047src$047ecs$047compose$058selected_value$1261$(_mode_0, _value_0) {
  if (_mode_0.$ === "../../src/ecs/compose.Required") {
    if (_value_0.$ === "../../src/ecs/component.Found") {
      return true;
    } else {
      return false;
    }
  } else if (_mode_0.$ === "../../src/ecs/compose.Present") {
    if (_value_0.$ === "../../src/ecs/component.Found") {
      return true;
    } else {
      return false;
    }
  } else if (_mode_0.$ === "../../src/ecs/compose.Absent") {
    if (_value_0.$ === "../../src/ecs/component.ComponentAbsent") {
      return true;
    } else {
      return false;
    }
  } else {
    if (_value_0.$ === "../../src/ecs/component.Found") {
      return true;
    } else if (_value_0.$ === "../../src/ecs/component.ComponentAbsent") {
      return true;
    } else {
      return false;
    }
  }
}

function $$$$047$$$047src$047ecs$047compose$058read_join$1263$(_handle_0, _error_0, _cursor_0, _observed_0) {
  const _tx_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../src/ecs/compose.Frame", "tx": _tx_0, "handle": _handle_0, "error": _error_0, "cursor": _cursor_0}, "snd": _value_0};
}

function $$$$047$$$047src$047ecs$047component$058tx_get$1263$(_family_0, _tx_0, _handle_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047src$047ecs$047component$058tx_get_join$1263$(_undo_0, _commands_0, _events_0, ($$$$047$$$047src$047ecs$047component$058get$1263$(_family_0, _world_0, _handle_0)));
}

function $reference$045declarations$058id_join$(_observed_0) {
  const _frame_0 = _observed_0["fst"];
  const _handle_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _frame_0, "snd": ($observe$058handle_id$(_handle_0))};
}

function $$$$047$$$047src$047ecs$047compose$058handle_get$1260$(_frame_0) {
  const _tx_0 = _frame_0["tx"];
  const _handle_0 = _frame_0["handle"];
  const _error_0 = _frame_0["error"];
  const _cursor_0 = _frame_0["cursor"];
  return {$: "Tuple", "fst": {$: "../../src/ecs/compose.Frame", "tx": _tx_0, "handle": _handle_0, "error": _error_0, "cursor": _cursor_0}, "snd": _handle_0};
}

function $$$$047$$$047src$047ecs$047capabilities$058read_field$1263$(_cap_0) {
  const _get_0 = _cap_0["get"];
  return _get_0;
}

function $gameplay$058work_queue$1261$(_caps_0) {
  const _queue_0 = _caps_0["queue"];
  return _queue_0;
}

function $$$$047$$$047src$047ecs$047owned$045family$058get_taken$1260$(_observed_0) {
  const _rest_0 = _observed_0["fst"];
  const _cell_0 = _observed_0["snd"];
  return $$$$047$$$047src$047ecs$047owned$045family$058get_split$1260$(_cell_0, ($owned$045rows$058header_work_stock$(_rest_0)));
}

function $owned$045rows$058take_work_stock$($0) {
  for (;;) {
    {
      const _row_0 = $0;
      if (_row_0.$ === "owned-rows.WorkRow") {
        const _t_0 = _row_0["state"];
        const _header_0 = _t_0["header"];
        const _stock_0 = _t_0["stock"];
        const _recipe_0 = _t_0["recipe"];
        const _queue_0 = _t_0["queue"];
        const _cold_0 = _t_0["cold"];
        return {$: "Tuple", "fst": {$: "owned-rows.WorkStockRest", "header": _header_0, "recipe": _recipe_0, "queue": _queue_0, "cold": _cold_0}, "snd": _stock_0};
      } else {
        const _inner_0 = _row_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047owned$045family$058write_taken$1260$(_incoming_0, _observed_0) {
  const _rest_0 = _observed_0["fst"];
  const _cell_0 = _observed_0["snd"];
  return $$$$047$$$047src$047ecs$047owned$045family$058write_split$1260$(_cell_0, _incoming_0, ($owned$045rows$058header_work_stock$(_rest_0)));
}

function $$$$047$$$047src$047ecs$047owned$045family$058get_taken$1261$(_observed_0) {
  const _rest_0 = _observed_0["fst"];
  const _cell_0 = _observed_0["snd"];
  return $$$$047$$$047src$047ecs$047owned$045family$058get_split$1261$(_cell_0, ($owned$045rows$058header_work_recipe$(_rest_0)));
}

function $owned$045rows$058take_work_recipe$($0) {
  for (;;) {
    {
      const _row_0 = $0;
      if (_row_0.$ === "owned-rows.WorkRow") {
        const _t_0 = _row_0["state"];
        const _header_0 = _t_0["header"];
        const _stock_0 = _t_0["stock"];
        const _recipe_0 = _t_0["recipe"];
        const _queue_0 = _t_0["queue"];
        const _cold_0 = _t_0["cold"];
        return {$: "Tuple", "fst": {$: "owned-rows.WorkRecipeRest", "header": _header_0, "stock": _stock_0, "queue": _queue_0, "cold": _cold_0}, "snd": _recipe_0};
      } else {
        const _inner_0 = _row_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047owned$045family$058get_taken$1262$(_observed_0) {
  const _rest_0 = _observed_0["fst"];
  const _cell_0 = _observed_0["snd"];
  return $$$$047$$$047src$047ecs$047owned$045family$058get_split$1262$(_cell_0, ($owned$045rows$058header_work_queue$(_rest_0)));
}

function $owned$045rows$058take_work_queue$($0) {
  for (;;) {
    {
      const _row_0 = $0;
      if (_row_0.$ === "owned-rows.WorkRow") {
        const _t_0 = _row_0["state"];
        const _header_0 = _t_0["header"];
        const _stock_0 = _t_0["stock"];
        const _recipe_0 = _t_0["recipe"];
        const _queue_0 = _t_0["queue"];
        const _cold_0 = _t_0["cold"];
        return {$: "Tuple", "fst": {$: "owned-rows.WorkQueueRest", "header": _header_0, "stock": _stock_0, "recipe": _recipe_0, "cold": _cold_0}, "snd": _queue_0};
      } else {
        const _inner_0 = _row_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047captured$045column$058restore_plain$1261$(_id_0, _values_0, _stamps_0, _slot_0) {
  const _owner_0 = _slot_0["owner"];
  const _stamp_0 = _slot_0["stamp"];
  const _dirty_0 = _slot_0["dirty"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  return $$$$047$$$047src$047ecs$047captured$045column$058stamped$1261$(_id_0, {$: "../../src/ecs/column.Column", "values": (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0), "stamps": _stamps_0}, _stamp_0, _dirty_0);
}

function $$$$047$$$047src$047ecs$047captured$045column$058restore_prepared$1261$(_id_0, _values_0, _stamps_0, _capacity_0, _remaining_0, _past_0, _slot_0) {
  const _owner_0 = _slot_0["owner"];
  const _stamp_0 = _slot_0["stamp"];
  const _dirty_0 = _slot_0["dirty"];
  return $$$$047$$$047src$047ecs$047captured$045column$058stamped$1261$(_id_0, {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _id_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, _stamp_0, _dirty_0);
}

function $$$$047$$$047src$047ecs$047captured$045column$058indexed_plain_taken$1261$(_id_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _owner_0 = _result_0["snd"];
  return $$$$047$$$047src$047ecs$047captured$045column$058indexed_plain_got$1261$(_id_0, _values_0, _owner_0, ($$$$047$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047src$047ecs$047captured$045column$058indexed_captured_got$1261$(_id_0, _values_0, _capacity_0, _owner_0, _remaining_0, _past_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "../../src/ecs/captured-column.Captured", "id": _id_0, "owner": _owner_0, "stamp": _stamp_0, "restore": run_clo((_x_0) => {
  return $$$$047$$$047src$047ecs$047captured$045column$058indexed_restore_prepared$1261$(_id_0, _values_0, _metadata_0, _capacity_0, _remaining_0, _past_0, _x_0);
})};
}

function $$$$047$$$047src$047ecs$047captured$045column$058restore_plain$1262$(_id_0, _values_0, _stamps_0, _slot_0) {
  const _owner_0 = _slot_0["owner"];
  const _stamp_0 = _slot_0["stamp"];
  const _dirty_0 = _slot_0["dirty"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  return $$$$047$$$047src$047ecs$047captured$045column$058stamped$1262$(_id_0, {$: "../../src/ecs/column.Column", "values": (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0), "stamps": _stamps_0}, _stamp_0, _dirty_0);
}

function $$$$047$$$047src$047ecs$047captured$045column$058restore_prepared$1262$(_id_0, _values_0, _stamps_0, _capacity_0, _remaining_0, _past_0, _slot_0) {
  const _owner_0 = _slot_0["owner"];
  const _stamp_0 = _slot_0["stamp"];
  const _dirty_0 = _slot_0["dirty"];
  return $$$$047$$$047src$047ecs$047captured$045column$058stamped$1262$(_id_0, {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _id_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, _stamp_0, _dirty_0);
}

function $$$$047$$$047src$047ecs$047captured$045column$058indexed_plain_taken$1262$(_id_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _owner_0 = _result_0["snd"];
  return $$$$047$$$047src$047ecs$047captured$045column$058indexed_plain_got$1262$(_id_0, _values_0, _owner_0, ($$$$047$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047src$047ecs$047captured$045column$058indexed_captured_got$1262$(_id_0, _values_0, _capacity_0, _owner_0, _remaining_0, _past_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "../../src/ecs/captured-column.Captured", "id": _id_0, "owner": _owner_0, "stamp": _stamp_0, "restore": run_clo((_x_0) => {
  return $$$$047$$$047src$047ecs$047captured$045column$058indexed_restore_prepared$1262$(_id_0, _values_0, _metadata_0, _capacity_0, _remaining_0, _past_0, _x_0);
})};
}

function $$$$047$$$047src$047ecs$047compose$058family_match$1260$(_frame_0) {
  return $$$$047$$$047src$047ecs$047compose$058selected_join$1260$({$: "../../src/ecs/compose.Absent"}, ($$$$047$$$047src$047ecs$047compose$058get$1264$(_frame_0)));
}

function $$$$047$$$047src$047ecs$047compose$058selected_join$1262$(_mode_0, _observed_0) {
  const _frame_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _frame_0, "snd": ($$$$047$$$047src$047ecs$047compose$058selected_value$1262$(_mode_0, _value_0))};
}

function $$$$047$$$047src$047ecs$047compose$058get$1261$(_frame_0) {
  const _tx_0 = _frame_0["tx"];
  const _handle_0 = _frame_0["handle"];
  const _error_0 = _frame_0["error"];
  const _cursor_0 = _frame_0["cursor"];
  return $$$$047$$$047src$047ecs$047compose$058read_join$1261$(_handle_0, _error_0, _cursor_0, ($$$$047$$$047src$047ecs$047component$058tx_get$1261$(($schema$058recipe$()), _tx_0, _handle_0)));
}

function $schema$058put_locked$(_rest_0, _column_0) {
  const _stock_0 = _rest_0["stock"];
  const _recipe_0 = _rest_0["recipe"];
  const _queue_0 = _rest_0["queue"];
  const _enabled_0 = _rest_0["enabled"];
  return {$: "schema.Store", "stock": _stock_0, "recipe": _recipe_0, "queue": _queue_0, "enabled": _enabled_0, "locked": _column_0};
}

function $$$$047$$$047src$047ecs$047component$058access$1264$(_value_0) {
  if (_value_0.$ === "None") {
    return {$: "../../src/ecs/component.ComponentAbsent"};
  } else {
    const _value_1 = _value_0["value"];
    return {$: "../../src/ecs/component.Found", "value": _value_1};
  }
}

function $$$$047$$$047src$047ecs$047column$058plain_view_sized$1264$(_id_0, _stamps_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047src$047ecs$047column$058plain_view_checked$1264$(_values_0, _stamps_0, _id_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047src$047ecs$047column$058prepared_view_state$1264$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047src$047ecs$047column$058prepared_view_checked$1264$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0));
}

function $$$$047$$$047src$047ecs$047column$058indexed_view_state$1264$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047src$047ecs$047column$058indexed_view_sized$1264$(_id_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepared_view_state$1264$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047src$047ecs$047column$058indexed_prepared_view_checked$1264$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0));
}

function $$$$047$$$047src$047ecs$047column$058plain_view_checked$1263$(_values_0, _stamps_0, _id_0, _valid_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "None"}};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $$$$047$$$047src$047ecs$047column$058plain_view_taken$1263$(_stamps_0, _id_0, array_rmw(_values_0, _x_0, () => _x_1));
  }
}

function $$$$047$$$047src$047ecs$047column$058prepared_view_checked$1263$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _valid_0, _same_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    if (_same_0) {
      return $$$$047$$$047src$047ecs$047column$058prepared_view_current$1263$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0);
    } else {
      return $$$$047$$$047src$047ecs$047column$058prepared_view_different$1263$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, (_id_0 < _current_0));
    }
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_view_sized$1263$(_id_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047src$047ecs$047column$058indexed_view_checked$1263$(_id_0, _values_0, _metadata_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepared_view_checked$1263$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _valid_0, _same_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    if (_same_0) {
      return $$$$047$$$047src$047ecs$047column$058indexed_prepared_view_current$1263$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0);
    } else {
      return $$$$047$$$047src$047ecs$047column$058indexed_prepared_view_different$1263$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, (_id_0 < _current_0));
    }
  }
}

function $$$$047$$$047src$047ecs$047column$058plain_view_taken$1262$(_stamps_0, _id_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "None"}};
  } else {
    const _owner_0 = _t_0["value"];
    return $$$$047$$$047src$047ecs$047column$058plain_view_projected$1262$(_values_0, _stamps_0, _id_0, ($schema$058project_queue$(_owner_0)));
  }
}

function $$$$047$$$047src$047ecs$047column$058prepared_view_current$1262$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "None"}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    const _owned_0 = _owner_0["value"];
    return $$$$047$$$047src$047ecs$047column$058prepared_view_projected$1262$(_values_0, _stamps_0, _capacity_0, _current_0, _remaining_0, _past_0, ($schema$058project_queue$(_owned_0)));
  }
}

function $$$$047$$$047src$047ecs$047column$058prepared_view_different$1262$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _backwards_0) {
  if (_backwards_0) {
    return $$$$047$$$047src$047ecs$047column$058view_taken$1262$(_id_0, ($$$$047$$$047src$047ecs$047column$058swap_recovered$1262$(_id_0, {$: "None"}, ($$$$047$$$047src$047ecs$047column$058recover_current$1262$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0))))));
  } else {
    const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
    const _x_1 = ((_x_0 + 1) >>> 0);
    return $$$$047$$$047src$047ecs$047column$058seek_view$1262$(_x_1, _values_0, _stamps_0, _capacity_0, _id_0, _remaining_0, ($$$$047$$$047src$047ecs$047column$058past_current$1262$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../src/ecs/column.Inspect"});
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_view_checked$1262$(_id_0, _values_0, _metadata_0, _valid_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": ($$$$047$$$047src$047ecs$047column$058indexed_wrap$1262$(_values_0, _metadata_0)), "snd": {$: "None"}};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $$$$047$$$047src$047ecs$047column$058indexed_view_taken$1262$(_id_0, _metadata_0, array_rmw(_values_0, _x_0, () => _x_1));
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepared_view_current$1262$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "None"}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    const _owned_0 = _owner_0["value"];
    return $$$$047$$$047src$047ecs$047column$058indexed_prepared_view_projected$1262$(_values_0, _metadata_0, _capacity_0, _current_0, _remaining_0, _past_0, ($schema$058project_queue$(_owned_0)));
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepared_view_different$1262$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _backwards_0) {
  if (_backwards_0) {
    return $$$$047$$$047src$047ecs$047column$058view_taken$1262$(_id_0, ($$$$047$$$047src$047ecs$047column$058swap_recovered$1262$(_id_0, {$: "None"}, ($$$$047$$$047src$047ecs$047column$058indexed_recover_current$1262$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0))))));
  } else {
    const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
    const _x_1 = ((_x_0 + 1) >>> 0);
    return $$$$047$$$047src$047ecs$047column$058indexed_seek_view$1262$(_x_1, _values_0, _metadata_0, _capacity_0, _id_0, _remaining_0, ($$$$047$$$047src$047ecs$047column$058past_current$1262$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../src/ecs/column.Inspect"});
  }
}

function $$$$047$$$047src$047ecs$047column$058plain_view_projected$1261$(_values_0, _stamps_0, _id_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = {$: "Some", "value": _owner_0};
  return $$$$047$$$047src$047ecs$047column$058restored$1261$(array_rmw(_values_0, _x_0, () => _x_1), _projection_0, _stamps_0);
}

function $schema$058project_recipe$(_owner_0) {
  const _value_0 = _owner_0["value"];
  const _array_0 = _owner_0["owned"];
  const _length_0 = _owner_0["length"];
  return $schema$058project_recipe_join$(_value_0, _length_0, ($schema$058array_view$(_array_0)));
}

function $$$$047$$$047src$047ecs$047column$058prepared_view_projected$1261$(_values_0, _stamps_0, _capacity_0, _current_0, _remaining_0, _past_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "Some", "value": _owner_0}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047$$$047src$047ecs$047column$058view_taken$1261$(_id_0, _outcome_0) {
  if (_outcome_0.$ === "../../src/ecs/column.Rejected") {
    const _column_0 = _outcome_0["column"];
    return {$: "Tuple", "fst": _column_0, "snd": {$: "None"}};
  } else {
    const _column_1 = _outcome_0["column"];
    const _t_0 = _outcome_0["previous"];
    if (_t_0.$ === "None") {
      return {$: "Tuple", "fst": _column_1, "snd": {$: "None"}};
    } else {
      const _owner_0 = _t_0["value"];
      return $$$$047$$$047src$047ecs$047column$058viewed$1261$(($schema$058project_recipe$(_owner_0)), _column_1, _id_0);
    }
  }
}

function $$$$047$$$047src$047ecs$047column$058swap_recovered$1261$(_id_0, _incoming_0, _column_0) {
  if (_column_0.$ === "../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047src$047ecs$047column$058swap_sized$1261$(_id_0, _incoming_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../src/ecs/column.Indexed") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058indexed_swap_state$1261$(_id_0, _incoming_0, ($$$$047$$$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_0)));
  } else {
    return {$: "../../src/ecs/column.Rejected", "column": _column_0, "incoming": _incoming_0};
  }
}

function $$$$047$$$047src$047ecs$047column$058seek_view$1261$($0, $1, $2, $3, $4, $5, $6, $7) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _remaining_0 = $5;
      const _past_0 = $6;
      const _phase_0 = $7;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "Tuple", "fst": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "snd": {$: "None"}};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _stamps_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $6 = _past_0;
            $7 = {$: "../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return $$$$047$$$047src$047ecs$047column$058prepared_view_projected$1261$(_values_0, _stamps_0, _capacity_0, _target_0, _rest_1, _past_0, ($schema$058project_recipe$(_owner_1)));
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "Tuple", "fst": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "snd": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _stamps_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _rest_1;
                $6 = {$: "../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $7 = {$: "../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_view_taken$1261$(_id_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "Tuple", "fst": ($$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0)), "snd": {$: "None"}};
  } else {
    const _owner_0 = _t_0["value"];
    return $$$$047$$$047src$047ecs$047column$058indexed_view_projected$1261$(_id_0, _values_0, _metadata_0, ($schema$058project_recipe$(_owner_0)));
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepared_view_projected$1261$(_values_0, _metadata_0, _capacity_0, _current_0, _remaining_0, _past_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "Some", "value": _owner_0}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047$$$047src$047ecs$047column$058indexed_seek_view$1261$($0, $1, $2, $3, $4, $5, $6, $7) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _remaining_0 = $5;
      const _past_0 = $6;
      const _phase_0 = $7;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "Tuple", "fst": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "snd": {$: "None"}};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _metadata_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $6 = _past_0;
            $7 = {$: "../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return $$$$047$$$047src$047ecs$047column$058indexed_prepared_view_projected$1261$(_values_0, _metadata_0, _capacity_0, _target_0, _rest_1, _past_0, ($schema$058project_recipe$(_owner_1)));
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "Tuple", "fst": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "snd": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _metadata_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _rest_1;
                $6 = {$: "../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $7 = {$: "../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047column$058restored$1260$(_result_0, _projection_0, _stamps_0) {
  const _values_0 = _result_0["fst"];
  return {$: "Tuple", "fst": {$: "../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "Some", "value": _projection_0}};
}

function $schema$058project_stock_join$(_value_0, _length_0, _observed_0) {
  const _array_0 = _observed_0["fst"];
  const _values_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "schema.Stock", "value": _value_0, "owned": _array_0, "length": _length_0}, "snd": {$: "schema.StockView", "value": _value_0, "owned": ($schema$058prefix$(_length_0, _values_0))}};
}

function $schema$058array_view$(_array_0) {
  return $schema$058array_view_sized$({$: "Tuple", fst: _array_0, snd: _array_0.length});
}

function $$$$047$$$047src$047ecs$047column$058viewed$1260$(_projected_0, _column_0, _id_0) {
  const _owner_0 = _projected_0["fst"];
  const _result_0 = _projected_0["snd"];
  if (_column_0.$ === "../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "Some", "value": _owner_0};
    return $$$$047$$$047src$047ecs$047column$058restored$1260$(array_rmw(_values_0, _x_0, () => _x_1), _result_0, _stamps_0);
  } else if (_column_0.$ === "../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058viewed_return$1260$(_result_0, ($$$$047$$$047src$047ecs$047column$058swap$1260$({$: "../../src/ecs/column.Prepared", "state": _carrier_0}, _id_0, {$: "Some", "value": _owner_0})));
  } else if (_column_0.$ === "../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058indexed_projected_state$1260$(_id_0, {$: "Tuple", "fst": _owner_0, "snd": _result_0}, ($$$$047$$$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058viewed_return$1260$(_result_0, ($$$$047$$$047src$047ecs$047column$058swap$1260$({$: "../../src/ecs/column.PreparedIndexed", "state": _carrier_2}, _id_0, {$: "Some", "value": _owner_0})));
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_view_projected$1260$(_id_0, _values_0, _metadata_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = {$: "Some", "value": _owner_0};
  return $$$$047$$$047src$047ecs$047column$058indexed_view_restored$1260$(_metadata_0, _projection_0, array_rmw(_values_0, _x_0, () => _x_1));
}

function $$$$047$$$047src$047ecs$047owned$045family$058get_split$1263$(_cell_0, _observed_0) {
  const _rest_0 = _observed_0["fst"];
  const _meta_0 = _observed_0["snd"];
  return $$$$047$$$047src$047ecs$047owned$045family$058get_checked$1263$(_rest_0, _cell_0, ($$$$047$$$047src$047ecs$047owned$045family$058checked$(_meta_0)));
}

function $owned$045rows$058header_duplicate_stock$(_rest_0) {
  const _header_0 = _rest_0["header"];
  const _cold_0 = _rest_0["cold"];
  return {$: "Tuple", "fst": {$: "owned-rows.DuplicateStockMetaRest", "cold": _cold_0}, "snd": _header_0};
}

function $$$$047$$$047src$047ecs$047owned$045family$058write_split$1263$(_cell_0, _incoming_0, _observed_0) {
  const _rest_0 = _observed_0["fst"];
  const _meta_0 = _observed_0["snd"];
  return $$$$047$$$047src$047ecs$047owned$045family$058write_checked$1263$(_rest_0, _cell_0, _incoming_0, ($$$$047$$$047src$047ecs$047owned$045family$058checked$(_meta_0)));
}

function $$$$047$$$047src$047ecs$047lifecycle$058choose$(_found_0, _stamp_0, _other_0) {
  if (_found_0) {
    return _stamp_0;
  } else {
    return _other_0;
  }
}

function $$$$047$$$047src$047ecs$047captured$045column$058stamped$1260$(_id_0, _column_0, _stamp_0, _dirty_0) {
  if (!_dirty_0) {
    return _column_0;
  } else {
    return $$$$047$$$047src$047ecs$047column$058restore_stamp$1260$(_column_0, _id_0, _stamp_0);
  }
}

function $$$$047$$$047src$047ecs$047captured$045column$058indexed_plain_got$1260$(_id_0, _values_0, _owner_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "../../src/ecs/captured-column.Captured", "id": _id_0, "owner": _owner_0, "stamp": _stamp_0, "restore": run_clo((_x_0) => {
  return $$$$047$$$047src$047ecs$047captured$045column$058indexed_restore_plain$1260$(_id_0, _values_0, _metadata_0, _x_0);
})};
}

function $$$$047$$$047src$047ecs$047captured$045column$058indexed_restore_prepared$1260$(_id_0, _values_0, _metadata_0, _capacity_0, _remaining_0, _past_0, _slot_0) {
  const _owner_0 = _slot_0["owner"];
  const _stamp_0 = _slot_0["stamp"];
  const _dirty_0 = _slot_0["dirty"];
  return $$$$047$$$047src$047ecs$047captured$045column$058stamped$1260$(_id_0, {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _id_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, _stamp_0, _dirty_0);
}

function $$$$047$$$047src$047ecs$047indexed$045lifecycle$058get_checked$(_id_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, _isnormal_0, _fits_0) {
  if (!_isnormal_0) {
    return {$: "Tuple", "fst": {$: "../../src/ecs/indexed-lifecycle.Metadata", "added": _added_0, "changed": _changed_0, "capacity": _capacity_0, "depth": _depth_0, "exceptional": _exceptional_0}, "snd": ($$$$047$$$047src$047ecs$047lifecycle$058get$(_exceptional_0, _id_0))};
  } else {
    if (!_fits_0) {
      return {$: "Tuple", "fst": {$: "../../src/ecs/indexed-lifecycle.Metadata", "added": _added_0, "changed": _changed_0, "capacity": _capacity_0, "depth": _depth_0, "exceptional": _exceptional_0}, "snd": {$: "../../src/ecs/lifecycle.Stamp", "added": 0, "changed": 0}};
    } else {
      const _x_0 = ((_id_0 - 1) >>> 0);
      return $$$$047$$$047src$047ecs$047indexed$045lifecycle$058got_added$(_id_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, {$: "Tuple", fst: _added_0, snd: _added_0[_x_0 % _added_0.length]});
    }
  }
}

function $$$$047$$$047src$047ecs$047indexed$045lifecycle$058normal$(_id_0) {
  return $Bool$and$((_id_0 > 0), (_id_0 <= 131072));
}

function $$$$047$$$047src$047ecs$047owned$045compose$058body_returned$1260$(_next_0, _observed_0) {
  const _t_0 = _observed_0["fst"];
  const _tx_0 = _t_0["tx"];
  const _internal_0 = _t_0["error"];
  const _t_1 = _observed_0["snd"];
  const _user_0 = _t_1["fst"];
  const _value_0 = _t_1["snd"];
  return $$$$047$$$047src$047ecs$047owned$045compose$058completed$1260$(_next_0, _tx_0, _value_0, ($$$$047$$$047src$047ecs$047compose$058outcome$1260$(_internal_0, _user_0)));
}

function $$$$047$$$047src$047ecs$047owned$045compose$058left$1260$(_observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _result_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($owned$045rows$058leave_work$(_owner_0)), "snd": _result_0};
}

function $$$$047$$$047src$047ecs$047capabilities$058invoke$1267$(_args_0, _ctx_0) {
  return $gameplay$058work_body$1261$(_args_0, _ctx_0);
}

function $$$$047$$$047src$047ecs$047lifecycle$058clear$(_entries_0, _id_0) {
  if (_entries_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _entries_0["head"];
    const _key_0 = _t_0["id"];
    const _stamp_0 = _t_0["stamp"];
    const _rest_0 = _entries_0["tail"];
    return $$$$047$$$047src$047ecs$047lifecycle$058keep$((_key_0 === _id_0), {$: "../../src/ecs/lifecycle.Entry", "id": _key_0, "stamp": _stamp_0}, ($$$$047$$$047src$047ecs$047lifecycle$058clear$(_rest_0, _id_0)));
  }
}

function $$$$047$$$047src$047ecs$047column$058clear_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": ($$$$047$$$047src$047ecs$047lifecycle$058clear$(_stamps_0, _id_0)), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047src$047ecs$047column$058indexed_clear_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, ($$$$047$$$047src$047ecs$047indexed$045lifecycle$058clear$(_metadata_0, _id_0)));
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepared_clear_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": ($$$$047$$$047src$047ecs$047indexed$045lifecycle$058clear$(_metadata_0, _id_0)), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047src$047ecs$047column$058swap_checked$1260$(_values_0, _stamps_0, _id_0, _incoming_0, _valid_0) {
  if (!_valid_0) {
    return {$: "../../src/ecs/column.Rejected", "column": {$: "../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "incoming": _incoming_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047$$$047src$047ecs$047column$058swapped$1260$(array_rmw(_values_0, _x_0, () => _incoming_0), _stamps_0);
  }
}

function $$$$047$$$047src$047ecs$047column$058prepared_swap$1260$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, _valid_0, _same_0, _backwards_0) {
  if (!_valid_0) {
    return {$: "../../src/ecs/column.Rejected", "column": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "incoming": _incoming_0};
  } else {
    if (_same_0) {
      return {$: "../../src/ecs/column.Accepted", "column": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _incoming_0, "remaining": _remaining_0, "past": _past_0}}}, "previous": _owner_0};
    } else {
      if (_backwards_0) {
        return $$$$047$$$047src$047ecs$047column$058swap_recovered$1260$(_id_0, _incoming_0, ($$$$047$$$047src$047ecs$047column$058recover$1260$({$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}})));
      } else {
        const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
        const _x_1 = ((_x_0 + 1) >>> 0);
        return $$$$047$$$047src$047ecs$047column$058seek$1260$(_x_1, _values_0, _stamps_0, _capacity_0, _id_0, _incoming_0, _remaining_0, ($$$$047$$$047src$047ecs$047column$058past_current$1260$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../src/ecs/column.Inspect"});
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_swap_sized$1260$(_id_0, _incoming_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047src$047ecs$047column$058indexed_swap_checked$1260$(_id_0, _incoming_0, _metadata_0, _values_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepared_swap$1260$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, _valid_0, _same_0, _backwards_0) {
  if (!_valid_0) {
    return {$: "../../src/ecs/column.Rejected", "column": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "incoming": _incoming_0};
  } else {
    if (_same_0) {
      return {$: "../../src/ecs/column.Accepted", "column": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _incoming_0, "remaining": _remaining_0, "past": _past_0}}}, "previous": _owner_0};
    } else {
      if (_backwards_0) {
        return $$$$047$$$047src$047ecs$047column$058swap_recovered$1260$(_id_0, _incoming_0, ($$$$047$$$047src$047ecs$047column$058recover$1260$({$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}})));
      } else {
        const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
        const _x_1 = ((_x_0 + 1) >>> 0);
        return $$$$047$$$047src$047ecs$047column$058indexed_seek$1260$(_x_1, _values_0, _metadata_0, _capacity_0, _id_0, _incoming_0, _remaining_0, ($$$$047$$$047src$047ecs$047column$058past_current$1260$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../src/ecs/column.Inspect"});
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047column$058clear_state$1261$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": ($$$$047$$$047src$047ecs$047lifecycle$058clear$(_stamps_0, _id_0)), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047src$047ecs$047column$058indexed_clear_state$1261$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, ($$$$047$$$047src$047ecs$047indexed$045lifecycle$058clear$(_metadata_0, _id_0)));
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepared_clear_state$1261$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": ($$$$047$$$047src$047ecs$047indexed$045lifecycle$058clear$(_metadata_0, _id_0)), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047src$047ecs$047column$058swap_checked$1261$(_values_0, _stamps_0, _id_0, _incoming_0, _valid_0) {
  if (!_valid_0) {
    return {$: "../../src/ecs/column.Rejected", "column": {$: "../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "incoming": _incoming_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047$$$047src$047ecs$047column$058swapped$1261$(array_rmw(_values_0, _x_0, () => _incoming_0), _stamps_0);
  }
}

function $$$$047$$$047src$047ecs$047column$058prepared_swap$1261$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, _valid_0, _same_0, _backwards_0) {
  if (!_valid_0) {
    return {$: "../../src/ecs/column.Rejected", "column": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "incoming": _incoming_0};
  } else {
    if (_same_0) {
      return {$: "../../src/ecs/column.Accepted", "column": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _incoming_0, "remaining": _remaining_0, "past": _past_0}}}, "previous": _owner_0};
    } else {
      if (_backwards_0) {
        return $$$$047$$$047src$047ecs$047column$058swap_recovered$1261$(_id_0, _incoming_0, ($$$$047$$$047src$047ecs$047column$058recover$1261$({$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}})));
      } else {
        const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
        const _x_1 = ((_x_0 + 1) >>> 0);
        return $$$$047$$$047src$047ecs$047column$058seek$1261$(_x_1, _values_0, _stamps_0, _capacity_0, _id_0, _incoming_0, _remaining_0, ($$$$047$$$047src$047ecs$047column$058past_current$1261$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../src/ecs/column.Inspect"});
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_swap_sized$1261$(_id_0, _incoming_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047src$047ecs$047column$058indexed_swap_checked$1261$(_id_0, _incoming_0, _metadata_0, _values_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepared_swap$1261$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, _valid_0, _same_0, _backwards_0) {
  if (!_valid_0) {
    return {$: "../../src/ecs/column.Rejected", "column": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "incoming": _incoming_0};
  } else {
    if (_same_0) {
      return {$: "../../src/ecs/column.Accepted", "column": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _incoming_0, "remaining": _remaining_0, "past": _past_0}}}, "previous": _owner_0};
    } else {
      if (_backwards_0) {
        return $$$$047$$$047src$047ecs$047column$058swap_recovered$1261$(_id_0, _incoming_0, ($$$$047$$$047src$047ecs$047column$058recover$1261$({$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}})));
      } else {
        const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
        const _x_1 = ((_x_0 + 1) >>> 0);
        return $$$$047$$$047src$047ecs$047column$058indexed_seek$1261$(_x_1, _values_0, _metadata_0, _capacity_0, _id_0, _incoming_0, _remaining_0, ($$$$047$$$047src$047ecs$047column$058past_current$1261$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../src/ecs/column.Inspect"});
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047column$058clear_state$1262$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": ($$$$047$$$047src$047ecs$047lifecycle$058clear$(_stamps_0, _id_0)), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047src$047ecs$047column$058indexed_clear_state$1262$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047src$047ecs$047column$058indexed_wrap$1262$(_values_0, ($$$$047$$$047src$047ecs$047indexed$045lifecycle$058clear$(_metadata_0, _id_0)));
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepared_clear_state$1262$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": ($$$$047$$$047src$047ecs$047indexed$045lifecycle$058clear$(_metadata_0, _id_0)), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047src$047ecs$047column$058swap_checked$1262$(_values_0, _stamps_0, _id_0, _incoming_0, _valid_0) {
  if (!_valid_0) {
    return {$: "../../src/ecs/column.Rejected", "column": {$: "../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "incoming": _incoming_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047$$$047src$047ecs$047column$058swapped$1262$(array_rmw(_values_0, _x_0, () => _incoming_0), _stamps_0);
  }
}

function $$$$047$$$047src$047ecs$047column$058prepared_swap$1262$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, _valid_0, _same_0, _backwards_0) {
  if (!_valid_0) {
    return {$: "../../src/ecs/column.Rejected", "column": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "incoming": _incoming_0};
  } else {
    if (_same_0) {
      return {$: "../../src/ecs/column.Accepted", "column": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _incoming_0, "remaining": _remaining_0, "past": _past_0}}}, "previous": _owner_0};
    } else {
      if (_backwards_0) {
        return $$$$047$$$047src$047ecs$047column$058swap_recovered$1262$(_id_0, _incoming_0, ($$$$047$$$047src$047ecs$047column$058recover$1262$({$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}})));
      } else {
        const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
        const _x_1 = ((_x_0 + 1) >>> 0);
        return $$$$047$$$047src$047ecs$047column$058seek$1262$(_x_1, _values_0, _stamps_0, _capacity_0, _id_0, _incoming_0, _remaining_0, ($$$$047$$$047src$047ecs$047column$058past_current$1262$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../src/ecs/column.Inspect"});
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_swap_sized$1262$(_id_0, _incoming_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047src$047ecs$047column$058indexed_swap_checked$1262$(_id_0, _incoming_0, _metadata_0, _values_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepared_swap$1262$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, _valid_0, _same_0, _backwards_0) {
  if (!_valid_0) {
    return {$: "../../src/ecs/column.Rejected", "column": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "incoming": _incoming_0};
  } else {
    if (_same_0) {
      return {$: "../../src/ecs/column.Accepted", "column": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _incoming_0, "remaining": _remaining_0, "past": _past_0}}}, "previous": _owner_0};
    } else {
      if (_backwards_0) {
        return $$$$047$$$047src$047ecs$047column$058swap_recovered$1262$(_id_0, _incoming_0, ($$$$047$$$047src$047ecs$047column$058recover$1262$({$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}})));
      } else {
        const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
        const _x_1 = ((_x_0 + 1) >>> 0);
        return $$$$047$$$047src$047ecs$047column$058indexed_seek$1262$(_x_1, _values_0, _metadata_0, _capacity_0, _id_0, _incoming_0, _remaining_0, ($$$$047$$$047src$047ecs$047column$058past_current$1262$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../src/ecs/column.Inspect"});
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047column$058clear_state$1263$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": ($$$$047$$$047src$047ecs$047lifecycle$058clear$(_stamps_0, _id_0)), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047src$047ecs$047column$058indexed_clear_state$1263$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047src$047ecs$047column$058indexed_wrap$1263$(_values_0, ($$$$047$$$047src$047ecs$047indexed$045lifecycle$058clear$(_metadata_0, _id_0)));
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepared_clear_state$1263$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": ($$$$047$$$047src$047ecs$047indexed$045lifecycle$058clear$(_metadata_0, _id_0)), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047src$047ecs$047column$058swap_checked$1263$(_values_0, _stamps_0, _id_0, _incoming_0, _valid_0) {
  if (!_valid_0) {
    return {$: "../../src/ecs/column.Rejected", "column": {$: "../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "incoming": _incoming_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047$$$047src$047ecs$047column$058swapped$1263$(array_rmw(_values_0, _x_0, () => _incoming_0), _stamps_0);
  }
}

function $$$$047$$$047src$047ecs$047column$058prepared_swap$1263$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, _valid_0, _same_0, _backwards_0) {
  if (!_valid_0) {
    return {$: "../../src/ecs/column.Rejected", "column": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "incoming": _incoming_0};
  } else {
    if (_same_0) {
      return {$: "../../src/ecs/column.Accepted", "column": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _incoming_0, "remaining": _remaining_0, "past": _past_0}}}, "previous": _owner_0};
    } else {
      if (_backwards_0) {
        return $$$$047$$$047src$047ecs$047column$058swap_recovered$1263$(_id_0, _incoming_0, ($$$$047$$$047src$047ecs$047column$058recover$1263$({$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}})));
      } else {
        const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
        const _x_1 = ((_x_0 + 1) >>> 0);
        return $$$$047$$$047src$047ecs$047column$058seek$1263$(_x_1, _values_0, _stamps_0, _capacity_0, _id_0, _incoming_0, _remaining_0, ($$$$047$$$047src$047ecs$047column$058past_current$1263$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../src/ecs/column.Inspect"});
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_swap_sized$1263$(_id_0, _incoming_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047src$047ecs$047column$058indexed_swap_checked$1263$(_id_0, _incoming_0, _metadata_0, _values_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepared_swap$1263$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, _valid_0, _same_0, _backwards_0) {
  if (!_valid_0) {
    return {$: "../../src/ecs/column.Rejected", "column": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "incoming": _incoming_0};
  } else {
    if (_same_0) {
      return {$: "../../src/ecs/column.Accepted", "column": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _incoming_0, "remaining": _remaining_0, "past": _past_0}}}, "previous": _owner_0};
    } else {
      if (_backwards_0) {
        return $$$$047$$$047src$047ecs$047column$058swap_recovered$1263$(_id_0, _incoming_0, ($$$$047$$$047src$047ecs$047column$058recover$1263$({$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}})));
      } else {
        const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
        const _x_1 = ((_x_0 + 1) >>> 0);
        return $$$$047$$$047src$047ecs$047column$058indexed_seek$1263$(_x_1, _values_0, _metadata_0, _capacity_0, _id_0, _incoming_0, _remaining_0, ($$$$047$$$047src$047ecs$047column$058past_current$1263$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../src/ecs/column.Inspect"});
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047column$058clear_state$1264$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": ($$$$047$$$047src$047ecs$047lifecycle$058clear$(_stamps_0, _id_0)), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047src$047ecs$047column$058indexed_clear_state$1264$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047src$047ecs$047column$058indexed_wrap$1264$(_values_0, ($$$$047$$$047src$047ecs$047indexed$045lifecycle$058clear$(_metadata_0, _id_0)));
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepared_clear_state$1264$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": ($$$$047$$$047src$047ecs$047indexed$045lifecycle$058clear$(_metadata_0, _id_0)), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047src$047ecs$047column$058swap_checked$1264$(_values_0, _stamps_0, _id_0, _incoming_0, _valid_0) {
  if (!_valid_0) {
    return {$: "../../src/ecs/column.Rejected", "column": {$: "../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "incoming": _incoming_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047$$$047src$047ecs$047column$058swapped$1264$(array_rmw(_values_0, _x_0, () => _incoming_0), _stamps_0);
  }
}

function $$$$047$$$047src$047ecs$047column$058prepared_swap$1264$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, _valid_0, _same_0, _backwards_0) {
  if (!_valid_0) {
    return {$: "../../src/ecs/column.Rejected", "column": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "incoming": _incoming_0};
  } else {
    if (_same_0) {
      return {$: "../../src/ecs/column.Accepted", "column": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _incoming_0, "remaining": _remaining_0, "past": _past_0}}}, "previous": _owner_0};
    } else {
      if (_backwards_0) {
        return $$$$047$$$047src$047ecs$047column$058swap_recovered$1264$(_id_0, _incoming_0, ($$$$047$$$047src$047ecs$047column$058recover$1264$({$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}})));
      } else {
        const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
        const _x_1 = ((_x_0 + 1) >>> 0);
        return $$$$047$$$047src$047ecs$047column$058seek$1264$(_x_1, _values_0, _stamps_0, _capacity_0, _id_0, _incoming_0, _remaining_0, ($$$$047$$$047src$047ecs$047column$058past_current$1264$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../src/ecs/column.Inspect"});
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_swap_sized$1264$(_id_0, _incoming_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047src$047ecs$047column$058indexed_swap_checked$1264$(_id_0, _incoming_0, _metadata_0, _values_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepared_swap$1264$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, _valid_0, _same_0, _backwards_0) {
  if (!_valid_0) {
    return {$: "../../src/ecs/column.Rejected", "column": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "incoming": _incoming_0};
  } else {
    if (_same_0) {
      return {$: "../../src/ecs/column.Accepted", "column": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _incoming_0, "remaining": _remaining_0, "past": _past_0}}}, "previous": _owner_0};
    } else {
      if (_backwards_0) {
        return $$$$047$$$047src$047ecs$047column$058swap_recovered$1264$(_id_0, _incoming_0, ($$$$047$$$047src$047ecs$047column$058recover$1264$({$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}})));
      } else {
        const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
        const _x_1 = ((_x_0 + 1) >>> 0);
        return $$$$047$$$047src$047ecs$047column$058indexed_seek$1264$(_x_1, _values_0, _metadata_0, _capacity_0, _id_0, _incoming_0, _remaining_0, ($$$$047$$$047src$047ecs$047column$058past_current$1264$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../src/ecs/column.Inspect"});
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047world$058with_store_finish$1269$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047src$047ecs$047component$058swap_store$1264$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047src$047ecs$047component$058swap_join$1264$(_rest_0, _id_0, _incomingPresent_0, _tick_0, ($$$$047$$$047src$047ecs$047column$058swap$1264$(($$$$047$$$047src$047ecs$047column$058ensure$1264$(_column_0, _id_0)), _id_0, _incoming_0)));
}

function $$$$047$$$047src$047ecs$047world$058with_store_finish$1268$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047src$047ecs$047component$058swap_store$1263$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047src$047ecs$047component$058swap_join$1263$(_rest_0, _id_0, _incomingPresent_0, _tick_0, ($$$$047$$$047src$047ecs$047column$058swap$1263$(($$$$047$$$047src$047ecs$047column$058ensure$1263$(_column_0, _id_0)), _id_0, _incoming_0)));
}

function $$$$047$$$047src$047ecs$047owned$045compose$058selected_fields$1266$(_args_0, _next_0, _observed_0) {
  const _t_0 = _observed_0["fst"];
  const _tx_0 = _t_0["tx"];
  const __0 = _t_0["handle"];
  const __1 = _t_0["error"];
  const __2 = _t_0["cursor"];
  const _t_1 = _observed_0["snd"];
  if (!_t_1) {
    return run_tail(_next_0, _tx_0);
  } else {
    return $$$$047$$$047src$047ecs$047owned$045compose$058body_returned$1260$(_next_0, ($$$$047$$$047src$047ecs$047owned$045compose$058left$1260$(($$$$047$$$047src$047ecs$047capabilities$058invoke$12612$(_args_0, ($owned$045rows$058enter_work$({$: "../../src/ecs/compose.Frame", "tx": _tx_0, "handle": __0, "error": __1, "cursor": __2})))))));
  }
}

function $reference$045declarations$058triple_match$(_frame_0) {
  return $$$$047$$$047src$047ecs$047compose$058both$1264$(_frame_0);
}

function $$$$047$$$047src$047ecs$047component$058replace_clock_checked$1262$(_allowed_0, _world_0, _id_0, _observed_0) {
  if (!_allowed_0) {
    const _incoming_0 = _observed_0["fst"];
    return {$: "../../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../src/ecs/world.CapacityExceeded"}};
  } else {
    const _incoming_1 = _observed_0["fst"];
    const _present_0 = _observed_0["snd"];
    return $$$$047$$$047src$047ecs$047component$058replace_clock_advanced$1262$(_id_0, _present_0, _incoming_1, ($$$$047$$$047src$047ecs$047world$058advance_clock$1260$(_world_0)));
  }
}

function $$$$047$$$047src$047ecs$047component$058owner_present$1262$(_owner_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "None"}, "snd": false};
  } else {
    const _owner_1 = _owner_0["value"];
    return {$: "Tuple", "fst": {$: "Some", "value": _owner_1}, "snd": true};
  }
}

function $$$$047$$$047src$047ecs$047owned$045compose$058finish_returned$1262$(_values_0, _returned_0) {
  const _world_0 = _returned_0["world"];
  const _t_0 = _returned_0["outcome"];
  if (_t_0.$ === "../../src/ecs/transaction.Success") {
    return {$: "../../src/ecs/compose.Executed", "world": _world_0, "outcome": {$: "../../src/ecs/transaction.Success"}, "values": _values_0};
  } else {
    const _error_0 = _t_0["error"];
    return {$: "../../src/ecs/compose.Executed", "world": _world_0, "outcome": {$: "../../src/ecs/transaction.Failure", "error": _error_0}, "values": {$: "Nil"}};
  }
}

function $$$$047$$$047src$047ecs$047owned$045compose$058selected_fields$1265$(_args_0, _next_0, _observed_0) {
  const _t_0 = _observed_0["fst"];
  const _tx_0 = _t_0["tx"];
  const __0 = _t_0["handle"];
  const __1 = _t_0["error"];
  const __2 = _t_0["cursor"];
  const _t_1 = _observed_0["snd"];
  if (!_t_1) {
    return run_tail(_next_0, _tx_0);
  } else {
    return $$$$047$$$047src$047ecs$047owned$045compose$058body_returned$1262$(_next_0, ($$$$047$$$047src$047ecs$047owned$045compose$058left$1264$(($$$$047$$$047src$047ecs$047capabilities$058invoke$12611$(_args_0, ($owned$045rows$058enter_advanced$({$: "../../src/ecs/compose.Frame", "tx": _tx_0, "handle": __0, "error": __1, "cursor": __2})))))));
  }
}

function $reference$045declarations$058advanced_match$(_frame_0) {
  return $$$$047$$$047src$047ecs$047compose$058both$1266$(_frame_0);
}

function $$$$047$$$047src$047ecs$047component$058swap_join$1260$(_rest_0, _id_0, _incoming_0, _tick_0, _result_0) {
  if (_result_0.$ === "../../src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    const _previous_0 = _result_0["previous"];
    return $$$$047$$$047src$047ecs$047component$058mark_swapped$1260$(_rest_0, _column_0, _id_0, _incoming_0, _tick_0, ($$$$047$$$047src$047ecs$047component$058owner_present$1260$(_previous_0)));
  } else {
    const _column_1 = _result_0["column"];
    const _incoming_1 = _result_0["incoming"];
    return {$: "Tuple", "fst": ($schema$058put_stock$(_rest_0, _column_1)), "snd": {$: "../../src/ecs/component.SwapRejected", "incoming": _incoming_1}};
  }
}

function $$$$047$$$047src$047ecs$047column$058ensure$1260$(_column_0, _target_0) {
  return $$$$047$$$047src$047ecs$047column$058ensure_checked$1260$(_column_0, _target_0, ($Bool$and$((_target_0 > 0), (_target_0 <= 131072))));
}

function $$$$047$$$047src$047ecs$047component$058swap_join$1261$(_rest_0, _id_0, _incoming_0, _tick_0, _result_0) {
  if (_result_0.$ === "../../src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    const _previous_0 = _result_0["previous"];
    return $$$$047$$$047src$047ecs$047component$058mark_swapped$1261$(_rest_0, _column_0, _id_0, _incoming_0, _tick_0, ($$$$047$$$047src$047ecs$047component$058owner_present$1261$(_previous_0)));
  } else {
    const _column_1 = _result_0["column"];
    const _incoming_1 = _result_0["incoming"];
    return {$: "Tuple", "fst": ($schema$058put_recipe$(_rest_0, _column_1)), "snd": {$: "../../src/ecs/component.SwapRejected", "incoming": _incoming_1}};
  }
}

function $$$$047$$$047src$047ecs$047column$058ensure$1261$(_column_0, _target_0) {
  return $$$$047$$$047src$047ecs$047column$058ensure_checked$1261$(_column_0, _target_0, ($Bool$and$((_target_0 > 0), (_target_0 <= 131072))));
}

function $$$$047$$$047src$047ecs$047component$058tx_get_join$1263$(_undo_0, _commands_0, _events_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "snd": _value_0};
}

function $$$$047$$$047src$047ecs$047owned$045family$058get_split$1260$(_cell_0, _observed_0) {
  const _rest_0 = _observed_0["fst"];
  const _meta_0 = _observed_0["snd"];
  return $$$$047$$$047src$047ecs$047owned$045family$058get_checked$1260$(_rest_0, _cell_0, ($$$$047$$$047src$047ecs$047owned$045family$058checked$(_meta_0)));
}

function $owned$045rows$058header_work_stock$(_rest_0) {
  const _header_0 = _rest_0["header"];
  const _recipe_0 = _rest_0["recipe"];
  const _queue_0 = _rest_0["queue"];
  const _cold_0 = _rest_0["cold"];
  return {$: "Tuple", "fst": {$: "owned-rows.WorkStockMetaRest", "recipe": _recipe_0, "queue": _queue_0, "cold": _cold_0}, "snd": _header_0};
}

function $$$$047$$$047src$047ecs$047owned$045family$058write_split$1260$(_cell_0, _incoming_0, _observed_0) {
  const _rest_0 = _observed_0["fst"];
  const _meta_0 = _observed_0["snd"];
  return $$$$047$$$047src$047ecs$047owned$045family$058write_checked$1260$(_rest_0, _cell_0, _incoming_0, ($$$$047$$$047src$047ecs$047owned$045family$058checked$(_meta_0)));
}

function $$$$047$$$047src$047ecs$047owned$045family$058get_split$1261$(_cell_0, _observed_0) {
  const _rest_0 = _observed_0["fst"];
  const _meta_0 = _observed_0["snd"];
  return $$$$047$$$047src$047ecs$047owned$045family$058get_checked$1261$(_rest_0, _cell_0, ($$$$047$$$047src$047ecs$047owned$045family$058checked$(_meta_0)));
}

function $owned$045rows$058header_work_recipe$(_rest_0) {
  const _header_0 = _rest_0["header"];
  const _stock_0 = _rest_0["stock"];
  const _queue_0 = _rest_0["queue"];
  const _cold_0 = _rest_0["cold"];
  return {$: "Tuple", "fst": {$: "owned-rows.WorkRecipeMetaRest", "stock": _stock_0, "queue": _queue_0, "cold": _cold_0}, "snd": _header_0};
}

function $$$$047$$$047src$047ecs$047owned$045family$058get_split$1262$(_cell_0, _observed_0) {
  const _rest_0 = _observed_0["fst"];
  const _meta_0 = _observed_0["snd"];
  return $$$$047$$$047src$047ecs$047owned$045family$058get_checked$1262$(_rest_0, _cell_0, ($$$$047$$$047src$047ecs$047owned$045family$058checked$(_meta_0)));
}

function $owned$045rows$058header_work_queue$(_rest_0) {
  const _header_0 = _rest_0["header"];
  const _stock_0 = _rest_0["stock"];
  const _recipe_0 = _rest_0["recipe"];
  const _cold_0 = _rest_0["cold"];
  return {$: "Tuple", "fst": {$: "owned-rows.WorkQueueMetaRest", "stock": _stock_0, "recipe": _recipe_0, "cold": _cold_0}, "snd": _header_0};
}

function $$$$047$$$047src$047ecs$047captured$045column$058stamped$1261$(_id_0, _column_0, _stamp_0, _dirty_0) {
  if (!_dirty_0) {
    return _column_0;
  } else {
    return $$$$047$$$047src$047ecs$047column$058restore_stamp$1261$(_column_0, _id_0, _stamp_0);
  }
}

function $$$$047$$$047src$047ecs$047captured$045column$058indexed_plain_got$1261$(_id_0, _values_0, _owner_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "../../src/ecs/captured-column.Captured", "id": _id_0, "owner": _owner_0, "stamp": _stamp_0, "restore": run_clo((_x_0) => {
  return $$$$047$$$047src$047ecs$047captured$045column$058indexed_restore_plain$1261$(_id_0, _values_0, _metadata_0, _x_0);
})};
}

function $$$$047$$$047src$047ecs$047captured$045column$058indexed_restore_prepared$1261$(_id_0, _values_0, _metadata_0, _capacity_0, _remaining_0, _past_0, _slot_0) {
  const _owner_0 = _slot_0["owner"];
  const _stamp_0 = _slot_0["stamp"];
  const _dirty_0 = _slot_0["dirty"];
  return $$$$047$$$047src$047ecs$047captured$045column$058stamped$1261$(_id_0, {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _id_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, _stamp_0, _dirty_0);
}

function $$$$047$$$047src$047ecs$047captured$045column$058stamped$1262$(_id_0, _column_0, _stamp_0, _dirty_0) {
  if (!_dirty_0) {
    return _column_0;
  } else {
    return $$$$047$$$047src$047ecs$047column$058restore_stamp$1262$(_column_0, _id_0, _stamp_0);
  }
}

function $$$$047$$$047src$047ecs$047captured$045column$058indexed_plain_got$1262$(_id_0, _values_0, _owner_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "../../src/ecs/captured-column.Captured", "id": _id_0, "owner": _owner_0, "stamp": _stamp_0, "restore": run_clo((_x_0) => {
  return $$$$047$$$047src$047ecs$047captured$045column$058indexed_restore_plain$1262$(_id_0, _values_0, _metadata_0, _x_0);
})};
}

function $$$$047$$$047src$047ecs$047captured$045column$058indexed_restore_prepared$1262$(_id_0, _values_0, _metadata_0, _capacity_0, _remaining_0, _past_0, _slot_0) {
  const _owner_0 = _slot_0["owner"];
  const _stamp_0 = _slot_0["stamp"];
  const _dirty_0 = _slot_0["dirty"];
  return $$$$047$$$047src$047ecs$047captured$045column$058stamped$1262$(_id_0, {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _id_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, _stamp_0, _dirty_0);
}

function $$$$047$$$047src$047ecs$047compose$058selected_join$1260$(_mode_0, _observed_0) {
  const _frame_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _frame_0, "snd": ($$$$047$$$047src$047ecs$047compose$058selected_value$1260$(_mode_0, _value_0))};
}

function $$$$047$$$047src$047ecs$047compose$058get$1264$(_frame_0) {
  const _tx_0 = _frame_0["tx"];
  const _handle_0 = _frame_0["handle"];
  const _error_0 = _frame_0["error"];
  const _cursor_0 = _frame_0["cursor"];
  return $$$$047$$$047src$047ecs$047compose$058read_join$1264$(_handle_0, _error_0, _cursor_0, ($$$$047$$$047src$047ecs$047component$058tx_get$1264$(($schema$058locked$()), _tx_0, _handle_0)));
}

function $$$$047$$$047src$047ecs$047compose$058selected_value$1262$(_mode_0, _value_0) {
  if (_mode_0.$ === "../../src/ecs/compose.Required") {
    if (_value_0.$ === "../../src/ecs/component.Found") {
      return true;
    } else {
      return false;
    }
  } else if (_mode_0.$ === "../../src/ecs/compose.Present") {
    if (_value_0.$ === "../../src/ecs/component.Found") {
      return true;
    } else {
      return false;
    }
  } else if (_mode_0.$ === "../../src/ecs/compose.Absent") {
    if (_value_0.$ === "../../src/ecs/component.ComponentAbsent") {
      return true;
    } else {
      return false;
    }
  } else {
    if (_value_0.$ === "../../src/ecs/component.Found") {
      return true;
    } else if (_value_0.$ === "../../src/ecs/component.ComponentAbsent") {
      return true;
    } else {
      return false;
    }
  }
}

function $$$$047$$$047src$047ecs$047compose$058read_join$1261$(_handle_0, _error_0, _cursor_0, _observed_0) {
  const _tx_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../src/ecs/compose.Frame", "tx": _tx_0, "handle": _handle_0, "error": _error_0, "cursor": _cursor_0}, "snd": _value_0};
}

function $$$$047$$$047src$047ecs$047component$058tx_get$1261$(_family_0, _tx_0, _handle_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047src$047ecs$047component$058tx_get_join$1261$(_undo_0, _commands_0, _events_0, ($$$$047$$$047src$047ecs$047component$058get$1261$(_family_0, _world_0, _handle_0)));
}

function $$$$047$$$047src$047ecs$047column$058plain_view_checked$1264$(_values_0, _stamps_0, _id_0, _valid_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "None"}};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $$$$047$$$047src$047ecs$047column$058plain_view_taken$1264$(_stamps_0, _id_0, array_rmw(_values_0, _x_0, () => _x_1));
  }
}

function $$$$047$$$047src$047ecs$047column$058prepared_view_checked$1264$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _valid_0, _same_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    if (_same_0) {
      return $$$$047$$$047src$047ecs$047column$058prepared_view_current$1264$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0);
    } else {
      return $$$$047$$$047src$047ecs$047column$058prepared_view_different$1264$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, (_id_0 < _current_0));
    }
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_view_sized$1264$(_id_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047src$047ecs$047column$058indexed_view_checked$1264$(_id_0, _values_0, _metadata_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepared_view_checked$1264$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _valid_0, _same_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    if (_same_0) {
      return $$$$047$$$047src$047ecs$047column$058indexed_prepared_view_current$1264$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0);
    } else {
      return $$$$047$$$047src$047ecs$047column$058indexed_prepared_view_different$1264$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, (_id_0 < _current_0));
    }
  }
}

function $$$$047$$$047src$047ecs$047column$058plain_view_taken$1263$(_stamps_0, _id_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "None"}};
  } else {
    const _owner_0 = _t_0["value"];
    return $$$$047$$$047src$047ecs$047column$058plain_view_projected$1263$(_values_0, _stamps_0, _id_0, ($schema$058project_enabled$(_owner_0)));
  }
}

function $$$$047$$$047src$047ecs$047column$058prepared_view_current$1263$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "None"}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    const _owned_0 = _owner_0["value"];
    return $$$$047$$$047src$047ecs$047column$058prepared_view_projected$1263$(_values_0, _stamps_0, _capacity_0, _current_0, _remaining_0, _past_0, ($schema$058project_enabled$(_owned_0)));
  }
}

function $$$$047$$$047src$047ecs$047column$058prepared_view_different$1263$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _backwards_0) {
  if (_backwards_0) {
    return $$$$047$$$047src$047ecs$047column$058view_taken$1263$(_id_0, ($$$$047$$$047src$047ecs$047column$058swap_recovered$1263$(_id_0, {$: "None"}, ($$$$047$$$047src$047ecs$047column$058recover_current$1263$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0))))));
  } else {
    const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
    const _x_1 = ((_x_0 + 1) >>> 0);
    return $$$$047$$$047src$047ecs$047column$058seek_view$1263$(_x_1, _values_0, _stamps_0, _capacity_0, _id_0, _remaining_0, ($$$$047$$$047src$047ecs$047column$058past_current$1263$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../src/ecs/column.Inspect"});
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_view_checked$1263$(_id_0, _values_0, _metadata_0, _valid_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": ($$$$047$$$047src$047ecs$047column$058indexed_wrap$1263$(_values_0, _metadata_0)), "snd": {$: "None"}};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $$$$047$$$047src$047ecs$047column$058indexed_view_taken$1263$(_id_0, _metadata_0, array_rmw(_values_0, _x_0, () => _x_1));
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepared_view_current$1263$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "None"}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    const _owned_0 = _owner_0["value"];
    return $$$$047$$$047src$047ecs$047column$058indexed_prepared_view_projected$1263$(_values_0, _metadata_0, _capacity_0, _current_0, _remaining_0, _past_0, ($schema$058project_enabled$(_owned_0)));
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepared_view_different$1263$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _backwards_0) {
  if (_backwards_0) {
    return $$$$047$$$047src$047ecs$047column$058view_taken$1263$(_id_0, ($$$$047$$$047src$047ecs$047column$058swap_recovered$1263$(_id_0, {$: "None"}, ($$$$047$$$047src$047ecs$047column$058indexed_recover_current$1263$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0))))));
  } else {
    const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
    const _x_1 = ((_x_0 + 1) >>> 0);
    return $$$$047$$$047src$047ecs$047column$058indexed_seek_view$1263$(_x_1, _values_0, _metadata_0, _capacity_0, _id_0, _remaining_0, ($$$$047$$$047src$047ecs$047column$058past_current$1263$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../src/ecs/column.Inspect"});
  }
}

function $$$$047$$$047src$047ecs$047column$058plain_view_projected$1262$(_values_0, _stamps_0, _id_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = {$: "Some", "value": _owner_0};
  return $$$$047$$$047src$047ecs$047column$058restored$1262$(array_rmw(_values_0, _x_0, () => _x_1), _projection_0, _stamps_0);
}

function $schema$058project_queue$(_owner_0) {
  const _value_0 = _owner_0["value"];
  const _array_0 = _owner_0["owned"];
  const _length_0 = _owner_0["length"];
  return $schema$058project_queue_join$(_value_0, _length_0, ($schema$058array_view$(_array_0)));
}

function $$$$047$$$047src$047ecs$047column$058prepared_view_projected$1262$(_values_0, _stamps_0, _capacity_0, _current_0, _remaining_0, _past_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "Some", "value": _owner_0}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047$$$047src$047ecs$047column$058view_taken$1262$(_id_0, _outcome_0) {
  if (_outcome_0.$ === "../../src/ecs/column.Rejected") {
    const _column_0 = _outcome_0["column"];
    return {$: "Tuple", "fst": _column_0, "snd": {$: "None"}};
  } else {
    const _column_1 = _outcome_0["column"];
    const _t_0 = _outcome_0["previous"];
    if (_t_0.$ === "None") {
      return {$: "Tuple", "fst": _column_1, "snd": {$: "None"}};
    } else {
      const _owner_0 = _t_0["value"];
      return $$$$047$$$047src$047ecs$047column$058viewed$1262$(($schema$058project_queue$(_owner_0)), _column_1, _id_0);
    }
  }
}

function $$$$047$$$047src$047ecs$047column$058swap_recovered$1262$(_id_0, _incoming_0, _column_0) {
  if (_column_0.$ === "../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047src$047ecs$047column$058swap_sized$1262$(_id_0, _incoming_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../src/ecs/column.Indexed") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058indexed_swap_state$1262$(_id_0, _incoming_0, ($$$$047$$$047src$047ecs$047column$058indexed_unseal$1262$(_carrier_0)));
  } else {
    return {$: "../../src/ecs/column.Rejected", "column": _column_0, "incoming": _incoming_0};
  }
}

function $$$$047$$$047src$047ecs$047column$058seek_view$1262$($0, $1, $2, $3, $4, $5, $6, $7) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _remaining_0 = $5;
      const _past_0 = $6;
      const _phase_0 = $7;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "Tuple", "fst": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "snd": {$: "None"}};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _stamps_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $6 = _past_0;
            $7 = {$: "../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return $$$$047$$$047src$047ecs$047column$058prepared_view_projected$1262$(_values_0, _stamps_0, _capacity_0, _target_0, _rest_1, _past_0, ($schema$058project_queue$(_owner_1)));
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "Tuple", "fst": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "snd": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _stamps_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _rest_1;
                $6 = {$: "../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $7 = {$: "../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_view_taken$1262$(_id_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "Tuple", "fst": ($$$$047$$$047src$047ecs$047column$058indexed_wrap$1262$(_values_0, _metadata_0)), "snd": {$: "None"}};
  } else {
    const _owner_0 = _t_0["value"];
    return $$$$047$$$047src$047ecs$047column$058indexed_view_projected$1262$(_id_0, _values_0, _metadata_0, ($schema$058project_queue$(_owner_0)));
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepared_view_projected$1262$(_values_0, _metadata_0, _capacity_0, _current_0, _remaining_0, _past_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "Some", "value": _owner_0}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047$$$047src$047ecs$047column$058indexed_seek_view$1262$($0, $1, $2, $3, $4, $5, $6, $7) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _remaining_0 = $5;
      const _past_0 = $6;
      const _phase_0 = $7;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "Tuple", "fst": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "snd": {$: "None"}};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _metadata_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $6 = _past_0;
            $7 = {$: "../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return $$$$047$$$047src$047ecs$047column$058indexed_prepared_view_projected$1262$(_values_0, _metadata_0, _capacity_0, _target_0, _rest_1, _past_0, ($schema$058project_queue$(_owner_1)));
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "Tuple", "fst": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "snd": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _metadata_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _rest_1;
                $6 = {$: "../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $7 = {$: "../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047column$058restored$1261$(_result_0, _projection_0, _stamps_0) {
  const _values_0 = _result_0["fst"];
  return {$: "Tuple", "fst": {$: "../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "Some", "value": _projection_0}};
}

function $schema$058project_recipe_join$(_value_0, _length_0, _observed_0) {
  const _array_0 = _observed_0["fst"];
  const _values_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "schema.Recipe", "value": _value_0, "owned": _array_0, "length": _length_0}, "snd": {$: "schema.RecipeView", "value": _value_0, "owned": ($schema$058prefix$(_length_0, _values_0))}};
}

function $$$$047$$$047src$047ecs$047column$058viewed$1261$(_projected_0, _column_0, _id_0) {
  const _owner_0 = _projected_0["fst"];
  const _result_0 = _projected_0["snd"];
  if (_column_0.$ === "../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "Some", "value": _owner_0};
    return $$$$047$$$047src$047ecs$047column$058restored$1261$(array_rmw(_values_0, _x_0, () => _x_1), _result_0, _stamps_0);
  } else if (_column_0.$ === "../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058viewed_return$1261$(_result_0, ($$$$047$$$047src$047ecs$047column$058swap$1261$({$: "../../src/ecs/column.Prepared", "state": _carrier_0}, _id_0, {$: "Some", "value": _owner_0})));
  } else if (_column_0.$ === "../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058indexed_projected_state$1261$(_id_0, {$: "Tuple", "fst": _owner_0, "snd": _result_0}, ($$$$047$$$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058viewed_return$1261$(_result_0, ($$$$047$$$047src$047ecs$047column$058swap$1261$({$: "../../src/ecs/column.PreparedIndexed", "state": _carrier_2}, _id_0, {$: "Some", "value": _owner_0})));
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_view_projected$1261$(_id_0, _values_0, _metadata_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = {$: "Some", "value": _owner_0};
  return $$$$047$$$047src$047ecs$047column$058indexed_view_restored$1261$(_metadata_0, _projection_0, array_rmw(_values_0, _x_0, () => _x_1));
}

function $schema$058prefix$(_fuel_0, _xs_0) {
  if (_fuel_0 === 0) {
    if (_xs_0.$ === "Nil") {
      return {$: "Nil"};
    } else {
      return {$: "Nil"};
    }
  } else {
    const _rest_0 = (_fuel_0 - 1);
    if (_xs_0.$ === "Nil") {
      return {$: "Nil"};
    } else {
      const _x_0 = _xs_0["head"];
      const _xs_1 = _xs_0["tail"];
      return {$: "Con", "head": _x_0, "tail": ($schema$058prefix$(_rest_0, _xs_1))};
    }
  }
}

function $schema$058array_view_sized$(_observed_0) {
  const _array_0 = _observed_0["fst"];
  const _capacity_0 = _observed_0["snd"];
  const _x_0 = ((_capacity_0 - 1) >>> 0);
  return $schema$058array_view_finished$(($schema$058array_view_collect$(_x_0, 0, _capacity_0, {$: "Nil"}, ($schema$058array_view_read$(_array_0, 0, _capacity_0)))));
}

function $$$$047$$$047src$047ecs$047column$058viewed_return$1260$(_view_0, _result_0) {
  if (_result_0.$ === "../../src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    return {$: "Tuple", "fst": _column_0, "snd": {$: "Some", "value": _view_0}};
  } else {
    const _column_1 = _result_0["column"];
    return {$: "Tuple", "fst": _column_1, "snd": {$: "None"}};
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_projected_state$1260$(_id_0, _result_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047src$047ecs$047column$058indexed_view_projected$1260$(_id_0, _values_0, _metadata_0, _result_0);
}

function $$$$047$$$047src$047ecs$047column$058indexed_view_restored$1260$(_metadata_0, _projection_0, _result_0) {
  const _values_0 = _result_0["fst"];
  return {$: "Tuple", "fst": ($$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047$$$047src$047ecs$047owned$045family$058get_checked$1263$(_rest_0, _cell_0, _observed_0) {
  const _header_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": ($owned$045rows$058put_duplicate_stock$(($owned$045rows$058put_header_duplicate_stock$(_rest_0, _header_0)), _cell_0)), "snd": {$: "../../src/ecs/component.MissingEntity"}};
  } else {
    return $$$$047$$$047src$047ecs$047owned$045family$058get_targeted$1263$(_rest_0, _cell_0, ($$$$047$$$047src$047ecs$047owned$045family$058target$(_header_0)));
  }
}

function $$$$047$$$047src$047ecs$047owned$045family$058checked$(_header_0) {
  const _namespace_0 = _header_0["namespace"];
  const _nextId_0 = _header_0["nextId"];
  const _live_0 = _header_0["live"];
  const _t_0 = _header_0["handle"];
  const _ns_0 = _t_0["namespace"];
  const _id_0 = _t_0["id"];
  const _clock_0 = _header_0["clock"];
  const _error_0 = _header_0["error"];
  const _cursor_0 = _header_0["cursor"];
  return $$$$047$$$047src$047ecs$047owned$045family$058checked_metadata$(($Bool$and$((_namespace_0 === _ns_0), ($Bool$and$((0 < _id_0), (_id_0 < _nextId_0))))), _live_0, _id_0, _namespace_0, _nextId_0, {$: "../../src/ecs/world.Handle", "namespace": _ns_0, "id": _id_0}, _clock_0, _error_0, _cursor_0);
}

function $$$$047$$$047src$047ecs$047owned$045family$058write_checked$1263$(_rest_0, _cell_0, _incoming_0, _observed_0) {
  const _meta_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return $$$$047$$$047src$047ecs$047owned$045family$058rejected$1263$(_rest_0, _cell_0, _incoming_0, {$: "../../src/ecs/world.MissingEntity"}, _meta_0);
  } else {
    return $$$$047$$$047src$047ecs$047owned$045family$058write_targeted$1263$(_rest_0, _cell_0, _incoming_0, ($$$$047$$$047src$047ecs$047owned$045family$058target$(_meta_0)));
  }
}

function $$$$047$$$047src$047ecs$047column$058restore_stamp$1260$(_column_0, _id_0, _stamp_0) {
  if (_column_0.$ === "../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../src/ecs/column.Column", "values": _values_0, "stamps": ($$$$047$$$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, _stamp_0))};
  } else if (_column_0.$ === "../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058restore_state$1260$(_id_0, _stamp_0, ($$$$047$$$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
  } else if (_column_0.$ === "../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058indexed_restore_state$1260$(_id_0, _stamp_0, ($$$$047$$$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058indexed_prepared_restore_state$1260$(_id_0, _stamp_0, ($$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
  }
}

function $$$$047$$$047src$047ecs$047captured$045column$058indexed_restore_plain$1260$(_id_0, _values_0, _metadata_0, _slot_0) {
  const _owner_0 = _slot_0["owner"];
  const _stamp_0 = _slot_0["stamp"];
  const _dirty_0 = _slot_0["dirty"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  return $$$$047$$$047src$047ecs$047captured$045column$058stamped$1260$(_id_0, ($$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$((_values_0[_x_0 % _values_0.length] = _owner_0, _values_0), _metadata_0)), _stamp_0, _dirty_0);
}

function $$$$047$$$047src$047ecs$047indexed$045lifecycle$058got_added$(_id_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, _observed_0) {
  const _added_0 = _observed_0["fst"];
  const _first_0 = _observed_0["snd"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  return $$$$047$$$047src$047ecs$047indexed$045lifecycle$058got_changed$(_added_0, _capacity_0, _depth_0, _exceptional_0, _first_0, {$: "Tuple", fst: _changed_0, snd: _changed_0[_x_0 % _changed_0.length]});
}

function $$$$047$$$047src$047ecs$047owned$045compose$058completed$1260$(_next_0, _tx_0, _value_0, _result_0) {
  if (_result_0.$ === "../../src/ecs/transaction.Success") {
    return $$$$047$$$047src$047ecs$047owned$045compose$058prepend$1260$(_value_0, _next_0(_tx_0));
  } else {
    const _error_0 = _result_0["error"];
    return {$: "Tuple", "fst": _tx_0, "snd": {$: "Tuple", "fst": {$: "../../src/ecs/transaction.Failure", "error": _error_0}, "snd": {$: "Nil"}}};
  }
}

function $gameplay$058work_body$1261$(_args_0, _ctx_0) {
  return $gameplay$058work_stock_read$1261$(run_loop($$$$047$$$047src$047ecs$047capabilities$058get$1262$(_ctx_0)));
}

function $$$$047$$$047src$047ecs$047lifecycle$058keep$(_equal_0, _entry_0, _rest_0) {
  if (_equal_0) {
    return _rest_0;
  } else {
    return {$: "Con", "head": _entry_0, "tail": _rest_0};
  }
}

function $$$$047$$$047src$047ecs$047indexed$045lifecycle$058clear$(_metadata_0, _id_0) {
  const _added_0 = _metadata_0["added"];
  const _changed_0 = _metadata_0["changed"];
  const _capacity_0 = _metadata_0["capacity"];
  const _depth_0 = _metadata_0["depth"];
  const _exceptional_0 = _metadata_0["exceptional"];
  return $$$$047$$$047src$047ecs$047indexed$045lifecycle$058clear_checked$(_id_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, ($$$$047$$$047src$047ecs$047indexed$045lifecycle$058normal$(_id_0)), (_id_0 <= _capacity_0));
}

function $$$$047$$$047src$047ecs$047column$058swapped$1260$(_result_0, _stamps_0) {
  const _values_0 = _result_0["fst"];
  const _previous_0 = _result_0["snd"];
  return {$: "../../src/ecs/column.Accepted", "column": {$: "../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "previous": _previous_0};
}

function $$$$047$$$047src$047ecs$047column$058seek$1260$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _incoming_0 = $5;
      const _remaining_0 = $6;
      const _past_0 = $7;
      const _phase_0 = $8;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../src/ecs/column.Accepted", "column": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "../../src/ecs/column.Rejected", "column": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "incoming": _incoming_0};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../src/ecs/column.Accepted", "column": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _stamps_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = _incoming_0;
            $6 = {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $7 = _past_0;
            $8 = {$: "../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return {$: "../../src/ecs/column.Accepted", "column": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": _rest_1, "past": _past_0}}}, "previous": {$: "Some", "value": _owner_1}};
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "../../src/ecs/column.Accepted", "column": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "previous": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _stamps_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _incoming_0;
                $6 = _rest_1;
                $7 = {$: "../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $8 = {$: "../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_swap_checked$1260$(_id_0, _incoming_0, _metadata_0, _values_0, _valid_0) {
  if (!_valid_0) {
    return {$: "../../src/ecs/column.Rejected", "column": ($$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "incoming": _incoming_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047$$$047src$047ecs$047column$058indexed_swapped$1260$(_metadata_0, array_rmw(_values_0, _x_0, () => _incoming_0));
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_seek$1260$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _incoming_0 = $5;
      const _remaining_0 = $6;
      const _past_0 = $7;
      const _phase_0 = $8;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../src/ecs/column.Accepted", "column": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "../../src/ecs/column.Rejected", "column": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "incoming": _incoming_0};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../src/ecs/column.Accepted", "column": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _metadata_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = _incoming_0;
            $6 = {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $7 = _past_0;
            $8 = {$: "../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return {$: "../../src/ecs/column.Accepted", "column": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": _rest_1, "past": _past_0}}}, "previous": {$: "Some", "value": _owner_1}};
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "../../src/ecs/column.Accepted", "column": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "previous": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _metadata_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _incoming_0;
                $6 = _rest_1;
                $7 = {$: "../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $8 = {$: "../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047column$058swapped$1261$(_result_0, _stamps_0) {
  const _values_0 = _result_0["fst"];
  const _previous_0 = _result_0["snd"];
  return {$: "../../src/ecs/column.Accepted", "column": {$: "../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "previous": _previous_0};
}

function $$$$047$$$047src$047ecs$047column$058seek$1261$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _incoming_0 = $5;
      const _remaining_0 = $6;
      const _past_0 = $7;
      const _phase_0 = $8;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../src/ecs/column.Accepted", "column": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "../../src/ecs/column.Rejected", "column": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "incoming": _incoming_0};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../src/ecs/column.Accepted", "column": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _stamps_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = _incoming_0;
            $6 = {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $7 = _past_0;
            $8 = {$: "../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return {$: "../../src/ecs/column.Accepted", "column": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": _rest_1, "past": _past_0}}}, "previous": {$: "Some", "value": _owner_1}};
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "../../src/ecs/column.Accepted", "column": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "previous": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _stamps_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _incoming_0;
                $6 = _rest_1;
                $7 = {$: "../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $8 = {$: "../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_swap_checked$1261$(_id_0, _incoming_0, _metadata_0, _values_0, _valid_0) {
  if (!_valid_0) {
    return {$: "../../src/ecs/column.Rejected", "column": ($$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0)), "incoming": _incoming_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047$$$047src$047ecs$047column$058indexed_swapped$1261$(_metadata_0, array_rmw(_values_0, _x_0, () => _incoming_0));
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_seek$1261$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _incoming_0 = $5;
      const _remaining_0 = $6;
      const _past_0 = $7;
      const _phase_0 = $8;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../src/ecs/column.Accepted", "column": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "../../src/ecs/column.Rejected", "column": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "incoming": _incoming_0};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../src/ecs/column.Accepted", "column": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _metadata_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = _incoming_0;
            $6 = {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $7 = _past_0;
            $8 = {$: "../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return {$: "../../src/ecs/column.Accepted", "column": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": _rest_1, "past": _past_0}}}, "previous": {$: "Some", "value": _owner_1}};
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "../../src/ecs/column.Accepted", "column": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "previous": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _metadata_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _incoming_0;
                $6 = _rest_1;
                $7 = {$: "../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $8 = {$: "../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047column$058swapped$1262$(_result_0, _stamps_0) {
  const _values_0 = _result_0["fst"];
  const _previous_0 = _result_0["snd"];
  return {$: "../../src/ecs/column.Accepted", "column": {$: "../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "previous": _previous_0};
}

function $$$$047$$$047src$047ecs$047column$058seek$1262$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _incoming_0 = $5;
      const _remaining_0 = $6;
      const _past_0 = $7;
      const _phase_0 = $8;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../src/ecs/column.Accepted", "column": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "../../src/ecs/column.Rejected", "column": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "incoming": _incoming_0};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../src/ecs/column.Accepted", "column": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _stamps_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = _incoming_0;
            $6 = {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $7 = _past_0;
            $8 = {$: "../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return {$: "../../src/ecs/column.Accepted", "column": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": _rest_1, "past": _past_0}}}, "previous": {$: "Some", "value": _owner_1}};
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "../../src/ecs/column.Accepted", "column": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "previous": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _stamps_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _incoming_0;
                $6 = _rest_1;
                $7 = {$: "../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $8 = {$: "../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_swap_checked$1262$(_id_0, _incoming_0, _metadata_0, _values_0, _valid_0) {
  if (!_valid_0) {
    return {$: "../../src/ecs/column.Rejected", "column": ($$$$047$$$047src$047ecs$047column$058indexed_wrap$1262$(_values_0, _metadata_0)), "incoming": _incoming_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047$$$047src$047ecs$047column$058indexed_swapped$1262$(_metadata_0, array_rmw(_values_0, _x_0, () => _incoming_0));
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_seek$1262$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _incoming_0 = $5;
      const _remaining_0 = $6;
      const _past_0 = $7;
      const _phase_0 = $8;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../src/ecs/column.Accepted", "column": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "../../src/ecs/column.Rejected", "column": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "incoming": _incoming_0};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../src/ecs/column.Accepted", "column": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _metadata_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = _incoming_0;
            $6 = {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $7 = _past_0;
            $8 = {$: "../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return {$: "../../src/ecs/column.Accepted", "column": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": _rest_1, "past": _past_0}}}, "previous": {$: "Some", "value": _owner_1}};
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "../../src/ecs/column.Accepted", "column": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "previous": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _metadata_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _incoming_0;
                $6 = _rest_1;
                $7 = {$: "../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $8 = {$: "../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047column$058swapped$1263$(_result_0, _stamps_0) {
  const _values_0 = _result_0["fst"];
  const _previous_0 = _result_0["snd"];
  return {$: "../../src/ecs/column.Accepted", "column": {$: "../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "previous": _previous_0};
}

function $$$$047$$$047src$047ecs$047column$058swap_recovered$1263$(_id_0, _incoming_0, _column_0) {
  if (_column_0.$ === "../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047src$047ecs$047column$058swap_sized$1263$(_id_0, _incoming_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../src/ecs/column.Indexed") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058indexed_swap_state$1263$(_id_0, _incoming_0, ($$$$047$$$047src$047ecs$047column$058indexed_unseal$1263$(_carrier_0)));
  } else {
    return {$: "../../src/ecs/column.Rejected", "column": _column_0, "incoming": _incoming_0};
  }
}

function $$$$047$$$047src$047ecs$047column$058seek$1263$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _incoming_0 = $5;
      const _remaining_0 = $6;
      const _past_0 = $7;
      const _phase_0 = $8;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../src/ecs/column.Accepted", "column": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "../../src/ecs/column.Rejected", "column": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "incoming": _incoming_0};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../src/ecs/column.Accepted", "column": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _stamps_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = _incoming_0;
            $6 = {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $7 = _past_0;
            $8 = {$: "../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return {$: "../../src/ecs/column.Accepted", "column": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": _rest_1, "past": _past_0}}}, "previous": {$: "Some", "value": _owner_1}};
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "../../src/ecs/column.Accepted", "column": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "previous": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _stamps_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _incoming_0;
                $6 = _rest_1;
                $7 = {$: "../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $8 = {$: "../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047column$058past_current$1263$(_current_0, _owner_0, _past_0, _active_0) {
  if (!_active_0) {
    return _past_0;
  } else {
    return {$: "../../src/ecs/column.HistoryCon", "id": _current_0, "value": _owner_0, "rest": _past_0};
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_swap_checked$1263$(_id_0, _incoming_0, _metadata_0, _values_0, _valid_0) {
  if (!_valid_0) {
    return {$: "../../src/ecs/column.Rejected", "column": ($$$$047$$$047src$047ecs$047column$058indexed_wrap$1263$(_values_0, _metadata_0)), "incoming": _incoming_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047$$$047src$047ecs$047column$058indexed_swapped$1263$(_metadata_0, array_rmw(_values_0, _x_0, () => _incoming_0));
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_seek$1263$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _incoming_0 = $5;
      const _remaining_0 = $6;
      const _past_0 = $7;
      const _phase_0 = $8;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../src/ecs/column.Accepted", "column": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "../../src/ecs/column.Rejected", "column": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "incoming": _incoming_0};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../src/ecs/column.Accepted", "column": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _metadata_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = _incoming_0;
            $6 = {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $7 = _past_0;
            $8 = {$: "../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return {$: "../../src/ecs/column.Accepted", "column": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": _rest_1, "past": _past_0}}}, "previous": {$: "Some", "value": _owner_1}};
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "../../src/ecs/column.Accepted", "column": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "previous": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _metadata_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _incoming_0;
                $6 = _rest_1;
                $7 = {$: "../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $8 = {$: "../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047column$058swapped$1264$(_result_0, _stamps_0) {
  const _values_0 = _result_0["fst"];
  const _previous_0 = _result_0["snd"];
  return {$: "../../src/ecs/column.Accepted", "column": {$: "../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "previous": _previous_0};
}

function $$$$047$$$047src$047ecs$047column$058swap_recovered$1264$(_id_0, _incoming_0, _column_0) {
  if (_column_0.$ === "../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047src$047ecs$047column$058swap_sized$1264$(_id_0, _incoming_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../src/ecs/column.Indexed") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058indexed_swap_state$1264$(_id_0, _incoming_0, ($$$$047$$$047src$047ecs$047column$058indexed_unseal$1264$(_carrier_0)));
  } else {
    return {$: "../../src/ecs/column.Rejected", "column": _column_0, "incoming": _incoming_0};
  }
}

function $$$$047$$$047src$047ecs$047column$058seek$1264$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _incoming_0 = $5;
      const _remaining_0 = $6;
      const _past_0 = $7;
      const _phase_0 = $8;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../src/ecs/column.Accepted", "column": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "../../src/ecs/column.Rejected", "column": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "incoming": _incoming_0};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../src/ecs/column.Accepted", "column": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _stamps_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = _incoming_0;
            $6 = {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $7 = _past_0;
            $8 = {$: "../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return {$: "../../src/ecs/column.Accepted", "column": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": _rest_1, "past": _past_0}}}, "previous": {$: "Some", "value": _owner_1}};
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "../../src/ecs/column.Accepted", "column": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "previous": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _stamps_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _incoming_0;
                $6 = _rest_1;
                $7 = {$: "../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $8 = {$: "../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047column$058past_current$1264$(_current_0, _owner_0, _past_0, _active_0) {
  if (!_active_0) {
    return _past_0;
  } else {
    return {$: "../../src/ecs/column.HistoryCon", "id": _current_0, "value": _owner_0, "rest": _past_0};
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_swap_checked$1264$(_id_0, _incoming_0, _metadata_0, _values_0, _valid_0) {
  if (!_valid_0) {
    return {$: "../../src/ecs/column.Rejected", "column": ($$$$047$$$047src$047ecs$047column$058indexed_wrap$1264$(_values_0, _metadata_0)), "incoming": _incoming_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047$$$047src$047ecs$047column$058indexed_swapped$1264$(_metadata_0, array_rmw(_values_0, _x_0, () => _incoming_0));
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_seek$1264$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _incoming_0 = $5;
      const _remaining_0 = $6;
      const _past_0 = $7;
      const _phase_0 = $8;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../src/ecs/column.Accepted", "column": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "../../src/ecs/column.Rejected", "column": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "incoming": _incoming_0};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../src/ecs/column.Accepted", "column": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _metadata_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = _incoming_0;
            $6 = {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $7 = _past_0;
            $8 = {$: "../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return {$: "../../src/ecs/column.Accepted", "column": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": _rest_1, "past": _past_0}}}, "previous": {$: "Some", "value": _owner_1}};
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "../../src/ecs/column.Accepted", "column": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "previous": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _metadata_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _incoming_0;
                $6 = _rest_1;
                $7 = {$: "../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $8 = {$: "../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047component$058swap_join$1264$(_rest_0, _id_0, _incoming_0, _tick_0, _result_0) {
  if (_result_0.$ === "../../src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    const _previous_0 = _result_0["previous"];
    return $$$$047$$$047src$047ecs$047component$058mark_swapped$1264$(_rest_0, _column_0, _id_0, _incoming_0, _tick_0, ($$$$047$$$047src$047ecs$047component$058owner_present$1264$(_previous_0)));
  } else {
    const _column_1 = _result_0["column"];
    const _incoming_1 = _result_0["incoming"];
    return {$: "Tuple", "fst": ($schema$058put_locked$(_rest_0, _column_1)), "snd": {$: "../../src/ecs/component.SwapRejected", "incoming": _incoming_1}};
  }
}

function $$$$047$$$047src$047ecs$047column$058ensure$1264$(_column_0, _target_0) {
  return $$$$047$$$047src$047ecs$047column$058ensure_checked$1264$(_column_0, _target_0, ($Bool$and$((_target_0 > 0), (_target_0 <= 131072))));
}

function $$$$047$$$047src$047ecs$047component$058swap_join$1263$(_rest_0, _id_0, _incoming_0, _tick_0, _result_0) {
  if (_result_0.$ === "../../src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    const _previous_0 = _result_0["previous"];
    return $$$$047$$$047src$047ecs$047component$058mark_swapped$1263$(_rest_0, _column_0, _id_0, _incoming_0, _tick_0, ($$$$047$$$047src$047ecs$047component$058owner_present$1263$(_previous_0)));
  } else {
    const _column_1 = _result_0["column"];
    const _incoming_1 = _result_0["incoming"];
    return {$: "Tuple", "fst": ($schema$058put_enabled$(_rest_0, _column_1)), "snd": {$: "../../src/ecs/component.SwapRejected", "incoming": _incoming_1}};
  }
}

function $$$$047$$$047src$047ecs$047column$058ensure$1263$(_column_0, _target_0) {
  return $$$$047$$$047src$047ecs$047column$058ensure_checked$1263$(_column_0, _target_0, ($Bool$and$((_target_0 > 0), (_target_0 <= 131072))));
}

function $$$$047$$$047src$047ecs$047capabilities$058invoke$12612$(_args_0, _ctx_0) {
  return $gameplay$058retry_body$1261$(_args_0, _ctx_0);
}

function $$$$047$$$047src$047ecs$047compose$058both$1264$(_frame_0) {
  return $$$$047$$$047src$047ecs$047compose$058and_join$1264$(($reference$045declarations$058work_match$(_frame_0)));
}

function $$$$047$$$047src$047ecs$047component$058replace_clock_advanced$1262$(_id_0, _incomingPresent_0, _incoming_0, _advanced_0) {
  const _world_0 = _advanced_0["fst"];
  const _tick_0 = _advanced_0["snd"];
  return $$$$047$$$047src$047ecs$047component$058replaced$1262$(($$$$047$$$047src$047ecs$047component$058swap_world$1262$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _world_0)));
}

function $$$$047$$$047src$047ecs$047owned$045compose$058body_returned$1262$(_next_0, _observed_0) {
  const _t_0 = _observed_0["fst"];
  const _tx_0 = _t_0["tx"];
  const _internal_0 = _t_0["error"];
  const _t_1 = _observed_0["snd"];
  const _user_0 = _t_1["fst"];
  const _value_0 = _t_1["snd"];
  return $$$$047$$$047src$047ecs$047owned$045compose$058completed$1262$(_next_0, _tx_0, _value_0, ($$$$047$$$047src$047ecs$047compose$058outcome$1260$(_internal_0, _user_0)));
}

function $$$$047$$$047src$047ecs$047owned$045compose$058left$1264$(_observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _result_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($owned$045rows$058leave_advanced$(_owner_0)), "snd": _result_0};
}

function $$$$047$$$047src$047ecs$047capabilities$058invoke$12611$(_args_0, _ctx_0) {
  return $reference$045declarations$058advanced_body$1261$(_args_0, _ctx_0);
}

function $owned$045rows$058enter_advanced$(_frame_0) {
  const _t_0 = _frame_0["tx"];
  const _t_1 = _t_0["world"];
  const _namespace_0 = _t_1["namespace"];
  const _nextId_0 = _t_1["nextId"];
  const _highWater_0 = _t_1["highWater"];
  const _live_0 = _t_1["live"];
  const _capacity_0 = _t_1["capacity"];
  const _depth_0 = _t_1["depth"];
  const _t_2 = _t_1["store"];
  const _stock_0 = _t_2["stock"];
  const _recipe_0 = _t_2["recipe"];
  const _queue_0 = _t_2["queue"];
  const _enabled_0 = _t_2["enabled"];
  const _locked_0 = _t_2["locked"];
  const _resource_0 = _t_1["resource"];
  const _events_0 = _t_1["events"];
  const _pending_0 = _t_1["pending"];
  const _registrations_0 = _t_1["registrations"];
  const _nextSystemId_0 = _t_1["nextSystemId"];
  const _clock_0 = _t_1["clock"];
  const _undo_0 = _t_0["undo"];
  const _commands_0 = _t_0["commands"];
  const _txEvents_0 = _t_0["events"];
  const _handle_0 = _frame_0["handle"];
  const _error_0 = _frame_0["error"];
  const _cursor_0 = _frame_0["cursor"];
  return {$: "owned-rows.AdvancedRow", "state": {$: "owned-rows.AdvancedState", "header": {$: "../../src/ecs/owned-family.Header", "namespace": _namespace_0, "nextId": _nextId_0, "live": _live_0, "handle": _handle_0, "clock": _clock_0, "error": _error_0, "cursor": _cursor_0}, "stock": ($$$$047$$$047src$047ecs$047restored$045row$058detach$1260$(_stock_0, ($owned$045rows$058id$(_handle_0)))), "queue": ($$$$047$$$047src$047ecs$047restored$045row$058detach$1262$(_queue_0, ($owned$045rows$058id$(_handle_0)))), "cold": {$: "owned-rows.AdvancedCold", "state": {$: "owned-rows.AdvancedColdState", "highWater": _highWater_0, "capacity": _capacity_0, "depth": _depth_0, "recipe": _recipe_0, "enabled": _enabled_0, "locked": _locked_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "undo": _undo_0, "commands": _commands_0, "txEvents": _txEvents_0}}}};
}

function $$$$047$$$047src$047ecs$047compose$058both$1266$(_frame_0) {
  return $$$$047$$$047src$047ecs$047compose$058and_join$1266$(($reference$045declarations$058structural_match$(_frame_0)));
}

function $$$$047$$$047src$047ecs$047component$058mark_swapped$1260$(_rest_0, _column_0, _id_0, _incoming_0, _tick_0, _observed_0) {
  const _previous_0 = _observed_0["fst"];
  const _wasPresent_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($schema$058put_stock$(_rest_0, ($$$$047$$$047src$047ecs$047column$058mark$1260$(_column_0, _id_0, _incoming_0, _wasPresent_0, _tick_0)))), "snd": {$: "../../src/ecs/component.Swapped", "previous": _previous_0}};
}

function $$$$047$$$047src$047ecs$047column$058ensure_checked$1260$(_column_0, _target_0, _valid_0) {
  if (_column_0.$ === "../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    if (!_valid_0) {
      return {$: "../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
    } else {
      return $$$$047$$$047src$047ecs$047column$058ensure_sized$1260$(_target_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
    }
  } else if (_column_0.$ === "../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../../src/ecs/column.Prepared", "state": _carrier_0};
    } else {
      return $$$$047$$$047src$047ecs$047column$058ensure_state$1260$(_target_0, ($$$$047$$$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
    }
  } else if (_column_0.$ === "../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../../src/ecs/column.Indexed", "state": _carrier_1};
    } else {
      return $$$$047$$$047src$047ecs$047column$058indexed_ensure_state$1260$(_target_0, ($$$$047$$$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
    }
  } else {
    const _carrier_2 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../../src/ecs/column.PreparedIndexed", "state": _carrier_2};
    } else {
      return $$$$047$$$047src$047ecs$047column$058indexed_prepared_ensure_state$1260$(_target_0, ($$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
    }
  }
}

function $$$$047$$$047src$047ecs$047component$058mark_swapped$1261$(_rest_0, _column_0, _id_0, _incoming_0, _tick_0, _observed_0) {
  const _previous_0 = _observed_0["fst"];
  const _wasPresent_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($schema$058put_recipe$(_rest_0, ($$$$047$$$047src$047ecs$047column$058mark$1261$(_column_0, _id_0, _incoming_0, _wasPresent_0, _tick_0)))), "snd": {$: "../../src/ecs/component.Swapped", "previous": _previous_0}};
}

function $$$$047$$$047src$047ecs$047column$058ensure_checked$1261$(_column_0, _target_0, _valid_0) {
  if (_column_0.$ === "../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    if (!_valid_0) {
      return {$: "../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
    } else {
      return $$$$047$$$047src$047ecs$047column$058ensure_sized$1261$(_target_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
    }
  } else if (_column_0.$ === "../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../../src/ecs/column.Prepared", "state": _carrier_0};
    } else {
      return $$$$047$$$047src$047ecs$047column$058ensure_state$1261$(_target_0, ($$$$047$$$047src$047ecs$047column$058unseal$1261$(_carrier_0)));
    }
  } else if (_column_0.$ === "../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../../src/ecs/column.Indexed", "state": _carrier_1};
    } else {
      return $$$$047$$$047src$047ecs$047column$058indexed_ensure_state$1261$(_target_0, ($$$$047$$$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_1)));
    }
  } else {
    const _carrier_2 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../../src/ecs/column.PreparedIndexed", "state": _carrier_2};
    } else {
      return $$$$047$$$047src$047ecs$047column$058indexed_prepared_ensure_state$1261$(_target_0, ($$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1261$(_carrier_2)));
    }
  }
}

function $$$$047$$$047src$047ecs$047owned$045family$058get_checked$1260$(_rest_0, _cell_0, _observed_0) {
  const _header_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": ($owned$045rows$058put_work_stock$(($owned$045rows$058put_header_work_stock$(_rest_0, _header_0)), _cell_0)), "snd": {$: "../../src/ecs/component.MissingEntity"}};
  } else {
    return $$$$047$$$047src$047ecs$047owned$045family$058get_targeted$1260$(_rest_0, _cell_0, ($$$$047$$$047src$047ecs$047owned$045family$058target$(_header_0)));
  }
}

function $$$$047$$$047src$047ecs$047owned$045family$058write_checked$1260$(_rest_0, _cell_0, _incoming_0, _observed_0) {
  const _meta_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return $$$$047$$$047src$047ecs$047owned$045family$058rejected$1260$(_rest_0, _cell_0, _incoming_0, {$: "../../src/ecs/world.MissingEntity"}, _meta_0);
  } else {
    return $$$$047$$$047src$047ecs$047owned$045family$058write_targeted$1260$(_rest_0, _cell_0, _incoming_0, ($$$$047$$$047src$047ecs$047owned$045family$058target$(_meta_0)));
  }
}

function $$$$047$$$047src$047ecs$047owned$045family$058get_checked$1261$(_rest_0, _cell_0, _observed_0) {
  const _header_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": ($owned$045rows$058put_work_recipe$(($owned$045rows$058put_header_work_recipe$(_rest_0, _header_0)), _cell_0)), "snd": {$: "../../src/ecs/component.MissingEntity"}};
  } else {
    return $$$$047$$$047src$047ecs$047owned$045family$058get_targeted$1261$(_rest_0, _cell_0, ($$$$047$$$047src$047ecs$047owned$045family$058target$(_header_0)));
  }
}

function $$$$047$$$047src$047ecs$047owned$045family$058get_checked$1262$(_rest_0, _cell_0, _observed_0) {
  const _header_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": ($owned$045rows$058put_work_queue$(($owned$045rows$058put_header_work_queue$(_rest_0, _header_0)), _cell_0)), "snd": {$: "../../src/ecs/component.MissingEntity"}};
  } else {
    return $$$$047$$$047src$047ecs$047owned$045family$058get_targeted$1262$(_rest_0, _cell_0, ($$$$047$$$047src$047ecs$047owned$045family$058target$(_header_0)));
  }
}

function $$$$047$$$047src$047ecs$047column$058restore_stamp$1261$(_column_0, _id_0, _stamp_0) {
  if (_column_0.$ === "../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../src/ecs/column.Column", "values": _values_0, "stamps": ($$$$047$$$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, _stamp_0))};
  } else if (_column_0.$ === "../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058restore_state$1261$(_id_0, _stamp_0, ($$$$047$$$047src$047ecs$047column$058unseal$1261$(_carrier_0)));
  } else if (_column_0.$ === "../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058indexed_restore_state$1261$(_id_0, _stamp_0, ($$$$047$$$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058indexed_prepared_restore_state$1261$(_id_0, _stamp_0, ($$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1261$(_carrier_2)));
  }
}

function $$$$047$$$047src$047ecs$047captured$045column$058indexed_restore_plain$1261$(_id_0, _values_0, _metadata_0, _slot_0) {
  const _owner_0 = _slot_0["owner"];
  const _stamp_0 = _slot_0["stamp"];
  const _dirty_0 = _slot_0["dirty"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  return $$$$047$$$047src$047ecs$047captured$045column$058stamped$1261$(_id_0, ($$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$((_values_0[_x_0 % _values_0.length] = _owner_0, _values_0), _metadata_0)), _stamp_0, _dirty_0);
}

function $$$$047$$$047src$047ecs$047column$058restore_stamp$1262$(_column_0, _id_0, _stamp_0) {
  if (_column_0.$ === "../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../src/ecs/column.Column", "values": _values_0, "stamps": ($$$$047$$$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, _stamp_0))};
  } else if (_column_0.$ === "../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058restore_state$1262$(_id_0, _stamp_0, ($$$$047$$$047src$047ecs$047column$058unseal$1262$(_carrier_0)));
  } else if (_column_0.$ === "../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058indexed_restore_state$1262$(_id_0, _stamp_0, ($$$$047$$$047src$047ecs$047column$058indexed_unseal$1262$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058indexed_prepared_restore_state$1262$(_id_0, _stamp_0, ($$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1262$(_carrier_2)));
  }
}

function $$$$047$$$047src$047ecs$047captured$045column$058indexed_restore_plain$1262$(_id_0, _values_0, _metadata_0, _slot_0) {
  const _owner_0 = _slot_0["owner"];
  const _stamp_0 = _slot_0["stamp"];
  const _dirty_0 = _slot_0["dirty"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  return $$$$047$$$047src$047ecs$047captured$045column$058stamped$1262$(_id_0, ($$$$047$$$047src$047ecs$047column$058indexed_wrap$1262$((_values_0[_x_0 % _values_0.length] = _owner_0, _values_0), _metadata_0)), _stamp_0, _dirty_0);
}

function $$$$047$$$047src$047ecs$047compose$058selected_value$1260$(_mode_0, _value_0) {
  if (_mode_0.$ === "../../src/ecs/compose.Required") {
    if (_value_0.$ === "../../src/ecs/component.Found") {
      return true;
    } else {
      return false;
    }
  } else if (_mode_0.$ === "../../src/ecs/compose.Present") {
    if (_value_0.$ === "../../src/ecs/component.Found") {
      return true;
    } else {
      return false;
    }
  } else if (_mode_0.$ === "../../src/ecs/compose.Absent") {
    if (_value_0.$ === "../../src/ecs/component.ComponentAbsent") {
      return true;
    } else {
      return false;
    }
  } else {
    if (_value_0.$ === "../../src/ecs/component.Found") {
      return true;
    } else if (_value_0.$ === "../../src/ecs/component.ComponentAbsent") {
      return true;
    } else {
      return false;
    }
  }
}

function $$$$047$$$047src$047ecs$047compose$058read_join$1264$(_handle_0, _error_0, _cursor_0, _observed_0) {
  const _tx_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../src/ecs/compose.Frame", "tx": _tx_0, "handle": _handle_0, "error": _error_0, "cursor": _cursor_0}, "snd": _value_0};
}

function $$$$047$$$047src$047ecs$047component$058tx_get$1264$(_family_0, _tx_0, _handle_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047src$047ecs$047component$058tx_get_join$1264$(_undo_0, _commands_0, _events_0, ($$$$047$$$047src$047ecs$047component$058get$1264$(_family_0, _world_0, _handle_0)));
}

function $$$$047$$$047src$047ecs$047component$058tx_get_join$1261$(_undo_0, _commands_0, _events_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "snd": _value_0};
}

function $$$$047$$$047src$047ecs$047column$058plain_view_taken$1264$(_stamps_0, _id_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "None"}};
  } else {
    const _owner_0 = _t_0["value"];
    return $$$$047$$$047src$047ecs$047column$058plain_view_projected$1264$(_values_0, _stamps_0, _id_0, ($schema$058project_locked$(_owner_0)));
  }
}

function $$$$047$$$047src$047ecs$047column$058prepared_view_current$1264$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "None"}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    const _owned_0 = _owner_0["value"];
    return $$$$047$$$047src$047ecs$047column$058prepared_view_projected$1264$(_values_0, _stamps_0, _capacity_0, _current_0, _remaining_0, _past_0, ($schema$058project_locked$(_owned_0)));
  }
}

function $$$$047$$$047src$047ecs$047column$058prepared_view_different$1264$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _backwards_0) {
  if (_backwards_0) {
    return $$$$047$$$047src$047ecs$047column$058view_taken$1264$(_id_0, ($$$$047$$$047src$047ecs$047column$058swap_recovered$1264$(_id_0, {$: "None"}, ($$$$047$$$047src$047ecs$047column$058recover_current$1264$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0))))));
  } else {
    const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
    const _x_1 = ((_x_0 + 1) >>> 0);
    return $$$$047$$$047src$047ecs$047column$058seek_view$1264$(_x_1, _values_0, _stamps_0, _capacity_0, _id_0, _remaining_0, ($$$$047$$$047src$047ecs$047column$058past_current$1264$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../src/ecs/column.Inspect"});
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_view_checked$1264$(_id_0, _values_0, _metadata_0, _valid_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": ($$$$047$$$047src$047ecs$047column$058indexed_wrap$1264$(_values_0, _metadata_0)), "snd": {$: "None"}};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $$$$047$$$047src$047ecs$047column$058indexed_view_taken$1264$(_id_0, _metadata_0, array_rmw(_values_0, _x_0, () => _x_1));
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepared_view_current$1264$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "None"}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    const _owned_0 = _owner_0["value"];
    return $$$$047$$$047src$047ecs$047column$058indexed_prepared_view_projected$1264$(_values_0, _metadata_0, _capacity_0, _current_0, _remaining_0, _past_0, ($schema$058project_locked$(_owned_0)));
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepared_view_different$1264$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _backwards_0) {
  if (_backwards_0) {
    return $$$$047$$$047src$047ecs$047column$058view_taken$1264$(_id_0, ($$$$047$$$047src$047ecs$047column$058swap_recovered$1264$(_id_0, {$: "None"}, ($$$$047$$$047src$047ecs$047column$058indexed_recover_current$1264$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0))))));
  } else {
    const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
    const _x_1 = ((_x_0 + 1) >>> 0);
    return $$$$047$$$047src$047ecs$047column$058indexed_seek_view$1264$(_x_1, _values_0, _metadata_0, _capacity_0, _id_0, _remaining_0, ($$$$047$$$047src$047ecs$047column$058past_current$1264$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../src/ecs/column.Inspect"});
  }
}

function $$$$047$$$047src$047ecs$047column$058plain_view_projected$1263$(_values_0, _stamps_0, _id_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = {$: "Some", "value": _owner_0};
  return $$$$047$$$047src$047ecs$047column$058restored$1263$(array_rmw(_values_0, _x_0, () => _x_1), _projection_0, _stamps_0);
}

function $schema$058project_enabled$(_owner_0) {
  return {$: "Tuple", "fst": {$: "schema.Enabled"}, "snd": {$: "schema.Enabled"}};
}

function $$$$047$$$047src$047ecs$047column$058prepared_view_projected$1263$(_values_0, _stamps_0, _capacity_0, _current_0, _remaining_0, _past_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "Some", "value": _owner_0}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047$$$047src$047ecs$047column$058view_taken$1263$(_id_0, _outcome_0) {
  if (_outcome_0.$ === "../../src/ecs/column.Rejected") {
    const _column_0 = _outcome_0["column"];
    return {$: "Tuple", "fst": _column_0, "snd": {$: "None"}};
  } else {
    const _column_1 = _outcome_0["column"];
    const _t_0 = _outcome_0["previous"];
    if (_t_0.$ === "None") {
      return {$: "Tuple", "fst": _column_1, "snd": {$: "None"}};
    } else {
      const _owner_0 = _t_0["value"];
      return $$$$047$$$047src$047ecs$047column$058viewed$1263$(($schema$058project_enabled$(_owner_0)), _column_1, _id_0);
    }
  }
}

function $$$$047$$$047src$047ecs$047column$058seek_view$1263$($0, $1, $2, $3, $4, $5, $6, $7) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _remaining_0 = $5;
      const _past_0 = $6;
      const _phase_0 = $7;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "Tuple", "fst": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "snd": {$: "None"}};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _stamps_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $6 = _past_0;
            $7 = {$: "../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return $$$$047$$$047src$047ecs$047column$058prepared_view_projected$1263$(_values_0, _stamps_0, _capacity_0, _target_0, _rest_1, _past_0, ($schema$058project_enabled$(_owner_1)));
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "Tuple", "fst": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "snd": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _stamps_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _rest_1;
                $6 = {$: "../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $7 = {$: "../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_view_taken$1263$(_id_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "Tuple", "fst": ($$$$047$$$047src$047ecs$047column$058indexed_wrap$1263$(_values_0, _metadata_0)), "snd": {$: "None"}};
  } else {
    const _owner_0 = _t_0["value"];
    return $$$$047$$$047src$047ecs$047column$058indexed_view_projected$1263$(_id_0, _values_0, _metadata_0, ($schema$058project_enabled$(_owner_0)));
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepared_view_projected$1263$(_values_0, _metadata_0, _capacity_0, _current_0, _remaining_0, _past_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "Some", "value": _owner_0}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047$$$047src$047ecs$047column$058indexed_seek_view$1263$($0, $1, $2, $3, $4, $5, $6, $7) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _remaining_0 = $5;
      const _past_0 = $6;
      const _phase_0 = $7;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "Tuple", "fst": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "snd": {$: "None"}};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _metadata_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $6 = _past_0;
            $7 = {$: "../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return $$$$047$$$047src$047ecs$047column$058indexed_prepared_view_projected$1263$(_values_0, _metadata_0, _capacity_0, _target_0, _rest_1, _past_0, ($schema$058project_enabled$(_owner_1)));
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "Tuple", "fst": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "snd": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _metadata_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _rest_1;
                $6 = {$: "../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $7 = {$: "../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047column$058restored$1262$(_result_0, _projection_0, _stamps_0) {
  const _values_0 = _result_0["fst"];
  return {$: "Tuple", "fst": {$: "../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "Some", "value": _projection_0}};
}

function $schema$058project_queue_join$(_value_0, _length_0, _observed_0) {
  const _array_0 = _observed_0["fst"];
  const _values_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "schema.Queue", "value": _value_0, "owned": _array_0, "length": _length_0}, "snd": {$: "schema.QueueView", "value": _value_0, "owned": ($schema$058prefix$(_length_0, _values_0))}};
}

function $$$$047$$$047src$047ecs$047column$058viewed$1262$(_projected_0, _column_0, _id_0) {
  const _owner_0 = _projected_0["fst"];
  const _result_0 = _projected_0["snd"];
  if (_column_0.$ === "../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "Some", "value": _owner_0};
    return $$$$047$$$047src$047ecs$047column$058restored$1262$(array_rmw(_values_0, _x_0, () => _x_1), _result_0, _stamps_0);
  } else if (_column_0.$ === "../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058viewed_return$1262$(_result_0, ($$$$047$$$047src$047ecs$047column$058swap$1262$({$: "../../src/ecs/column.Prepared", "state": _carrier_0}, _id_0, {$: "Some", "value": _owner_0})));
  } else if (_column_0.$ === "../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058indexed_projected_state$1262$(_id_0, {$: "Tuple", "fst": _owner_0, "snd": _result_0}, ($$$$047$$$047src$047ecs$047column$058indexed_unseal$1262$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058viewed_return$1262$(_result_0, ($$$$047$$$047src$047ecs$047column$058swap$1262$({$: "../../src/ecs/column.PreparedIndexed", "state": _carrier_2}, _id_0, {$: "Some", "value": _owner_0})));
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_view_projected$1262$(_id_0, _values_0, _metadata_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = {$: "Some", "value": _owner_0};
  return $$$$047$$$047src$047ecs$047column$058indexed_view_restored$1262$(_metadata_0, _projection_0, array_rmw(_values_0, _x_0, () => _x_1));
}

function $$$$047$$$047src$047ecs$047column$058viewed_return$1261$(_view_0, _result_0) {
  if (_result_0.$ === "../../src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    return {$: "Tuple", "fst": _column_0, "snd": {$: "Some", "value": _view_0}};
  } else {
    const _column_1 = _result_0["column"];
    return {$: "Tuple", "fst": _column_1, "snd": {$: "None"}};
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_projected_state$1261$(_id_0, _result_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047src$047ecs$047column$058indexed_view_projected$1261$(_id_0, _values_0, _metadata_0, _result_0);
}

function $$$$047$$$047src$047ecs$047column$058indexed_view_restored$1261$(_metadata_0, _projection_0, _result_0) {
  const _values_0 = _result_0["fst"];
  return {$: "Tuple", "fst": ($$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0)), "snd": {$: "Some", "value": _projection_0}};
}

function $schema$058array_view_finished$(_collected_0) {
  if (_collected_0.$ === "schema.ArrayViewComplete") {
    const _array_0 = _collected_0["array"];
    const _values_0 = _collected_0["values"];
    return {$: "Tuple", "fst": _array_0, "snd": _values_0};
  } else {
    const _array_1 = _collected_0["array"];
    return $schema$058array_view_structural$(_array_1);
  }
}

function $schema$058array_view_collect$($0, $1, $2, $3, $4) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _index_0 = $1;
      const _capacity_0 = $2;
      const _reverse_0 = $3;
      const _observed_0 = $4;
      if (_fuel_0 === 0) {
        const _array_0 = _observed_0["fst"];
        const _t_0 = _observed_0["snd"];
        if (_t_0.$ === "None") {
          return {$: "schema.ArrayViewRefused", "array": _array_0, "partial": _reverse_0};
        } else {
          const _value_0 = _t_0["value"];
          return {$: "schema.ArrayViewComplete", "array": _array_0, "values": ($List$reverse$({$: "Con", "head": _value_0, "tail": _reverse_0}))};
        }
      } else {
        const _rest_0 = (_fuel_0 - 1);
        const _array_1 = _observed_0["fst"];
        const _t_1 = _observed_0["snd"];
        if (_t_1.$ === "None") {
          return {$: "schema.ArrayViewRefused", "array": _array_1, "partial": _reverse_0};
        } else {
          const _value_1 = _t_1["value"];
          $0 = _rest_0;
          $1 = ((_index_0 + 1) >>> 0);
          $2 = _capacity_0;
          $3 = {$: "Con", "head": _value_1, "tail": _reverse_0};
          $4 = ($schema$058array_view_read$(_array_1, ((_index_0 + 1) >>> 0), _capacity_0));
          continue;
        }
      }
    }
  }
}

function $schema$058array_view_read$(_array_0, _index_0, _capacity_0) {
  return $schema$058array_view_read_checked$(_array_0, _index_0, (_index_0 < _capacity_0));
}

function $owned$045rows$058put_duplicate_stock$(_rest_0, _cell_0) {
  const _header_0 = _rest_0["header"];
  const _cold_0 = _rest_0["cold"];
  return {$: "owned-rows.DuplicateRow", "state": {$: "owned-rows.DuplicateState", "header": _header_0, "stock": _cell_0, "cold": _cold_0}};
}

function $owned$045rows$058put_header_duplicate_stock$(_rest_0, _header_0) {
  const _cold_0 = _rest_0["cold"];
  return {$: "owned-rows.DuplicateStockRest", "header": _header_0, "cold": _cold_0};
}

function $$$$047$$$047src$047ecs$047owned$045family$058get_targeted$1263$(_rest_0, _cell_0, _observed_0) {
  const _header_0 = _observed_0["fst"];
  const _id_0 = _observed_0["snd"];
  return $$$$047$$$047src$047ecs$047owned$045family$058get_matching$1263$(($owned$045rows$058put_header_duplicate_stock$(_rest_0, _header_0)), ($$$$047$$$047src$047ecs$047owned$045family$058cell_matches$1260$(_cell_0, _id_0)));
}

function $$$$047$$$047src$047ecs$047owned$045family$058target$(_header_0) {
  const _namespace_0 = _header_0["namespace"];
  const _nextId_0 = _header_0["nextId"];
  const _live_0 = _header_0["live"];
  const _t_0 = _header_0["handle"];
  const _ns_0 = _t_0["namespace"];
  const _id_0 = _t_0["id"];
  const _clock_0 = _header_0["clock"];
  const _error_0 = _header_0["error"];
  const _cursor_0 = _header_0["cursor"];
  return {$: "Tuple", "fst": {$: "../../src/ecs/owned-family.Header", "namespace": _namespace_0, "nextId": _nextId_0, "live": _live_0, "handle": {$: "../../src/ecs/world.Handle", "namespace": _ns_0, "id": _id_0}, "clock": _clock_0, "error": _error_0, "cursor": _cursor_0}, "snd": _id_0};
}

function $$$$047$$$047src$047ecs$047owned$045family$058checked_metadata$(_valid_0, _live_0, _id_0, _namespace_0, _nextId_0, _handle_0, _clock_0, _error_0, _cursor_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../../src/ecs/owned-family.Header", "namespace": _namespace_0, "nextId": _nextId_0, "live": _live_0, "handle": _handle_0, "clock": _clock_0, "error": _error_0, "cursor": _cursor_0}, "snd": false};
  } else {
    return $$$$047$$$047src$047ecs$047owned$045family$058checked_live$(_namespace_0, _nextId_0, _handle_0, _clock_0, _error_0, _cursor_0, {$: "Tuple", fst: _live_0, snd: _live_0[_id_0 % _live_0.length]});
  }
}

function $$$$047$$$047src$047ecs$047owned$045family$058rejected$1263$(_rest_0, _cell_0, _incoming_0, _reason_0, _header_0) {
  return {$: "../../src/ecs/owned-family.Rejected", "owner": ($owned$045rows$058put_duplicate_stock$(($owned$045rows$058put_header_duplicate_stock$(_rest_0, ($$$$047$$$047src$047ecs$047owned$045family$058reject_header$(_reason_0, _header_0)))), _cell_0)), "incoming": _incoming_0, "error": _reason_0};
}

function $$$$047$$$047src$047ecs$047owned$045family$058write_targeted$1263$(_rest_0, _cell_0, _incoming_0, _observed_0) {
  const _meta_0 = _observed_0["fst"];
  const _id_0 = _observed_0["snd"];
  return $$$$047$$$047src$047ecs$047owned$045family$058write_matching$1263$(_rest_0, _meta_0, _incoming_0, ($$$$047$$$047src$047ecs$047owned$045family$058cell_matches$1260$(_cell_0, _id_0)));
}

function $$$$047$$$047src$047ecs$047lifecycle$058set$(_entries_0, _id_0, _stamp_0) {
  return {$: "Con", "head": {$: "../../src/ecs/lifecycle.Entry", "id": _id_0, "stamp": _stamp_0}, "tail": ($$$$047$$$047src$047ecs$047lifecycle$058clear$(_entries_0, _id_0))};
}

function $$$$047$$$047src$047ecs$047column$058restore_state$1260$(_id_0, _stamp_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": ($$$$047$$$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, _stamp_0)), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047src$047ecs$047column$058indexed_restore_state$1260$(_id_0, _stamp_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, ($$$$047$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, _stamp_0)));
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepared_restore_state$1260$(_id_0, _stamp_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": ($$$$047$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, _stamp_0)), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047src$047ecs$047indexed$045lifecycle$058got_changed$(_added_0, _capacity_0, _depth_0, _exceptional_0, _first_0, _observed_0) {
  const _changed_0 = _observed_0["fst"];
  const _last_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../src/ecs/indexed-lifecycle.Metadata", "added": _added_0, "changed": _changed_0, "capacity": _capacity_0, "depth": _depth_0, "exceptional": _exceptional_0}, "snd": {$: "../../src/ecs/lifecycle.Stamp", "added": _first_0, "changed": _last_0}};
}

function $$$$047$$$047src$047ecs$047owned$045compose$058prepend$1260$(_value_0, _observed_0) {
  const _tx_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  const _outcome_0 = _t_0["fst"];
  const _values_0 = _t_0["snd"];
  return {$: "Tuple", "fst": _tx_0, "snd": {$: "Tuple", "fst": _outcome_0, "snd": {$: "Con", "head": _value_0, "tail": _values_0}}};
}

function $gameplay$058work_stock_read$1261$(_observed_0) {
  const _ctx_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "../../src/ecs/component.Found") {
    const _stock_0 = _t_0["value"];
    return $gameplay$058work_recipe_read$1261$(_stock_0, run_loop($$$$047$$$047src$047ecs$047capabilities$058read$1266$(_ctx_0)));
  } else {
    return {$: "Tuple", "fst": _ctx_0, "snd": {$: "Tuple", "fst": {$: "../../src/ecs/transaction.Failure", "error": {$: "gameplay.MissingFixture"}}, "snd": {$: "Unit"}}};
  }
}

function $$$$047$$$047src$047ecs$047indexed$045lifecycle$058clear_checked$(_id_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, _isnormal_0, _fits_0) {
  if (!_isnormal_0) {
    return {$: "../../src/ecs/indexed-lifecycle.Metadata", "added": _added_0, "changed": _changed_0, "capacity": _capacity_0, "depth": _depth_0, "exceptional": ($$$$047$$$047src$047ecs$047lifecycle$058clear$(_exceptional_0, _id_0))};
  } else {
    if (!_fits_0) {
      return {$: "../../src/ecs/indexed-lifecycle.Metadata", "added": _added_0, "changed": _changed_0, "capacity": _capacity_0, "depth": _depth_0, "exceptional": _exceptional_0};
    } else {
      return $$$$047$$$047src$047ecs$047indexed$045lifecycle$058write_ready$(_id_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, {$: "../../src/ecs/lifecycle.Stamp", "added": 0, "changed": 0});
    }
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_swapped$1260$(_metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _previous_0 = _result_0["snd"];
  return {$: "../../src/ecs/column.Accepted", "column": ($$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "previous": _previous_0};
}

function $$$$047$$$047src$047ecs$047column$058indexed_swapped$1261$(_metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _previous_0 = _result_0["snd"];
  return {$: "../../src/ecs/column.Accepted", "column": ($$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0)), "previous": _previous_0};
}

function $$$$047$$$047src$047ecs$047column$058indexed_swapped$1262$(_metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _previous_0 = _result_0["snd"];
  return {$: "../../src/ecs/column.Accepted", "column": ($$$$047$$$047src$047ecs$047column$058indexed_wrap$1262$(_values_0, _metadata_0)), "previous": _previous_0};
}

function $$$$047$$$047src$047ecs$047column$058indexed_swapped$1263$(_metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _previous_0 = _result_0["snd"];
  return {$: "../../src/ecs/column.Accepted", "column": ($$$$047$$$047src$047ecs$047column$058indexed_wrap$1263$(_values_0, _metadata_0)), "previous": _previous_0};
}

function $$$$047$$$047src$047ecs$047column$058indexed_swapped$1264$(_metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _previous_0 = _result_0["snd"];
  return {$: "../../src/ecs/column.Accepted", "column": ($$$$047$$$047src$047ecs$047column$058indexed_wrap$1264$(_values_0, _metadata_0)), "previous": _previous_0};
}

function $$$$047$$$047src$047ecs$047component$058mark_swapped$1264$(_rest_0, _column_0, _id_0, _incoming_0, _tick_0, _observed_0) {
  const _previous_0 = _observed_0["fst"];
  const _wasPresent_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($schema$058put_locked$(_rest_0, ($$$$047$$$047src$047ecs$047column$058mark$1264$(_column_0, _id_0, _incoming_0, _wasPresent_0, _tick_0)))), "snd": {$: "../../src/ecs/component.Swapped", "previous": _previous_0}};
}

function $$$$047$$$047src$047ecs$047column$058ensure_checked$1264$(_column_0, _target_0, _valid_0) {
  if (_column_0.$ === "../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    if (!_valid_0) {
      return {$: "../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
    } else {
      return $$$$047$$$047src$047ecs$047column$058ensure_sized$1264$(_target_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
    }
  } else if (_column_0.$ === "../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../../src/ecs/column.Prepared", "state": _carrier_0};
    } else {
      return $$$$047$$$047src$047ecs$047column$058ensure_state$1264$(_target_0, ($$$$047$$$047src$047ecs$047column$058unseal$1264$(_carrier_0)));
    }
  } else if (_column_0.$ === "../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../../src/ecs/column.Indexed", "state": _carrier_1};
    } else {
      return $$$$047$$$047src$047ecs$047column$058indexed_ensure_state$1264$(_target_0, ($$$$047$$$047src$047ecs$047column$058indexed_unseal$1264$(_carrier_1)));
    }
  } else {
    const _carrier_2 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../../src/ecs/column.PreparedIndexed", "state": _carrier_2};
    } else {
      return $$$$047$$$047src$047ecs$047column$058indexed_prepared_ensure_state$1264$(_target_0, ($$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1264$(_carrier_2)));
    }
  }
}

function $$$$047$$$047src$047ecs$047component$058mark_swapped$1263$(_rest_0, _column_0, _id_0, _incoming_0, _tick_0, _observed_0) {
  const _previous_0 = _observed_0["fst"];
  const _wasPresent_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($schema$058put_enabled$(_rest_0, ($$$$047$$$047src$047ecs$047column$058mark$1263$(_column_0, _id_0, _incoming_0, _wasPresent_0, _tick_0)))), "snd": {$: "../../src/ecs/component.Swapped", "previous": _previous_0}};
}

function $$$$047$$$047src$047ecs$047column$058ensure_checked$1263$(_column_0, _target_0, _valid_0) {
  if (_column_0.$ === "../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    if (!_valid_0) {
      return {$: "../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
    } else {
      return $$$$047$$$047src$047ecs$047column$058ensure_sized$1263$(_target_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
    }
  } else if (_column_0.$ === "../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../../src/ecs/column.Prepared", "state": _carrier_0};
    } else {
      return $$$$047$$$047src$047ecs$047column$058ensure_state$1263$(_target_0, ($$$$047$$$047src$047ecs$047column$058unseal$1263$(_carrier_0)));
    }
  } else if (_column_0.$ === "../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../../src/ecs/column.Indexed", "state": _carrier_1};
    } else {
      return $$$$047$$$047src$047ecs$047column$058indexed_ensure_state$1263$(_target_0, ($$$$047$$$047src$047ecs$047column$058indexed_unseal$1263$(_carrier_1)));
    }
  } else {
    const _carrier_2 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../../src/ecs/column.PreparedIndexed", "state": _carrier_2};
    } else {
      return $$$$047$$$047src$047ecs$047column$058indexed_prepared_ensure_state$1263$(_target_0, ($$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1263$(_carrier_2)));
    }
  }
}

function $gameplay$058retry_body$1261$(_args_0, _ctx_0) {
  const _fail_0 = _args_0["fail"];
  const _target_0 = _args_0["target"];
  const _ctx_1 = run_loop($$$$047$$$047src$047ecs$047capabilities$058set$1269$(_ctx_0, ($schema$058stock_payload$(($gameplay$058retry_value$(_fail_0))))));
  const _ctx_2 = run_loop($$$$047$$$047src$047ecs$047capabilities$058set$12610$(_ctx_1, ($schema$058recipe_payload$(($gameplay$058retry_value$(_fail_0))))));
  const _ctx_3 = run_loop($$$$047$$$047src$047ecs$047capabilities$058set$12611$(_ctx_2, ($schema$058queue_payload$(($gameplay$058retry_value$(_fail_0))))));
  const _ctx_4 = run_loop($$$$047$$$047src$047ecs$047capabilities$058send$1261$(_ctx_3, {$: "../../src/ecs/compose.Insert", "target": _target_0, "value": ($schema$058queue_payload$(($gameplay$058command_value$(_fail_0))))}));
  return {$: "Tuple", "fst": _ctx_4, "snd": {$: "Tuple", "fst": ($gameplay$058retry_outcome$(_fail_0)), "snd": {$: "Unit"}}};
}

function $$$$047$$$047src$047ecs$047compose$058and_join$1264$(_observed_0) {
  const _frame_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": _frame_0, "snd": false};
  } else {
    return $reference$045declarations$058match_queue$1260$(_frame_0);
  }
}

function $$$$047$$$047src$047ecs$047component$058replaced$1262$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../../src/ecs/component.Swapped") {
    const _previous_0 = _t_0["previous"];
    return {$: "../../src/ecs/component.Replaced", "world": _world_0, "previous": _previous_0};
  } else {
    const _incoming_0 = _t_0["incoming"];
    return {$: "../../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../src/ecs/world.CapacityExceeded"}};
  }
}

function $$$$047$$$047src$047ecs$047component$058swap_world$1262$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047src$047ecs$047world$058with_store_finish$1267$(($$$$047$$$047src$047ecs$047component$058swap_store$1262$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, ($schema$058take_queue$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047src$047ecs$047owned$045compose$058completed$1262$(_next_0, _tx_0, _value_0, _result_0) {
  if (_result_0.$ === "../../src/ecs/transaction.Success") {
    return $$$$047$$$047src$047ecs$047owned$045compose$058prepend$1262$(_value_0, _next_0(_tx_0));
  } else {
    const _error_0 = _result_0["error"];
    return {$: "Tuple", "fst": _tx_0, "snd": {$: "Tuple", "fst": {$: "../../src/ecs/transaction.Failure", "error": _error_0}, "snd": {$: "Nil"}}};
  }
}

function $owned$045rows$058leave_advanced$($0) {
  for (;;) {
    {
      const _row_0 = $0;
      if (_row_0.$ === "owned-rows.AdvancedRow") {
        const _t_0 = _row_0["state"];
        const _header_0 = _t_0["header"];
        const _stock_0 = _t_0["stock"];
        const _queue_0 = _t_0["queue"];
        const _cold_0 = _t_0["cold"];
        return $owned$045rows$058leave_advanced_cold$(_header_0, run_loop($$$$047$$$047src$047ecs$047restored$045row$058attach$1260$(_stock_0)), run_loop($$$$047$$$047src$047ecs$047restored$045row$058attach$1262$(_queue_0)), _cold_0);
      } else {
        const _inner_0 = _row_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $reference$045declarations$058advanced_body$1261$(_args_0, _ctx_0) {
  return $reference$045declarations$058advanced_stock_read$1261$(run_loop($$$$047$$$047src$047ecs$047capabilities$058read$1269$(_ctx_0)));
}

function $$$$047$$$047src$047ecs$047compose$058and_join$1266$(_observed_0) {
  const _frame_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": _frame_0, "snd": false};
  } else {
    return $reference$045declarations$058advanced_lifecycle$(_frame_0);
  }
}

function $$$$047$$$047src$047ecs$047column$058mark$1260$(_column_0, _id_0, _incoming_0, _wasPresent_0, _tick_0) {
  if (_column_0.$ === "../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../src/ecs/column.Column", "values": _values_0, "stamps": ($$$$047$$$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, ($$$$047$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, ($$$$047$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0)), _tick_0))))};
  } else if (_column_0.$ === "../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058mark_state$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047$$$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
  } else if (_column_0.$ === "../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058indexed_mark_state$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047$$$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058indexed_prepared_mark_state$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
  }
}

function $$$$047$$$047src$047ecs$047column$058ensure_sized$1260$(_target_0, _stamps_0, _sized_0) {
  const _values_0 = _sized_0["fst"];
  const _size_0 = _sized_0["snd"];
  return $$$$047$$$047src$047ecs$047column$058grow$1260$(17, _values_0, _stamps_0, _size_0, ($U32$log2$(_size_0)), _target_0, (_target_0 <= _size_0));
}

function $$$$047$$$047src$047ecs$047column$058ensure_state$1260$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047src$047ecs$047column$058ensure_prepared$1260$(_target_0, {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, (_target_0 <= _capacity_0));
}

function $$$$047$$$047src$047ecs$047column$058indexed_ensure_state$1260$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047src$047ecs$047column$058indexed_ensure_sized$1260$(_target_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepared_ensure_state$1260$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047src$047ecs$047column$058ensure_prepared$1260$(_target_0, {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, (_target_0 <= _capacity_0));
}

function $$$$047$$$047src$047ecs$047column$058mark$1261$(_column_0, _id_0, _incoming_0, _wasPresent_0, _tick_0) {
  if (_column_0.$ === "../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../src/ecs/column.Column", "values": _values_0, "stamps": ($$$$047$$$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, ($$$$047$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, ($$$$047$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0)), _tick_0))))};
  } else if (_column_0.$ === "../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058mark_state$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047$$$047src$047ecs$047column$058unseal$1261$(_carrier_0)));
  } else if (_column_0.$ === "../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058indexed_mark_state$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047$$$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058indexed_prepared_mark_state$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1261$(_carrier_2)));
  }
}

function $$$$047$$$047src$047ecs$047column$058ensure_sized$1261$(_target_0, _stamps_0, _sized_0) {
  const _values_0 = _sized_0["fst"];
  const _size_0 = _sized_0["snd"];
  return $$$$047$$$047src$047ecs$047column$058grow$1261$(17, _values_0, _stamps_0, _size_0, ($U32$log2$(_size_0)), _target_0, (_target_0 <= _size_0));
}

function $$$$047$$$047src$047ecs$047column$058ensure_state$1261$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047src$047ecs$047column$058ensure_prepared$1261$(_target_0, {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, (_target_0 <= _capacity_0));
}

function $$$$047$$$047src$047ecs$047column$058indexed_ensure_state$1261$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047src$047ecs$047column$058indexed_ensure_sized$1261$(_target_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepared_ensure_state$1261$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047src$047ecs$047column$058ensure_prepared$1261$(_target_0, {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, (_target_0 <= _capacity_0));
}

function $owned$045rows$058put_work_stock$(_rest_0, _cell_0) {
  const _header_0 = _rest_0["header"];
  const _recipe_0 = _rest_0["recipe"];
  const _queue_0 = _rest_0["queue"];
  const _cold_0 = _rest_0["cold"];
  return {$: "owned-rows.WorkRow", "state": {$: "owned-rows.WorkState", "header": _header_0, "stock": _cell_0, "recipe": _recipe_0, "queue": _queue_0, "cold": _cold_0}};
}

function $owned$045rows$058put_header_work_stock$(_rest_0, _header_0) {
  const _recipe_0 = _rest_0["recipe"];
  const _queue_0 = _rest_0["queue"];
  const _cold_0 = _rest_0["cold"];
  return {$: "owned-rows.WorkStockRest", "header": _header_0, "recipe": _recipe_0, "queue": _queue_0, "cold": _cold_0};
}

function $$$$047$$$047src$047ecs$047owned$045family$058get_targeted$1260$(_rest_0, _cell_0, _observed_0) {
  const _header_0 = _observed_0["fst"];
  const _id_0 = _observed_0["snd"];
  return $$$$047$$$047src$047ecs$047owned$045family$058get_matching$1260$(($owned$045rows$058put_header_work_stock$(_rest_0, _header_0)), ($$$$047$$$047src$047ecs$047owned$045family$058cell_matches$1260$(_cell_0, _id_0)));
}

function $$$$047$$$047src$047ecs$047owned$045family$058rejected$1260$(_rest_0, _cell_0, _incoming_0, _reason_0, _header_0) {
  return {$: "../../src/ecs/owned-family.Rejected", "owner": ($owned$045rows$058put_work_stock$(($owned$045rows$058put_header_work_stock$(_rest_0, ($$$$047$$$047src$047ecs$047owned$045family$058reject_header$(_reason_0, _header_0)))), _cell_0)), "incoming": _incoming_0, "error": _reason_0};
}

function $$$$047$$$047src$047ecs$047owned$045family$058write_targeted$1260$(_rest_0, _cell_0, _incoming_0, _observed_0) {
  const _meta_0 = _observed_0["fst"];
  const _id_0 = _observed_0["snd"];
  return $$$$047$$$047src$047ecs$047owned$045family$058write_matching$1260$(_rest_0, _meta_0, _incoming_0, ($$$$047$$$047src$047ecs$047owned$045family$058cell_matches$1260$(_cell_0, _id_0)));
}

function $owned$045rows$058put_work_recipe$(_rest_0, _cell_0) {
  const _header_0 = _rest_0["header"];
  const _stock_0 = _rest_0["stock"];
  const _queue_0 = _rest_0["queue"];
  const _cold_0 = _rest_0["cold"];
  return {$: "owned-rows.WorkRow", "state": {$: "owned-rows.WorkState", "header": _header_0, "stock": _stock_0, "recipe": _cell_0, "queue": _queue_0, "cold": _cold_0}};
}

function $owned$045rows$058put_header_work_recipe$(_rest_0, _header_0) {
  const _stock_0 = _rest_0["stock"];
  const _queue_0 = _rest_0["queue"];
  const _cold_0 = _rest_0["cold"];
  return {$: "owned-rows.WorkRecipeRest", "header": _header_0, "stock": _stock_0, "queue": _queue_0, "cold": _cold_0};
}

function $$$$047$$$047src$047ecs$047owned$045family$058get_targeted$1261$(_rest_0, _cell_0, _observed_0) {
  const _header_0 = _observed_0["fst"];
  const _id_0 = _observed_0["snd"];
  return $$$$047$$$047src$047ecs$047owned$045family$058get_matching$1261$(($owned$045rows$058put_header_work_recipe$(_rest_0, _header_0)), ($$$$047$$$047src$047ecs$047owned$045family$058cell_matches$1261$(_cell_0, _id_0)));
}

function $owned$045rows$058put_work_queue$(_rest_0, _cell_0) {
  const _header_0 = _rest_0["header"];
  const _stock_0 = _rest_0["stock"];
  const _recipe_0 = _rest_0["recipe"];
  const _cold_0 = _rest_0["cold"];
  return {$: "owned-rows.WorkRow", "state": {$: "owned-rows.WorkState", "header": _header_0, "stock": _stock_0, "recipe": _recipe_0, "queue": _cell_0, "cold": _cold_0}};
}

function $owned$045rows$058put_header_work_queue$(_rest_0, _header_0) {
  const _stock_0 = _rest_0["stock"];
  const _recipe_0 = _rest_0["recipe"];
  const _cold_0 = _rest_0["cold"];
  return {$: "owned-rows.WorkQueueRest", "header": _header_0, "stock": _stock_0, "recipe": _recipe_0, "cold": _cold_0};
}

function $$$$047$$$047src$047ecs$047owned$045family$058get_targeted$1262$(_rest_0, _cell_0, _observed_0) {
  const _header_0 = _observed_0["fst"];
  const _id_0 = _observed_0["snd"];
  return $$$$047$$$047src$047ecs$047owned$045family$058get_matching$1262$(($owned$045rows$058put_header_work_queue$(_rest_0, _header_0)), ($$$$047$$$047src$047ecs$047owned$045family$058cell_matches$1262$(_cell_0, _id_0)));
}

function $$$$047$$$047src$047ecs$047column$058restore_state$1261$(_id_0, _stamp_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": ($$$$047$$$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, _stamp_0)), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047src$047ecs$047column$058indexed_restore_state$1261$(_id_0, _stamp_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, ($$$$047$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, _stamp_0)));
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepared_restore_state$1261$(_id_0, _stamp_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": ($$$$047$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, _stamp_0)), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047src$047ecs$047column$058restore_state$1262$(_id_0, _stamp_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": ($$$$047$$$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, _stamp_0)), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047src$047ecs$047column$058indexed_restore_state$1262$(_id_0, _stamp_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047src$047ecs$047column$058indexed_wrap$1262$(_values_0, ($$$$047$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, _stamp_0)));
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepared_restore_state$1262$(_id_0, _stamp_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": ($$$$047$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, _stamp_0)), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047src$047ecs$047component$058tx_get_join$1264$(_undo_0, _commands_0, _events_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "snd": _value_0};
}

function $$$$047$$$047src$047ecs$047column$058plain_view_projected$1264$(_values_0, _stamps_0, _id_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = {$: "Some", "value": _owner_0};
  return $$$$047$$$047src$047ecs$047column$058restored$1264$(array_rmw(_values_0, _x_0, () => _x_1), _projection_0, _stamps_0);
}

function $schema$058project_locked$(_owner_0) {
  return {$: "Tuple", "fst": {$: "schema.Locked"}, "snd": {$: "schema.Locked"}};
}

function $$$$047$$$047src$047ecs$047column$058prepared_view_projected$1264$(_values_0, _stamps_0, _capacity_0, _current_0, _remaining_0, _past_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "Some", "value": _owner_0}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047$$$047src$047ecs$047column$058view_taken$1264$(_id_0, _outcome_0) {
  if (_outcome_0.$ === "../../src/ecs/column.Rejected") {
    const _column_0 = _outcome_0["column"];
    return {$: "Tuple", "fst": _column_0, "snd": {$: "None"}};
  } else {
    const _column_1 = _outcome_0["column"];
    const _t_0 = _outcome_0["previous"];
    if (_t_0.$ === "None") {
      return {$: "Tuple", "fst": _column_1, "snd": {$: "None"}};
    } else {
      const _owner_0 = _t_0["value"];
      return $$$$047$$$047src$047ecs$047column$058viewed$1264$(($schema$058project_locked$(_owner_0)), _column_1, _id_0);
    }
  }
}

function $$$$047$$$047src$047ecs$047column$058seek_view$1264$($0, $1, $2, $3, $4, $5, $6, $7) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _remaining_0 = $5;
      const _past_0 = $6;
      const _phase_0 = $7;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "Tuple", "fst": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "snd": {$: "None"}};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _stamps_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $6 = _past_0;
            $7 = {$: "../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return $$$$047$$$047src$047ecs$047column$058prepared_view_projected$1264$(_values_0, _stamps_0, _capacity_0, _target_0, _rest_1, _past_0, ($schema$058project_locked$(_owner_1)));
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "Tuple", "fst": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "snd": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _stamps_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _rest_1;
                $6 = {$: "../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $7 = {$: "../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_view_taken$1264$(_id_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "Tuple", "fst": ($$$$047$$$047src$047ecs$047column$058indexed_wrap$1264$(_values_0, _metadata_0)), "snd": {$: "None"}};
  } else {
    const _owner_0 = _t_0["value"];
    return $$$$047$$$047src$047ecs$047column$058indexed_view_projected$1264$(_id_0, _values_0, _metadata_0, ($schema$058project_locked$(_owner_0)));
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepared_view_projected$1264$(_values_0, _metadata_0, _capacity_0, _current_0, _remaining_0, _past_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "Some", "value": _owner_0}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047$$$047src$047ecs$047column$058indexed_seek_view$1264$($0, $1, $2, $3, $4, $5, $6, $7) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _remaining_0 = $5;
      const _past_0 = $6;
      const _phase_0 = $7;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "Tuple", "fst": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "snd": {$: "None"}};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _metadata_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $6 = _past_0;
            $7 = {$: "../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return $$$$047$$$047src$047ecs$047column$058indexed_prepared_view_projected$1264$(_values_0, _metadata_0, _capacity_0, _target_0, _rest_1, _past_0, ($schema$058project_locked$(_owner_1)));
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "Tuple", "fst": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "snd": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _metadata_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _rest_1;
                $6 = {$: "../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $7 = {$: "../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047column$058restored$1263$(_result_0, _projection_0, _stamps_0) {
  const _values_0 = _result_0["fst"];
  return {$: "Tuple", "fst": {$: "../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047$$$047src$047ecs$047column$058viewed$1263$(_projected_0, _column_0, _id_0) {
  const _owner_0 = _projected_0["fst"];
  const _result_0 = _projected_0["snd"];
  if (_column_0.$ === "../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "Some", "value": _owner_0};
    return $$$$047$$$047src$047ecs$047column$058restored$1263$(array_rmw(_values_0, _x_0, () => _x_1), _result_0, _stamps_0);
  } else if (_column_0.$ === "../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058viewed_return$1263$(_result_0, ($$$$047$$$047src$047ecs$047column$058swap$1263$({$: "../../src/ecs/column.Prepared", "state": _carrier_0}, _id_0, {$: "Some", "value": _owner_0})));
  } else if (_column_0.$ === "../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058indexed_projected_state$1263$(_id_0, {$: "Tuple", "fst": _owner_0, "snd": _result_0}, ($$$$047$$$047src$047ecs$047column$058indexed_unseal$1263$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058viewed_return$1263$(_result_0, ($$$$047$$$047src$047ecs$047column$058swap$1263$({$: "../../src/ecs/column.PreparedIndexed", "state": _carrier_2}, _id_0, {$: "Some", "value": _owner_0})));
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_view_projected$1263$(_id_0, _values_0, _metadata_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = {$: "Some", "value": _owner_0};
  return $$$$047$$$047src$047ecs$047column$058indexed_view_restored$1263$(_metadata_0, _projection_0, array_rmw(_values_0, _x_0, () => _x_1));
}

function $$$$047$$$047src$047ecs$047column$058viewed_return$1262$(_view_0, _result_0) {
  if (_result_0.$ === "../../src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    return {$: "Tuple", "fst": _column_0, "snd": {$: "Some", "value": _view_0}};
  } else {
    const _column_1 = _result_0["column"];
    return {$: "Tuple", "fst": _column_1, "snd": {$: "None"}};
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_projected_state$1262$(_id_0, _result_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047src$047ecs$047column$058indexed_view_projected$1262$(_id_0, _values_0, _metadata_0, _result_0);
}

function $$$$047$$$047src$047ecs$047column$058indexed_view_restored$1262$(_metadata_0, _projection_0, _result_0) {
  const _values_0 = _result_0["fst"];
  return {$: "Tuple", "fst": ($$$$047$$$047src$047ecs$047column$058indexed_wrap$1262$(_values_0, _metadata_0)), "snd": {$: "Some", "value": _projection_0}};
}

function $schema$058array_view_structural$(_array_0) {
  if (_array_0.length === 1) {
    const _value_0 = _array_0[0];
    return {$: "Tuple", "fst": [_value_0], "snd": {$: "Con", "head": _value_0, "tail": {$: "Nil"}}};
  } else {
    const _left_0 = _array_0.slice(0, _array_0.length >> 1);
    const _right_0 = _array_0.slice(_array_0.length >> 1);
    return $schema$058array_join$(($schema$058array_view_structural$(_left_0)), ($schema$058array_view_structural$(_right_0)));
  }
}

function $schema$058array_view_read_checked$(_array_0, _index_0, _valid_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": _array_0, "snd": {$: "None"}};
  } else {
    return $schema$058array_view_read_result$({$: "Tuple", fst: _array_0, snd: _array_0[_index_0 % _array_0.length]});
  }
}

function $$$$047$$$047src$047ecs$047owned$045family$058get_matching$1263$(_rest_0, _observed_0) {
  const _cell_0 = _observed_0["fst"];
  const _same_0 = _observed_0["snd"];
  return $$$$047$$$047src$047ecs$047owned$045family$058get_ready$1263$(_rest_0, _cell_0, _same_0);
}

function $$$$047$$$047src$047ecs$047owned$045family$058cell_matches$1260$(_cell_0, _id_0) {
  if (_cell_0.$ === "../../src/ecs/restored-row.Taken") {
    const _captured_0 = _cell_0["id"];
    const _owner_0 = _cell_0["owner"];
    const _stamp_0 = _cell_0["stamp"];
    const _dirty_0 = _cell_0["dirty"];
    const _cold_0 = _cell_0["restore"];
    return {$: "Tuple", "fst": {$: "../../src/ecs/restored-row.Taken", "id": _captured_0, "owner": _owner_0, "stamp": _stamp_0, "dirty": _dirty_0, "restore": _cold_0}, "snd": (_captured_0 === _id_0)};
  } else {
    return {$: "Tuple", "fst": _cell_0, "snd": false};
  }
}

function $$$$047$$$047src$047ecs$047owned$045family$058checked_live$(_namespace_0, _nextId_0, _handle_0, _clock_0, _error_0, _cursor_0, _observed_0) {
  const _live_0 = _observed_0["fst"];
  const _valid_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../src/ecs/owned-family.Header", "namespace": _namespace_0, "nextId": _nextId_0, "live": _live_0, "handle": _handle_0, "clock": _clock_0, "error": _error_0, "cursor": _cursor_0}, "snd": _valid_0};
}

function $$$$047$$$047src$047ecs$047owned$045family$058reject_header$(_reason_0, _header_0) {
  const _namespace_0 = _header_0["namespace"];
  const _nextId_0 = _header_0["nextId"];
  const _live_0 = _header_0["live"];
  const _handle_0 = _header_0["handle"];
  const _clock_0 = _header_0["clock"];
  const _error_0 = _header_0["error"];
  const _cursor_0 = _header_0["cursor"];
  return {$: "../../src/ecs/owned-family.Header", "namespace": _namespace_0, "nextId": _nextId_0, "live": _live_0, "handle": _handle_0, "clock": _clock_0, "error": ($$$$047$$$047src$047ecs$047compose$058first_error$(_error_0, _reason_0)), "cursor": _cursor_0};
}

function $$$$047$$$047src$047ecs$047owned$045family$058write_matching$1263$(_rest_0, _meta_0, _incoming_0, _observed_0) {
  const _cell_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return $owned$045rows$058bridge_duplicate_stock_write$(($owned$045rows$058put_duplicate_stock$(($owned$045rows$058put_header_duplicate_stock$(_rest_0, _meta_0)), _cell_0)), _incoming_0);
  } else {
    return $$$$047$$$047src$047ecs$047owned$045family$058write_clocked$1263$(_rest_0, _cell_0, _incoming_0, ($$$$047$$$047src$047ecs$047owned$045family$058clocked$(_meta_0)));
  }
}

function $$$$047$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, _stamp_0) {
  const _added_0 = _metadata_0["added"];
  const _changed_0 = _metadata_0["changed"];
  const _capacity_0 = _metadata_0["capacity"];
  const _depth_0 = _metadata_0["depth"];
  const _exceptional_0 = _metadata_0["exceptional"];
  return $$$$047$$$047src$047ecs$047indexed$045lifecycle$058set_checked$(_id_0, _stamp_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, ($$$$047$$$047src$047ecs$047indexed$045lifecycle$058normal$(_id_0)));
}

function $gameplay$058work_recipe_read$1261$(_stock_0, _observed_0) {
  const _ctx_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "../../src/ecs/component.Found") {
    const _recipe_0 = _t_0["value"];
    return $gameplay$058work_write$1261$(_stock_0, _recipe_0, _ctx_0);
  } else {
    return {$: "Tuple", "fst": _ctx_0, "snd": {$: "Tuple", "fst": {$: "../../src/ecs/transaction.Failure", "error": {$: "gameplay.MissingFixture"}}, "snd": {$: "Unit"}}};
  }
}

function $$$$047$$$047src$047ecs$047indexed$045lifecycle$058write_ready$(_id_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, _stamp_0) {
  const _first_0 = _stamp_0["added"];
  const _last_0 = _stamp_0["changed"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = ((_id_0 - 1) >>> 0);
  return {$: "../../src/ecs/indexed-lifecycle.Metadata", "added": (_added_0[_x_0 % _added_0.length] = _first_0, _added_0), "changed": (_changed_0[_x_1 % _changed_0.length] = _last_0, _changed_0), "capacity": _capacity_0, "depth": _depth_0, "exceptional": _exceptional_0};
}

function $$$$047$$$047src$047ecs$047column$058mark$1264$(_column_0, _id_0, _incoming_0, _wasPresent_0, _tick_0) {
  if (_column_0.$ === "../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../src/ecs/column.Column", "values": _values_0, "stamps": ($$$$047$$$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, ($$$$047$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, ($$$$047$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0)), _tick_0))))};
  } else if (_column_0.$ === "../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058mark_state$1264$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047$$$047src$047ecs$047column$058unseal$1264$(_carrier_0)));
  } else if (_column_0.$ === "../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058indexed_mark_state$1264$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047$$$047src$047ecs$047column$058indexed_unseal$1264$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058indexed_prepared_mark_state$1264$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1264$(_carrier_2)));
  }
}

function $$$$047$$$047src$047ecs$047column$058ensure_sized$1264$(_target_0, _stamps_0, _sized_0) {
  const _values_0 = _sized_0["fst"];
  const _size_0 = _sized_0["snd"];
  return $$$$047$$$047src$047ecs$047column$058grow$1264$(17, _values_0, _stamps_0, _size_0, ($U32$log2$(_size_0)), _target_0, (_target_0 <= _size_0));
}

function $$$$047$$$047src$047ecs$047column$058ensure_state$1264$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047src$047ecs$047column$058ensure_prepared$1264$(_target_0, {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, (_target_0 <= _capacity_0));
}

function $$$$047$$$047src$047ecs$047column$058indexed_ensure_state$1264$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047src$047ecs$047column$058indexed_ensure_sized$1264$(_target_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepared_ensure_state$1264$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047src$047ecs$047column$058ensure_prepared$1264$(_target_0, {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, (_target_0 <= _capacity_0));
}

function $$$$047$$$047src$047ecs$047column$058mark$1263$(_column_0, _id_0, _incoming_0, _wasPresent_0, _tick_0) {
  if (_column_0.$ === "../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../src/ecs/column.Column", "values": _values_0, "stamps": ($$$$047$$$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, ($$$$047$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, ($$$$047$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0)), _tick_0))))};
  } else if (_column_0.$ === "../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058mark_state$1263$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047$$$047src$047ecs$047column$058unseal$1263$(_carrier_0)));
  } else if (_column_0.$ === "../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058indexed_mark_state$1263$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047$$$047src$047ecs$047column$058indexed_unseal$1263$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058indexed_prepared_mark_state$1263$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1263$(_carrier_2)));
  }
}

function $$$$047$$$047src$047ecs$047column$058ensure_sized$1263$(_target_0, _stamps_0, _sized_0) {
  const _values_0 = _sized_0["fst"];
  const _size_0 = _sized_0["snd"];
  return $$$$047$$$047src$047ecs$047column$058grow$1263$(17, _values_0, _stamps_0, _size_0, ($U32$log2$(_size_0)), _target_0, (_target_0 <= _size_0));
}

function $$$$047$$$047src$047ecs$047column$058ensure_state$1263$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047src$047ecs$047column$058ensure_prepared$1263$(_target_0, {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, (_target_0 <= _capacity_0));
}

function $$$$047$$$047src$047ecs$047column$058indexed_ensure_state$1263$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047src$047ecs$047column$058indexed_ensure_sized$1263$(_target_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepared_ensure_state$1263$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047src$047ecs$047column$058ensure_prepared$1263$(_target_0, {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, (_target_0 <= _capacity_0));
}

function $$$$047$$$047src$047ecs$047capabilities$058set$1269$(_ctx_0, _value_0) {
  return run_tail(($$$$047$$$047src$047ecs$047capabilities$058write_field$1263$(($gameplay$058retry_stock$1261$({$: "gameplay.RetryCaps", "stock": ($owned$045rows$058write_work_stock$()), "recipe": ($owned$045rows$058write_work_recipe$()), "queue": ($owned$045rows$058write_work_queue$()), "insert": {$: "../../src/ecs/capabilities.Send", "send": run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $declarations$058queue_send$(_x_0, _x_1);
});
})}}))))(_ctx_0), _value_0);
}

function $gameplay$058retry_value$(_fail_0) {
  if (_fail_0) {
    return 900;
  } else {
    return 100;
  }
}

function $$$$047$$$047src$047ecs$047capabilities$058set$12610$(_ctx_0, _value_0) {
  return run_tail(($$$$047$$$047src$047ecs$047capabilities$058write_field$1265$(($gameplay$058retry_recipe$1261$({$: "gameplay.RetryCaps", "stock": ($owned$045rows$058write_work_stock$()), "recipe": ($owned$045rows$058write_work_recipe$()), "queue": ($owned$045rows$058write_work_queue$()), "insert": {$: "../../src/ecs/capabilities.Send", "send": run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $declarations$058queue_send$(_x_0, _x_1);
});
})}}))))(_ctx_0), _value_0);
}

function $$$$047$$$047src$047ecs$047capabilities$058set$12611$(_ctx_0, _value_0) {
  return run_tail(($$$$047$$$047src$047ecs$047capabilities$058write_field$1266$(($gameplay$058retry_queue$1261$({$: "gameplay.RetryCaps", "stock": ($owned$045rows$058write_work_stock$()), "recipe": ($owned$045rows$058write_work_recipe$()), "queue": ($owned$045rows$058write_work_queue$()), "insert": {$: "../../src/ecs/capabilities.Send", "send": run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $declarations$058queue_send$(_x_0, _x_1);
});
})}}))))(_ctx_0), _value_0);
}

function $$$$047$$$047src$047ecs$047capabilities$058send$1261$(_ctx_0, _value_0) {
  return run_tail(($$$$047$$$047src$047ecs$047capabilities$058send_field$1261$(($gameplay$058retry_insert$1261$({$: "gameplay.RetryCaps", "stock": ($owned$045rows$058write_work_stock$()), "recipe": ($owned$045rows$058write_work_recipe$()), "queue": ($owned$045rows$058write_work_queue$()), "insert": {$: "../../src/ecs/capabilities.Send", "send": run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $declarations$058queue_send$(_x_0, _x_1);
});
})}}))))(_ctx_0), _value_0);
}

function $gameplay$058command_value$(_fail_0) {
  if (_fail_0) {
    return 999;
  } else {
    return 31;
  }
}

function $gameplay$058retry_outcome$(_fail_0) {
  if (_fail_0) {
    return {$: "../../src/ecs/transaction.Failure", "error": {$: "gameplay.Rejected"}};
  } else {
    return {$: "../../src/ecs/transaction.Success"};
  }
}

function $reference$045declarations$058match_queue$1260$(_frame_0) {
  return $$$$047$$$047src$047ecs$047compose$058family_match$1265$(_frame_0);
}

function $$$$047$$$047src$047ecs$047world$058with_store_finish$1267$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047src$047ecs$047component$058swap_store$1262$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047src$047ecs$047component$058swap_join$1262$(_rest_0, _id_0, _incomingPresent_0, _tick_0, ($$$$047$$$047src$047ecs$047column$058swap$1262$(($$$$047$$$047src$047ecs$047column$058ensure$1262$(_column_0, _id_0)), _id_0, _incoming_0)));
}

function $$$$047$$$047src$047ecs$047owned$045compose$058prepend$1262$(_value_0, _observed_0) {
  const _tx_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  const _outcome_0 = _t_0["fst"];
  const _values_0 = _t_0["snd"];
  return {$: "Tuple", "fst": _tx_0, "snd": {$: "Tuple", "fst": _outcome_0, "snd": {$: "Con", "head": _value_0, "tail": _values_0}}};
}

function $owned$045rows$058leave_advanced_cold$($0, $1, $2, $3) {
  for (;;) {
    {
      const _header_0 = $0;
      const _stock_0 = $1;
      const _queue_0 = $2;
      const _cold_0 = $3;
      if (_cold_0.$ === "owned-rows.AdvancedCold") {
        const _t_0 = _cold_0["state"];
        const _highWater_0 = _t_0["highWater"];
        const _capacity_0 = _t_0["capacity"];
        const _depth_0 = _t_0["depth"];
        const _recipe_0 = _t_0["recipe"];
        const _enabled_0 = _t_0["enabled"];
        const _locked_0 = _t_0["locked"];
        const _resource_0 = _t_0["resource"];
        const _events_0 = _t_0["events"];
        const _pending_0 = _t_0["pending"];
        const _registrations_0 = _t_0["registrations"];
        const _nextSystemId_0 = _t_0["nextSystemId"];
        const _undo_0 = _t_0["undo"];
        const _commands_0 = _t_0["commands"];
        const _txEvents_0 = _t_0["txEvents"];
        return $owned$045rows$058leave_advanced_header$(_stock_0, _queue_0, _highWater_0, _capacity_0, _depth_0, _recipe_0, _enabled_0, _locked_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _undo_0, _commands_0, _txEvents_0, _header_0);
      } else {
        const _inner_0 = _cold_0["inner"];
        $0 = _header_0;
        $1 = _stock_0;
        $2 = _queue_0;
        $3 = _inner_0;
        continue;
      }
    }
  }
}

function $reference$045declarations$058advanced_stock_read$1261$(_observed_0) {
  const _ctx_0 = _observed_0["fst"];
  return $reference$045declarations$058advanced_queue_read$1261$(run_loop($$$$047$$$047src$047ecs$047capabilities$058read$1268$(_ctx_0)));
}

function $$$$047$$$047src$047ecs$047capabilities$058read$1269$(_ctx_0) {
  return run_tail(($$$$047$$$047src$047ecs$047capabilities$058read_field$1267$(($reference$045declarations$058advanced_stock$1261$({$: "reference-declarations.AdvancedCaps", "stock": ($owned$045rows$058read_advanced_stock$()), "queue": ($owned$045rows$058read_advanced_queue$()), "id": ($owned$045rows$058id_read_advanced$())})))), _ctx_0);
}

function $reference$045declarations$058advanced_lifecycle$(_frame_0) {
  return $$$$047$$$047src$047ecs$047compose$058both$1265$(_frame_0);
}

function $$$$047$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, _stamp_0, _tick_0) {
  if (!_incoming_0) {
    return {$: "../../src/ecs/lifecycle.Stamp", "added": 0, "changed": 0};
  } else {
    return $$$$047$$$047src$047ecs$047lifecycle$058written$(_wasPresent_0, _stamp_0, _tick_0);
  }
}

function $$$$047$$$047src$047ecs$047column$058mark_state$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": ($$$$047$$$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, ($$$$047$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, ($$$$047$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0)), _tick_0)))), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047src$047ecs$047column$058indexed_mark_state$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047src$047ecs$047column$058indexed_mark_got$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, ($$$$047$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepared_mark_state$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047src$047ecs$047column$058indexed_prepared_mark_got$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($$$$047$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047src$047ecs$047column$058grow$1260$($0, $1, $2, $3, $4, $5, $6) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _size_0 = $3;
      const _depth_0 = $4;
      const _target_0 = $5;
      const _enough_0 = $6;
      if (_fuel_0 === 0) {
        if (_enough_0) {
          return {$: "../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        } else {
          return {$: "../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        }
      } else {
        const _rest_0 = (_fuel_0 - 1);
        if (_enough_0) {
          return {$: "../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        } else {
          const _next_0 = ((_size_0 << 1) >>> 0);
          $0 = _rest_0;
          $1 = array_node(_values_0, ($$$$047$$$047src$047ecs$047column$058absent$1260$(_depth_0)));
          $2 = _stamps_0;
          $3 = _next_0;
          $4 = nat_chk(_depth_0 + 1);
          $5 = _target_0;
          $6 = (_target_0 <= _next_0);
          continue;
        }
      }
    }
  }
}

function $U32$log2$(_n_0) {
  return $U32$log2$go$(5, _n_0, 0);
}

function $$$$047$$$047src$047ecs$047column$058ensure_prepared$1260$(_target_0, _column_0, _fits_0) {
  if (_fits_0) {
    return _column_0;
  } else {
    return $$$$047$$$047src$047ecs$047column$058ensure_recovered$1260$(_target_0, ($$$$047$$$047src$047ecs$047column$058recover$1260$(_column_0)));
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_ensure_sized$1260$(_target_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047src$047ecs$047column$058indexed_grow$1260$(17, _values_0, _metadata_0, _size_0, ($U32$log2$(_size_0)), _target_0, (_target_0 <= _size_0));
}

function $$$$047$$$047src$047ecs$047column$058mark_state$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": ($$$$047$$$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, ($$$$047$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, ($$$$047$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0)), _tick_0)))), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047src$047ecs$047column$058indexed_mark_state$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047src$047ecs$047column$058indexed_mark_got$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, ($$$$047$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepared_mark_state$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047src$047ecs$047column$058indexed_prepared_mark_got$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($$$$047$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047src$047ecs$047column$058grow$1261$($0, $1, $2, $3, $4, $5, $6) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _size_0 = $3;
      const _depth_0 = $4;
      const _target_0 = $5;
      const _enough_0 = $6;
      if (_fuel_0 === 0) {
        if (_enough_0) {
          return {$: "../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        } else {
          return {$: "../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        }
      } else {
        const _rest_0 = (_fuel_0 - 1);
        if (_enough_0) {
          return {$: "../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        } else {
          const _next_0 = ((_size_0 << 1) >>> 0);
          $0 = _rest_0;
          $1 = array_node(_values_0, ($$$$047$$$047src$047ecs$047column$058absent$1261$(_depth_0)));
          $2 = _stamps_0;
          $3 = _next_0;
          $4 = nat_chk(_depth_0 + 1);
          $5 = _target_0;
          $6 = (_target_0 <= _next_0);
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047column$058ensure_prepared$1261$(_target_0, _column_0, _fits_0) {
  if (_fits_0) {
    return _column_0;
  } else {
    return $$$$047$$$047src$047ecs$047column$058ensure_recovered$1261$(_target_0, ($$$$047$$$047src$047ecs$047column$058recover$1261$(_column_0)));
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_ensure_sized$1261$(_target_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047src$047ecs$047column$058indexed_grow$1261$(17, _values_0, _metadata_0, _size_0, ($U32$log2$(_size_0)), _target_0, (_target_0 <= _size_0));
}

function $$$$047$$$047src$047ecs$047owned$045family$058get_matching$1260$(_rest_0, _observed_0) {
  const _cell_0 = _observed_0["fst"];
  const _same_0 = _observed_0["snd"];
  return $$$$047$$$047src$047ecs$047owned$045family$058get_ready$1260$(_rest_0, _cell_0, _same_0);
}

function $$$$047$$$047src$047ecs$047owned$045family$058write_matching$1260$(_rest_0, _meta_0, _incoming_0, _observed_0) {
  const _cell_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return $owned$045rows$058bridge_work_stock_write$(($owned$045rows$058put_work_stock$(($owned$045rows$058put_header_work_stock$(_rest_0, _meta_0)), _cell_0)), _incoming_0);
  } else {
    return $$$$047$$$047src$047ecs$047owned$045family$058write_clocked$1260$(_rest_0, _cell_0, _incoming_0, ($$$$047$$$047src$047ecs$047owned$045family$058clocked$(_meta_0)));
  }
}

function $$$$047$$$047src$047ecs$047owned$045family$058get_matching$1261$(_rest_0, _observed_0) {
  const _cell_0 = _observed_0["fst"];
  const _same_0 = _observed_0["snd"];
  return $$$$047$$$047src$047ecs$047owned$045family$058get_ready$1261$(_rest_0, _cell_0, _same_0);
}

function $$$$047$$$047src$047ecs$047owned$045family$058cell_matches$1261$(_cell_0, _id_0) {
  if (_cell_0.$ === "../../src/ecs/restored-row.Taken") {
    const _captured_0 = _cell_0["id"];
    const _owner_0 = _cell_0["owner"];
    const _stamp_0 = _cell_0["stamp"];
    const _dirty_0 = _cell_0["dirty"];
    const _cold_0 = _cell_0["restore"];
    return {$: "Tuple", "fst": {$: "../../src/ecs/restored-row.Taken", "id": _captured_0, "owner": _owner_0, "stamp": _stamp_0, "dirty": _dirty_0, "restore": _cold_0}, "snd": (_captured_0 === _id_0)};
  } else {
    return {$: "Tuple", "fst": _cell_0, "snd": false};
  }
}

function $$$$047$$$047src$047ecs$047owned$045family$058get_matching$1262$(_rest_0, _observed_0) {
  const _cell_0 = _observed_0["fst"];
  const _same_0 = _observed_0["snd"];
  return $$$$047$$$047src$047ecs$047owned$045family$058get_ready$1262$(_rest_0, _cell_0, _same_0);
}

function $$$$047$$$047src$047ecs$047owned$045family$058cell_matches$1262$(_cell_0, _id_0) {
  if (_cell_0.$ === "../../src/ecs/restored-row.Taken") {
    const _captured_0 = _cell_0["id"];
    const _owner_0 = _cell_0["owner"];
    const _stamp_0 = _cell_0["stamp"];
    const _dirty_0 = _cell_0["dirty"];
    const _cold_0 = _cell_0["restore"];
    return {$: "Tuple", "fst": {$: "../../src/ecs/restored-row.Taken", "id": _captured_0, "owner": _owner_0, "stamp": _stamp_0, "dirty": _dirty_0, "restore": _cold_0}, "snd": (_captured_0 === _id_0)};
  } else {
    return {$: "Tuple", "fst": _cell_0, "snd": false};
  }
}

function $$$$047$$$047src$047ecs$047column$058restored$1264$(_result_0, _projection_0, _stamps_0) {
  const _values_0 = _result_0["fst"];
  return {$: "Tuple", "fst": {$: "../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047$$$047src$047ecs$047column$058viewed$1264$(_projected_0, _column_0, _id_0) {
  const _owner_0 = _projected_0["fst"];
  const _result_0 = _projected_0["snd"];
  if (_column_0.$ === "../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "Some", "value": _owner_0};
    return $$$$047$$$047src$047ecs$047column$058restored$1264$(array_rmw(_values_0, _x_0, () => _x_1), _result_0, _stamps_0);
  } else if (_column_0.$ === "../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058viewed_return$1264$(_result_0, ($$$$047$$$047src$047ecs$047column$058swap$1264$({$: "../../src/ecs/column.Prepared", "state": _carrier_0}, _id_0, {$: "Some", "value": _owner_0})));
  } else if (_column_0.$ === "../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058indexed_projected_state$1264$(_id_0, {$: "Tuple", "fst": _owner_0, "snd": _result_0}, ($$$$047$$$047src$047ecs$047column$058indexed_unseal$1264$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058viewed_return$1264$(_result_0, ($$$$047$$$047src$047ecs$047column$058swap$1264$({$: "../../src/ecs/column.PreparedIndexed", "state": _carrier_2}, _id_0, {$: "Some", "value": _owner_0})));
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_view_projected$1264$(_id_0, _values_0, _metadata_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = {$: "Some", "value": _owner_0};
  return $$$$047$$$047src$047ecs$047column$058indexed_view_restored$1264$(_metadata_0, _projection_0, array_rmw(_values_0, _x_0, () => _x_1));
}

function $$$$047$$$047src$047ecs$047column$058viewed_return$1263$(_view_0, _result_0) {
  if (_result_0.$ === "../../src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    return {$: "Tuple", "fst": _column_0, "snd": {$: "Some", "value": _view_0}};
  } else {
    const _column_1 = _result_0["column"];
    return {$: "Tuple", "fst": _column_1, "snd": {$: "None"}};
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_projected_state$1263$(_id_0, _result_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047src$047ecs$047column$058indexed_view_projected$1263$(_id_0, _values_0, _metadata_0, _result_0);
}

function $$$$047$$$047src$047ecs$047column$058indexed_view_restored$1263$(_metadata_0, _projection_0, _result_0) {
  const _values_0 = _result_0["fst"];
  return {$: "Tuple", "fst": ($$$$047$$$047src$047ecs$047column$058indexed_wrap$1263$(_values_0, _metadata_0)), "snd": {$: "Some", "value": _projection_0}};
}

function $schema$058array_join$(_left_view_0, _right_view_0) {
  const _left_0 = _left_view_0["fst"];
  const _xs_0 = _left_view_0["snd"];
  const _right_0 = _right_view_0["fst"];
  const _ys_0 = _right_view_0["snd"];
  return {$: "Tuple", "fst": array_node(_left_0, _right_0), "snd": ($List$append$(_xs_0, _ys_0))};
}

function $schema$058array_view_read_result$(_observed_0) {
  const _array_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _array_0, "snd": {$: "Some", "value": _value_0}};
}

function $$$$047$$$047src$047ecs$047owned$045family$058get_ready$1263$(_rest_0, _cell_0, _same_0) {
  if (!_same_0) {
    return $owned$045rows$058bridge_duplicate_stock_get$(($owned$045rows$058put_duplicate_stock$(_rest_0, _cell_0)));
  } else {
    return $$$$047$$$047src$047ecs$047owned$045family$058projected$1263$(_rest_0, ($$$$047$$$047src$047ecs$047restored$045row$058project$1260$(_cell_0)));
  }
}

function $$$$047$$$047src$047ecs$047compose$058first_error$(_previous_0, _error_0) {
  if (_previous_0.$ === "None") {
    return {$: "Some", "value": _error_0};
  } else {
    const _previous_1 = _previous_0["value"];
    return {$: "Some", "value": _previous_1};
  }
}

function $owned$045rows$058bridge_duplicate_stock_write$(_row_0, _incoming_0) {
  return $owned$045rows$058bridge_duplicate_stock_write_frame$(_incoming_0, ($owned$045rows$058leave_duplicate$(_row_0)));
}

function $$$$047$$$047src$047ecs$047owned$045family$058write_clocked$1263$(_rest_0, _cell_0, _incoming_0, _observed_0) {
  const _meta_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "None") {
    return $$$$047$$$047src$047ecs$047owned$045family$058rejected$1263$(_rest_0, _cell_0, _incoming_0, {$: "../../src/ecs/world.CapacityExceeded"}, _meta_0);
  } else {
    const _tick_0 = _t_0["value"];
    return $$$$047$$$047src$047ecs$047owned$045family$058replaced$1263$(($owned$045rows$058put_header_duplicate_stock$(_rest_0, _meta_0)), ($$$$047$$$047src$047ecs$047restored$045row$058replace$1260$(_cell_0, _incoming_0, _tick_0)));
  }
}

function $$$$047$$$047src$047ecs$047owned$045family$058clocked$(_header_0) {
  const _namespace_0 = _header_0["namespace"];
  const _nextId_0 = _header_0["nextId"];
  const _live_0 = _header_0["live"];
  const _handle_0 = _header_0["handle"];
  const _clock_0 = _header_0["clock"];
  const _error_0 = _header_0["error"];
  const _cursor_0 = _header_0["cursor"];
  return $$$$047$$$047src$047ecs$047owned$045family$058clock_checked$((_clock_0 < 4294967295), _namespace_0, _nextId_0, _live_0, _handle_0, _clock_0, _error_0, _cursor_0);
}

function $$$$047$$$047src$047ecs$047indexed$045lifecycle$058set_checked$(_id_0, _stamp_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, _isnormal_0) {
  if (!_isnormal_0) {
    return {$: "../../src/ecs/indexed-lifecycle.Metadata", "added": _added_0, "changed": _changed_0, "capacity": _capacity_0, "depth": _depth_0, "exceptional": ($$$$047$$$047src$047ecs$047lifecycle$058set$(_exceptional_0, _id_0, _stamp_0))};
  } else {
    return $$$$047$$$047src$047ecs$047indexed$045lifecycle$058write_grow$(17, _id_0, _stamp_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, (_id_0 <= _capacity_0));
  }
}

function $gameplay$058work_write$1261$(_stock_0, _recipe_0, _ctx_0) {
  const _value_0 = _stock_0["value"];
  const _owned_0 = _stock_0["owned"];
  return $gameplay$058work_recipe_view$1261$(_value_0, _owned_0, _recipe_0, _ctx_0);
}

function $$$$047$$$047src$047ecs$047column$058mark_state$1264$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": ($$$$047$$$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, ($$$$047$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, ($$$$047$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0)), _tick_0)))), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047src$047ecs$047column$058indexed_mark_state$1264$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047src$047ecs$047column$058indexed_mark_got$1264$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, ($$$$047$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepared_mark_state$1264$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047src$047ecs$047column$058indexed_prepared_mark_got$1264$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($$$$047$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047src$047ecs$047column$058grow$1264$($0, $1, $2, $3, $4, $5, $6) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _size_0 = $3;
      const _depth_0 = $4;
      const _target_0 = $5;
      const _enough_0 = $6;
      if (_fuel_0 === 0) {
        if (_enough_0) {
          return {$: "../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        } else {
          return {$: "../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        }
      } else {
        const _rest_0 = (_fuel_0 - 1);
        if (_enough_0) {
          return {$: "../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        } else {
          const _next_0 = ((_size_0 << 1) >>> 0);
          $0 = _rest_0;
          $1 = array_node(_values_0, ($$$$047$$$047src$047ecs$047column$058absent$1264$(_depth_0)));
          $2 = _stamps_0;
          $3 = _next_0;
          $4 = nat_chk(_depth_0 + 1);
          $5 = _target_0;
          $6 = (_target_0 <= _next_0);
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047column$058ensure_prepared$1264$(_target_0, _column_0, _fits_0) {
  if (_fits_0) {
    return _column_0;
  } else {
    return $$$$047$$$047src$047ecs$047column$058ensure_recovered$1264$(_target_0, ($$$$047$$$047src$047ecs$047column$058recover$1264$(_column_0)));
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_ensure_sized$1264$(_target_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047src$047ecs$047column$058indexed_grow$1264$(17, _values_0, _metadata_0, _size_0, ($U32$log2$(_size_0)), _target_0, (_target_0 <= _size_0));
}

function $$$$047$$$047src$047ecs$047column$058mark_state$1263$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": ($$$$047$$$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, ($$$$047$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, ($$$$047$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0)), _tick_0)))), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047src$047ecs$047column$058indexed_mark_state$1263$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047src$047ecs$047column$058indexed_mark_got$1263$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, ($$$$047$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepared_mark_state$1263$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047src$047ecs$047column$058indexed_prepared_mark_got$1263$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($$$$047$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047src$047ecs$047column$058grow$1263$($0, $1, $2, $3, $4, $5, $6) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _size_0 = $3;
      const _depth_0 = $4;
      const _target_0 = $5;
      const _enough_0 = $6;
      if (_fuel_0 === 0) {
        if (_enough_0) {
          return {$: "../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        } else {
          return {$: "../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        }
      } else {
        const _rest_0 = (_fuel_0 - 1);
        if (_enough_0) {
          return {$: "../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        } else {
          const _next_0 = ((_size_0 << 1) >>> 0);
          $0 = _rest_0;
          $1 = array_node(_values_0, ($$$$047$$$047src$047ecs$047column$058absent$1263$(_depth_0)));
          $2 = _stamps_0;
          $3 = _next_0;
          $4 = nat_chk(_depth_0 + 1);
          $5 = _target_0;
          $6 = (_target_0 <= _next_0);
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047column$058ensure_prepared$1263$(_target_0, _column_0, _fits_0) {
  if (_fits_0) {
    return _column_0;
  } else {
    return $$$$047$$$047src$047ecs$047column$058ensure_recovered$1263$(_target_0, ($$$$047$$$047src$047ecs$047column$058recover$1263$(_column_0)));
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_ensure_sized$1263$(_target_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047src$047ecs$047column$058indexed_grow$1263$(17, _values_0, _metadata_0, _size_0, ($U32$log2$(_size_0)), _target_0, (_target_0 <= _size_0));
}

function $$$$047$$$047src$047ecs$047capabilities$058write_field$1263$(_cap_0) {
  const _set_0 = _cap_0["set"];
  return _set_0;
}

function $gameplay$058retry_stock$1261$(_caps_0) {
  const _stock_0 = _caps_0["stock"];
  return _stock_0;
}

function $owned$045rows$058write_work_recipe$() {
  return {$: "../../src/ecs/capabilities.Write", "get": run_clo((_x_0) => {
  return $owned$045rows$058get_work_recipe$(_x_0);
}), "set": run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $owned$045rows$058set_work_recipe$(_x_1, _x_2);
});
})};
}

function $owned$045rows$058write_work_queue$() {
  return {$: "../../src/ecs/capabilities.Write", "get": run_clo((_x_0) => {
  return $owned$045rows$058get_work_queue$(_x_0);
}), "set": run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $owned$045rows$058set_work_queue$(_x_1, _x_2);
});
})};
}

function $declarations$058queue_send$(_row_0, _request_0) {
  return $owned$045rows$058enter_work$(($$$$047$$$047src$047ecs$047compose$058insert$1260$(($owned$045rows$058leave_work$(_row_0)), _request_0)));
}

function $$$$047$$$047src$047ecs$047capabilities$058write_field$1265$(_cap_0) {
  const _set_0 = _cap_0["set"];
  return _set_0;
}

function $gameplay$058retry_recipe$1261$(_caps_0) {
  const _recipe_0 = _caps_0["recipe"];
  return _recipe_0;
}

function $$$$047$$$047src$047ecs$047capabilities$058write_field$1266$(_cap_0) {
  const _set_0 = _cap_0["set"];
  return _set_0;
}

function $gameplay$058retry_queue$1261$(_caps_0) {
  const _queue_0 = _caps_0["queue"];
  return _queue_0;
}

function $$$$047$$$047src$047ecs$047capabilities$058send_field$1261$(_cap_0) {
  const _send_0 = _cap_0["send"];
  return _send_0;
}

function $gameplay$058retry_insert$1261$(_caps_0) {
  const _insert_0 = _caps_0["insert"];
  return _insert_0;
}

function $$$$047$$$047src$047ecs$047compose$058family_match$1265$(_frame_0) {
  return $$$$047$$$047src$047ecs$047compose$058selected_join$1264$({$: "../../src/ecs/compose.Required"}, ($$$$047$$$047src$047ecs$047compose$058get$1262$(_frame_0)));
}

function $$$$047$$$047src$047ecs$047component$058swap_join$1262$(_rest_0, _id_0, _incoming_0, _tick_0, _result_0) {
  if (_result_0.$ === "../../src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    const _previous_0 = _result_0["previous"];
    return $$$$047$$$047src$047ecs$047component$058mark_swapped$1262$(_rest_0, _column_0, _id_0, _incoming_0, _tick_0, ($$$$047$$$047src$047ecs$047component$058owner_present$1262$(_previous_0)));
  } else {
    const _column_1 = _result_0["column"];
    const _incoming_1 = _result_0["incoming"];
    return {$: "Tuple", "fst": ($schema$058put_queue$(_rest_0, _column_1)), "snd": {$: "../../src/ecs/component.SwapRejected", "incoming": _incoming_1}};
  }
}

function $$$$047$$$047src$047ecs$047column$058ensure$1262$(_column_0, _target_0) {
  return $$$$047$$$047src$047ecs$047column$058ensure_checked$1262$(_column_0, _target_0, ($Bool$and$((_target_0 > 0), (_target_0 <= 131072))));
}

function $owned$045rows$058leave_advanced_header$(_stock_0, _queue_0, _highWater_0, _capacity_0, _depth_0, _recipe_0, _enabled_0, _locked_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _undo_0, _commands_0, _txEvents_0, _header_0) {
  const _namespace_0 = _header_0["namespace"];
  const _nextId_0 = _header_0["nextId"];
  const _live_0 = _header_0["live"];
  const _handle_0 = _header_0["handle"];
  const _clock_0 = _header_0["clock"];
  const _error_0 = _header_0["error"];
  const _cursor_0 = _header_0["cursor"];
  return {$: "../../src/ecs/compose.Frame", "tx": {$: "../../src/ecs/transaction.Tx", "world": {$: "../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": {$: "schema.Store", "stock": _stock_0, "recipe": _recipe_0, "queue": _queue_0, "enabled": _enabled_0, "locked": _locked_0}, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "undo": _undo_0, "commands": _commands_0, "events": _txEvents_0}, "handle": _handle_0, "error": _error_0, "cursor": _cursor_0};
}

function $reference$045declarations$058advanced_queue_read$1261$(_observed_0) {
  const _ctx_0 = _observed_0["fst"];
  return $reference$045declarations$058advanced_id$1261$(run_loop($$$$047$$$047src$047ecs$047capabilities$058value_read$1268$(_ctx_0)));
}

function $$$$047$$$047src$047ecs$047capabilities$058read$1268$(_ctx_0) {
  return run_tail(($$$$047$$$047src$047ecs$047capabilities$058read_field$1266$(($reference$045declarations$058advanced_queue$1261$({$: "reference-declarations.AdvancedCaps", "stock": ($owned$045rows$058read_advanced_stock$()), "queue": ($owned$045rows$058read_advanced_queue$()), "id": ($owned$045rows$058id_read_advanced$())})))), _ctx_0);
}

function $$$$047$$$047src$047ecs$047capabilities$058read_field$1267$(_cap_0) {
  const _get_0 = _cap_0["get"];
  return _get_0;
}

function $reference$045declarations$058advanced_stock$1261$(_caps_0) {
  const _stock_0 = _caps_0["stock"];
  return _stock_0;
}

function $owned$045rows$058read_advanced_stock$() {
  return {$: "../../src/ecs/capabilities.Read", "get": run_clo((_x_0) => {
  return $owned$045rows$058get_advanced_stock$(_x_0);
})};
}

function $owned$045rows$058read_advanced_queue$() {
  return {$: "../../src/ecs/capabilities.Read", "get": run_clo((_x_0) => {
  return $owned$045rows$058get_advanced_queue$(_x_0);
})};
}

function $owned$045rows$058id_read_advanced$() {
  return {$: "../../src/ecs/capabilities.ValueRead", "get": run_clo((_x_0) => {
  return $owned$045rows$058id_advanced$(_x_0);
})};
}

function $$$$047$$$047src$047ecs$047compose$058both$1265$(_frame_0) {
  return $$$$047$$$047src$047ecs$047compose$058and_join$1265$(($reference$045declarations$058lifecycle_recipe$(_frame_0)));
}

function $$$$047$$$047src$047ecs$047lifecycle$058written$(_wasPresent_0, _stamp_0, _tick_0) {
  if (!_wasPresent_0) {
    return {$: "../../src/ecs/lifecycle.Stamp", "added": _tick_0, "changed": _tick_0};
  } else {
    const _added_0 = _stamp_0["added"];
    return {$: "../../src/ecs/lifecycle.Stamp", "added": _added_0, "changed": _tick_0};
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_mark_got$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return $$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, ($$$$047$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, ($$$$047$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, _stamp_0, _tick_0)))));
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepared_mark_got$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": ($$$$047$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, ($$$$047$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, _stamp_0, _tick_0)))), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047src$047ecs$047column$058absent$1260$(_depth_0) {
  if (_depth_0 === 0) {
    return [{$: "None"}];
  } else {
    const _rest_0 = (_depth_0 - 1);
    return array_node(($$$$047$$$047src$047ecs$047column$058absent$1260$(_rest_0)), ($$$$047$$$047src$047ecs$047column$058absent$1260$(_rest_0)));
  }
}

function $U32$log2$go$($0, $1, $2) {
  for (;;) {
    {
      const _k_0 = $0;
      const _n_0 = $1;
      const _b_0 = $2;
      if (_k_0 === 0) {
        return _b_0;
      } else {
        const _p_0 = (_k_0 - 1);
        const _x_0 = (_p_0 >= 32 ? 0 : (1 << _p_0) >>> 0);
        const _s_0 = _x_0;
        const _x_1 = (_s_0 >= 32 ? 0 : (_n_0 >>> _s_0) >>> 0);
        const _x_2 = ($Bool$to_u32$((_x_1 !== 0)));
        const _t_0 = nat_chk(_s_0 * _x_2);
        $0 = _p_0;
        $1 = (_t_0 >= 32 ? 0 : (_n_0 >>> _t_0) >>> 0);
        $2 = nat_chk(_b_0 + _t_0);
        continue;
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047column$058ensure_recovered$1260$(_target_0, _column_0) {
  if (_column_0.$ === "../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047src$047ecs$047column$058ensure_sized$1260$(_target_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../src/ecs/column.Indexed") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058indexed_ensure_state$1260$(_target_0, ($$$$047$$$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_0)));
  } else {
    return _column_0;
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_grow$1260$($0, $1, $2, $3, $4, $5, $6) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _size_0 = $3;
      const _depth_0 = $4;
      const _target_0 = $5;
      const _enough_0 = $6;
      if (_fuel_0 === 0) {
        if (_enough_0) {
          return $$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0);
        } else {
          return $$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0);
        }
      } else {
        const _rest_0 = (_fuel_0 - 1);
        if (_enough_0) {
          return $$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0);
        } else {
          const _next_0 = ((_size_0 << 1) >>> 0);
          $0 = _rest_0;
          $1 = array_node(_values_0, ($$$$047$$$047src$047ecs$047column$058absent$1260$(_depth_0)));
          $2 = _metadata_0;
          $3 = _next_0;
          $4 = nat_chk(_depth_0 + 1);
          $5 = _target_0;
          $6 = (_target_0 <= _next_0);
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_mark_got$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return $$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, ($$$$047$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, ($$$$047$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, _stamp_0, _tick_0)))));
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepared_mark_got$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": ($$$$047$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, ($$$$047$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, _stamp_0, _tick_0)))), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047src$047ecs$047column$058absent$1261$(_depth_0) {
  if (_depth_0 === 0) {
    return [{$: "None"}];
  } else {
    const _rest_0 = (_depth_0 - 1);
    return array_node(($$$$047$$$047src$047ecs$047column$058absent$1261$(_rest_0)), ($$$$047$$$047src$047ecs$047column$058absent$1261$(_rest_0)));
  }
}

function $$$$047$$$047src$047ecs$047column$058ensure_recovered$1261$(_target_0, _column_0) {
  if (_column_0.$ === "../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047src$047ecs$047column$058ensure_sized$1261$(_target_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../src/ecs/column.Indexed") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058indexed_ensure_state$1261$(_target_0, ($$$$047$$$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_0)));
  } else {
    return _column_0;
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_grow$1261$($0, $1, $2, $3, $4, $5, $6) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _size_0 = $3;
      const _depth_0 = $4;
      const _target_0 = $5;
      const _enough_0 = $6;
      if (_fuel_0 === 0) {
        if (_enough_0) {
          return $$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0);
        } else {
          return $$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0);
        }
      } else {
        const _rest_0 = (_fuel_0 - 1);
        if (_enough_0) {
          return $$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0);
        } else {
          const _next_0 = ((_size_0 << 1) >>> 0);
          $0 = _rest_0;
          $1 = array_node(_values_0, ($$$$047$$$047src$047ecs$047column$058absent$1261$(_depth_0)));
          $2 = _metadata_0;
          $3 = _next_0;
          $4 = nat_chk(_depth_0 + 1);
          $5 = _target_0;
          $6 = (_target_0 <= _next_0);
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047owned$045family$058get_ready$1260$(_rest_0, _cell_0, _same_0) {
  if (!_same_0) {
    return $owned$045rows$058bridge_work_stock_get$(($owned$045rows$058put_work_stock$(_rest_0, _cell_0)));
  } else {
    return $$$$047$$$047src$047ecs$047owned$045family$058projected$1260$(_rest_0, ($$$$047$$$047src$047ecs$047restored$045row$058project$1260$(_cell_0)));
  }
}

function $owned$045rows$058bridge_work_stock_write$(_row_0, _incoming_0) {
  return $owned$045rows$058bridge_work_stock_write_frame$(_incoming_0, ($owned$045rows$058leave_work$(_row_0)));
}

function $$$$047$$$047src$047ecs$047owned$045family$058write_clocked$1260$(_rest_0, _cell_0, _incoming_0, _observed_0) {
  const _meta_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "None") {
    return $$$$047$$$047src$047ecs$047owned$045family$058rejected$1260$(_rest_0, _cell_0, _incoming_0, {$: "../../src/ecs/world.CapacityExceeded"}, _meta_0);
  } else {
    const _tick_0 = _t_0["value"];
    return $$$$047$$$047src$047ecs$047owned$045family$058replaced$1260$(($owned$045rows$058put_header_work_stock$(_rest_0, _meta_0)), ($$$$047$$$047src$047ecs$047restored$045row$058replace$1260$(_cell_0, _incoming_0, _tick_0)));
  }
}

function $$$$047$$$047src$047ecs$047owned$045family$058get_ready$1261$(_rest_0, _cell_0, _same_0) {
  if (!_same_0) {
    return $owned$045rows$058bridge_work_recipe_get$(($owned$045rows$058put_work_recipe$(_rest_0, _cell_0)));
  } else {
    return $$$$047$$$047src$047ecs$047owned$045family$058projected$1261$(_rest_0, ($$$$047$$$047src$047ecs$047restored$045row$058project$1261$(_cell_0)));
  }
}

function $$$$047$$$047src$047ecs$047owned$045family$058get_ready$1262$(_rest_0, _cell_0, _same_0) {
  if (!_same_0) {
    return $owned$045rows$058bridge_work_queue_get$(($owned$045rows$058put_work_queue$(_rest_0, _cell_0)));
  } else {
    return $$$$047$$$047src$047ecs$047owned$045family$058projected$1262$(_rest_0, ($$$$047$$$047src$047ecs$047restored$045row$058project$1262$(_cell_0)));
  }
}

function $$$$047$$$047src$047ecs$047column$058viewed_return$1264$(_view_0, _result_0) {
  if (_result_0.$ === "../../src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    return {$: "Tuple", "fst": _column_0, "snd": {$: "Some", "value": _view_0}};
  } else {
    const _column_1 = _result_0["column"];
    return {$: "Tuple", "fst": _column_1, "snd": {$: "None"}};
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_projected_state$1264$(_id_0, _result_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047src$047ecs$047column$058indexed_view_projected$1264$(_id_0, _values_0, _metadata_0, _result_0);
}

function $$$$047$$$047src$047ecs$047column$058indexed_view_restored$1264$(_metadata_0, _projection_0, _result_0) {
  const _values_0 = _result_0["fst"];
  return {$: "Tuple", "fst": ($$$$047$$$047src$047ecs$047column$058indexed_wrap$1264$(_values_0, _metadata_0)), "snd": {$: "Some", "value": _projection_0}};
}

function $List$append$(_xs_0, _ys_0) {
  if (_xs_0.$ === "Nil") {
    return _ys_0;
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    return {$: "Con", "head": _h_0, "tail": ($List$append$(_t_0, _ys_0))};
  }
}

function $owned$045rows$058bridge_duplicate_stock_get$(_row_0) {
  return $owned$045rows$058bridge_duplicate_stock_get_join$(($$$$047$$$047src$047ecs$047compose$058get$1260$(($owned$045rows$058leave_duplicate$(_row_0)))));
}

function $$$$047$$$047src$047ecs$047owned$045family$058projected$1263$(_rest_0, _result_0) {
  if (_result_0.$ === "../../src/ecs/restored-row.Projected") {
    const _cell_0 = _result_0["cell"];
    const _t_0 = _result_0["value"];
    if (_t_0.$ === "None") {
      return {$: "Tuple", "fst": ($owned$045rows$058put_duplicate_stock$(_rest_0, _cell_0)), "snd": {$: "../../src/ecs/component.ComponentAbsent"}};
    } else {
      const _value_0 = _t_0["value"];
      return {$: "Tuple", "fst": ($owned$045rows$058put_duplicate_stock$(_rest_0, _cell_0)), "snd": {$: "../../src/ecs/component.Found", "value": _value_0}};
    }
  } else {
    const _cell_1 = _result_0["cell"];
    return $owned$045rows$058bridge_duplicate_stock_get$(($owned$045rows$058put_duplicate_stock$(_rest_0, _cell_1)));
  }
}

function $$$$047$$$047src$047ecs$047restored$045row$058project$1260$(_cell_0) {
  if (_cell_0.$ === "../../src/ecs/restored-row.Taken") {
    const _id_0 = _cell_0["id"];
    const _t_0 = _cell_0["owner"];
    if (_t_0.$ === "None") {
      const _stamp_0 = _cell_0["stamp"];
      const _dirty_0 = _cell_0["dirty"];
      const _cold_0 = _cell_0["restore"];
      return {$: "../../src/ecs/restored-row.Projected", "cell": {$: "../../src/ecs/restored-row.Taken", "id": _id_0, "owner": {$: "None"}, "stamp": _stamp_0, "dirty": _dirty_0, "restore": _cold_0}, "value": {$: "None"}};
    } else {
      const _owner_0 = _t_0["value"];
      const _stamp_1 = _cell_0["stamp"];
      const _dirty_1 = _cell_0["dirty"];
      const _cold_1 = _cell_0["restore"];
      return $$$$047$$$047src$047ecs$047restored$045row$058projected_owner$1260$(_id_0, _stamp_1, _dirty_1, _cold_1, ($schema$058project_stock$(_owner_0)));
    }
  } else {
    const _column_0 = _cell_0["column"];
    return {$: "../../src/ecs/restored-row.Deferred", "cell": {$: "../../src/ecs/restored-row.Untaken", "column": _column_0}};
  }
}

function $owned$045rows$058bridge_duplicate_stock_write_frame$(_incoming_0, _frame_0) {
  const _tx_0 = _frame_0["tx"];
  const _handle_0 = _frame_0["handle"];
  const _error_0 = _frame_0["error"];
  const _cursor_0 = _frame_0["cursor"];
  return $owned$045rows$058bridge_duplicate_stock_write_result$(_handle_0, _error_0, _cursor_0, ($$$$047$$$047src$047ecs$047component$058tx_set$1260$(($schema$058stock$()), _tx_0, _handle_0, _incoming_0)));
}

function $$$$047$$$047src$047ecs$047owned$045family$058replaced$1263$(_rest_0, _result_0) {
  if (_result_0.$ === "../../src/ecs/restored-row.Replaced") {
    const _cell_0 = _result_0["cell"];
    const _previous_0 = _result_0["previous"];
    const _stamp_0 = _result_0["stamp"];
    return {$: "../../src/ecs/owned-family.Written", "owner": ($owned$045rows$058put_duplicate_stock$(($owned$045rows$058journal_duplicate_stock$(_rest_0, _previous_0, _stamp_0)), _cell_0))};
  } else {
    const _cell_1 = _result_0["cell"];
    const _incoming_0 = _result_0["incoming"];
    return $$$$047$$$047src$047ecs$047owned$045family$058replace_refused$1263$(_cell_1, _incoming_0, ($owned$045rows$058header_duplicate_stock$(_rest_0)));
  }
}

function $$$$047$$$047src$047ecs$047restored$045row$058replace$1260$(_cell_0, _incoming_0, _tick_0) {
  if (_cell_0.$ === "../../src/ecs/restored-row.Taken") {
    const _id_0 = _cell_0["id"];
    const _owner_0 = _cell_0["owner"];
    const _stamp_0 = _cell_0["stamp"];
    const _cold_0 = _cell_0["restore"];
    return $$$$047$$$047src$047ecs$047restored$045row$058replacement_present$1260$(_id_0, _stamp_0, _cold_0, _incoming_0, _tick_0, ($$$$047$$$047src$047ecs$047restored$045row$058owner_present$1260$(_owner_0)));
  } else {
    const _column_0 = _cell_0["column"];
    return {$: "../../src/ecs/restored-row.Refused", "cell": {$: "../../src/ecs/restored-row.Untaken", "column": _column_0}, "incoming": _incoming_0};
  }
}

function $$$$047$$$047src$047ecs$047owned$045family$058clock_checked$(_allowed_0, _namespace_0, _nextId_0, _live_0, _handle_0, _clock_0, _error_0, _cursor_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": {$: "../../src/ecs/owned-family.Header", "namespace": _namespace_0, "nextId": _nextId_0, "live": _live_0, "handle": _handle_0, "clock": _clock_0, "error": _error_0, "cursor": _cursor_0}, "snd": {$: "None"}};
  } else {
    return {$: "Tuple", "fst": {$: "../../src/ecs/owned-family.Header", "namespace": _namespace_0, "nextId": _nextId_0, "live": _live_0, "handle": _handle_0, "clock": ((_clock_0 + 1) >>> 0), "error": _error_0, "cursor": _cursor_0}, "snd": {$: "Some", "value": ((_clock_0 + 1) >>> 0)}};
  }
}

function $$$$047$$$047src$047ecs$047indexed$045lifecycle$058write_grow$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _id_0 = $1;
      const _stamp_0 = $2;
      const _added_0 = $3;
      const _changed_0 = $4;
      const _capacity_0 = $5;
      const _depth_0 = $6;
      const _exceptional_0 = $7;
      const _fits_0 = $8;
      if (_fuel_0 === 0) {
        if (_fits_0) {
          return $$$$047$$$047src$047ecs$047indexed$045lifecycle$058write_ready$(_id_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, _stamp_0);
        } else {
          return {$: "../../src/ecs/indexed-lifecycle.Metadata", "added": _added_0, "changed": _changed_0, "capacity": _capacity_0, "depth": _depth_0, "exceptional": _exceptional_0};
        }
      } else {
        const _rest_0 = (_fuel_0 - 1);
        if (_fits_0) {
          return $$$$047$$$047src$047ecs$047indexed$045lifecycle$058write_ready$(_id_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, _stamp_0);
        } else {
          const _next_0 = ((_capacity_0 << 1) >>> 0);
          $0 = _rest_0;
          $1 = _id_0;
          $2 = _stamp_0;
          $3 = array_node(_added_0, array_new(_depth_0, 0));
          $4 = array_node(_changed_0, array_new(_depth_0, 0));
          $5 = _next_0;
          $6 = nat_chk(_depth_0 + 1);
          $7 = _exceptional_0;
          $8 = (_id_0 <= _next_0);
          continue;
        }
      }
    }
  }
}

function $gameplay$058work_recipe_view$1261$(_value_0, _owned_0, _recipe_0, _ctx_0) {
  const _r_0 = _recipe_0["value"];
  return $gameplay$058work_queue_read$1261$(_value_0, _owned_0, _r_0, run_loop($$$$047$$$047src$047ecs$047capabilities$058read$1265$(_ctx_0)));
}

function $$$$047$$$047src$047ecs$047column$058indexed_mark_got$1264$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return $$$$047$$$047src$047ecs$047column$058indexed_wrap$1264$(_values_0, ($$$$047$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, ($$$$047$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, _stamp_0, _tick_0)))));
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepared_mark_got$1264$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": ($$$$047$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, ($$$$047$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, _stamp_0, _tick_0)))), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047src$047ecs$047column$058absent$1264$(_depth_0) {
  if (_depth_0 === 0) {
    return [{$: "None"}];
  } else {
    const _rest_0 = (_depth_0 - 1);
    return array_node(($$$$047$$$047src$047ecs$047column$058absent$1264$(_rest_0)), ($$$$047$$$047src$047ecs$047column$058absent$1264$(_rest_0)));
  }
}

function $$$$047$$$047src$047ecs$047column$058ensure_recovered$1264$(_target_0, _column_0) {
  if (_column_0.$ === "../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047src$047ecs$047column$058ensure_sized$1264$(_target_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../src/ecs/column.Indexed") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058indexed_ensure_state$1264$(_target_0, ($$$$047$$$047src$047ecs$047column$058indexed_unseal$1264$(_carrier_0)));
  } else {
    return _column_0;
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_grow$1264$($0, $1, $2, $3, $4, $5, $6) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _size_0 = $3;
      const _depth_0 = $4;
      const _target_0 = $5;
      const _enough_0 = $6;
      if (_fuel_0 === 0) {
        if (_enough_0) {
          return $$$$047$$$047src$047ecs$047column$058indexed_wrap$1264$(_values_0, _metadata_0);
        } else {
          return $$$$047$$$047src$047ecs$047column$058indexed_wrap$1264$(_values_0, _metadata_0);
        }
      } else {
        const _rest_0 = (_fuel_0 - 1);
        if (_enough_0) {
          return $$$$047$$$047src$047ecs$047column$058indexed_wrap$1264$(_values_0, _metadata_0);
        } else {
          const _next_0 = ((_size_0 << 1) >>> 0);
          $0 = _rest_0;
          $1 = array_node(_values_0, ($$$$047$$$047src$047ecs$047column$058absent$1264$(_depth_0)));
          $2 = _metadata_0;
          $3 = _next_0;
          $4 = nat_chk(_depth_0 + 1);
          $5 = _target_0;
          $6 = (_target_0 <= _next_0);
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_mark_got$1263$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return $$$$047$$$047src$047ecs$047column$058indexed_wrap$1263$(_values_0, ($$$$047$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, ($$$$047$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, _stamp_0, _tick_0)))));
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepared_mark_got$1263$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": ($$$$047$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, ($$$$047$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, _stamp_0, _tick_0)))), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047src$047ecs$047column$058absent$1263$(_depth_0) {
  if (_depth_0 === 0) {
    return [{$: "None"}];
  } else {
    const _rest_0 = (_depth_0 - 1);
    return array_node(($$$$047$$$047src$047ecs$047column$058absent$1263$(_rest_0)), ($$$$047$$$047src$047ecs$047column$058absent$1263$(_rest_0)));
  }
}

function $$$$047$$$047src$047ecs$047column$058ensure_recovered$1263$(_target_0, _column_0) {
  if (_column_0.$ === "../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047src$047ecs$047column$058ensure_sized$1263$(_target_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../src/ecs/column.Indexed") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058indexed_ensure_state$1263$(_target_0, ($$$$047$$$047src$047ecs$047column$058indexed_unseal$1263$(_carrier_0)));
  } else {
    return _column_0;
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_grow$1263$($0, $1, $2, $3, $4, $5, $6) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _size_0 = $3;
      const _depth_0 = $4;
      const _target_0 = $5;
      const _enough_0 = $6;
      if (_fuel_0 === 0) {
        if (_enough_0) {
          return $$$$047$$$047src$047ecs$047column$058indexed_wrap$1263$(_values_0, _metadata_0);
        } else {
          return $$$$047$$$047src$047ecs$047column$058indexed_wrap$1263$(_values_0, _metadata_0);
        }
      } else {
        const _rest_0 = (_fuel_0 - 1);
        if (_enough_0) {
          return $$$$047$$$047src$047ecs$047column$058indexed_wrap$1263$(_values_0, _metadata_0);
        } else {
          const _next_0 = ((_size_0 << 1) >>> 0);
          $0 = _rest_0;
          $1 = array_node(_values_0, ($$$$047$$$047src$047ecs$047column$058absent$1263$(_depth_0)));
          $2 = _metadata_0;
          $3 = _next_0;
          $4 = nat_chk(_depth_0 + 1);
          $5 = _target_0;
          $6 = (_target_0 <= _next_0);
          continue;
        }
      }
    }
  }
}

function $owned$045rows$058set_work_recipe$(_row_0, _incoming_0) {
  return $$$$047$$$047src$047ecs$047owned$045family$058write_owner$1261$(($$$$047$$$047src$047ecs$047owned$045family$058write$1261$(_row_0, _incoming_0)));
}

function $owned$045rows$058set_work_queue$(_row_0, _incoming_0) {
  return $$$$047$$$047src$047ecs$047owned$045family$058write_owner$1262$(($$$$047$$$047src$047ecs$047owned$045family$058write$1262$(_row_0, _incoming_0)));
}

function $$$$047$$$047src$047ecs$047compose$058insert$1260$(_frame_0, _request_0) {
  const _t_0 = _frame_0["tx"];
  const _world_0 = _t_0["world"];
  const _undo_0 = _t_0["undo"];
  const _commands_0 = _t_0["commands"];
  const _events_0 = _t_0["events"];
  const _current_0 = _frame_0["handle"];
  const _error_0 = _frame_0["error"];
  const _cursor_0 = _frame_0["cursor"];
  const _target_0 = _request_0["target"];
  const _value_0 = _request_0["value"];
  return $$$$047$$$047src$047ecs$047compose$058insert_checked$1260$(_current_0, _error_0, _cursor_0, _target_0, _value_0, _undo_0, _commands_0, _events_0, ($$$$047$$$047src$047ecs$047world$058valid$1260$(_world_0, _target_0)));
}

function $$$$047$$$047src$047ecs$047compose$058selected_join$1264$(_mode_0, _observed_0) {
  const _frame_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _frame_0, "snd": ($$$$047$$$047src$047ecs$047compose$058selected_value$1264$(_mode_0, _value_0))};
}

function $$$$047$$$047src$047ecs$047compose$058get$1262$(_frame_0) {
  const _tx_0 = _frame_0["tx"];
  const _handle_0 = _frame_0["handle"];
  const _error_0 = _frame_0["error"];
  const _cursor_0 = _frame_0["cursor"];
  return $$$$047$$$047src$047ecs$047compose$058read_join$1262$(_handle_0, _error_0, _cursor_0, ($$$$047$$$047src$047ecs$047component$058tx_get$1262$(($schema$058queue$()), _tx_0, _handle_0)));
}

function $$$$047$$$047src$047ecs$047component$058mark_swapped$1262$(_rest_0, _column_0, _id_0, _incoming_0, _tick_0, _observed_0) {
  const _previous_0 = _observed_0["fst"];
  const _wasPresent_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($schema$058put_queue$(_rest_0, ($$$$047$$$047src$047ecs$047column$058mark$1262$(_column_0, _id_0, _incoming_0, _wasPresent_0, _tick_0)))), "snd": {$: "../../src/ecs/component.Swapped", "previous": _previous_0}};
}

function $$$$047$$$047src$047ecs$047column$058ensure_checked$1262$(_column_0, _target_0, _valid_0) {
  if (_column_0.$ === "../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    if (!_valid_0) {
      return {$: "../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
    } else {
      return $$$$047$$$047src$047ecs$047column$058ensure_sized$1262$(_target_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
    }
  } else if (_column_0.$ === "../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../../src/ecs/column.Prepared", "state": _carrier_0};
    } else {
      return $$$$047$$$047src$047ecs$047column$058ensure_state$1262$(_target_0, ($$$$047$$$047src$047ecs$047column$058unseal$1262$(_carrier_0)));
    }
  } else if (_column_0.$ === "../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../../src/ecs/column.Indexed", "state": _carrier_1};
    } else {
      return $$$$047$$$047src$047ecs$047column$058indexed_ensure_state$1262$(_target_0, ($$$$047$$$047src$047ecs$047column$058indexed_unseal$1262$(_carrier_1)));
    }
  } else {
    const _carrier_2 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../../src/ecs/column.PreparedIndexed", "state": _carrier_2};
    } else {
      return $$$$047$$$047src$047ecs$047column$058indexed_prepared_ensure_state$1262$(_target_0, ($$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1262$(_carrier_2)));
    }
  }
}

function $reference$045declarations$058advanced_id$1261$(_observed_0) {
  const _ctx_0 = _observed_0["fst"];
  const _id_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _ctx_0, "snd": {$: "Tuple", "fst": {$: "../../src/ecs/transaction.Success"}, "snd": _id_0}};
}

function $$$$047$$$047src$047ecs$047capabilities$058value_read$1268$(_ctx_0) {
  return run_tail(($$$$047$$$047src$047ecs$047capabilities$058value_read_field$1264$(($reference$045declarations$058advanced_handle$1261$({$: "reference-declarations.AdvancedCaps", "stock": ($owned$045rows$058read_advanced_stock$()), "queue": ($owned$045rows$058read_advanced_queue$()), "id": ($owned$045rows$058id_read_advanced$())})))), _ctx_0);
}

function $$$$047$$$047src$047ecs$047capabilities$058read_field$1266$(_cap_0) {
  const _get_0 = _cap_0["get"];
  return _get_0;
}

function $reference$045declarations$058advanced_queue$1261$(_caps_0) {
  const _queue_0 = _caps_0["queue"];
  return _queue_0;
}

function $owned$045rows$058get_advanced_stock$(_row_0) {
  return $$$$047$$$047src$047ecs$047owned$045family$058get$1264$(_row_0);
}

function $owned$045rows$058get_advanced_queue$(_row_0) {
  return $$$$047$$$047src$047ecs$047owned$045family$058get$1265$(_row_0);
}

function $owned$045rows$058id_advanced$($0) {
  for (;;) {
    {
      const _row_0 = $0;
      if (_row_0.$ === "owned-rows.AdvancedRow") {
        const _t_0 = _row_0["state"];
        const _header_0 = _t_0["header"];
        const _stock_0 = _t_0["stock"];
        const _queue_0 = _t_0["queue"];
        const _cold_0 = _t_0["cold"];
        return $owned$045rows$058id_advanced_header$(_stock_0, _queue_0, _cold_0, _header_0);
      } else {
        const _inner_0 = _row_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047compose$058and_join$1265$(_observed_0) {
  const _frame_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": _frame_0, "snd": false};
  } else {
    return $reference$045declarations$058lifecycle_stock$(_frame_0);
  }
}

function $reference$045declarations$058lifecycle_recipe$(_frame_0) {
  return $$$$047$$$047src$047ecs$047compose$058lifecycle_match$1260$(_frame_0);
}

function $Bool$to_u32$(_b_0) {
  if (!_b_0) {
    return 0;
  } else {
    return 1;
  }
}

function $owned$045rows$058bridge_work_stock_get$(_row_0) {
  return $owned$045rows$058bridge_work_stock_get_join$(($$$$047$$$047src$047ecs$047compose$058get$1260$(($owned$045rows$058leave_work$(_row_0)))));
}

function $$$$047$$$047src$047ecs$047owned$045family$058projected$1260$(_rest_0, _result_0) {
  if (_result_0.$ === "../../src/ecs/restored-row.Projected") {
    const _cell_0 = _result_0["cell"];
    const _t_0 = _result_0["value"];
    if (_t_0.$ === "None") {
      return {$: "Tuple", "fst": ($owned$045rows$058put_work_stock$(_rest_0, _cell_0)), "snd": {$: "../../src/ecs/component.ComponentAbsent"}};
    } else {
      const _value_0 = _t_0["value"];
      return {$: "Tuple", "fst": ($owned$045rows$058put_work_stock$(_rest_0, _cell_0)), "snd": {$: "../../src/ecs/component.Found", "value": _value_0}};
    }
  } else {
    const _cell_1 = _result_0["cell"];
    return $owned$045rows$058bridge_work_stock_get$(($owned$045rows$058put_work_stock$(_rest_0, _cell_1)));
  }
}

function $owned$045rows$058bridge_work_stock_write_frame$(_incoming_0, _frame_0) {
  const _tx_0 = _frame_0["tx"];
  const _handle_0 = _frame_0["handle"];
  const _error_0 = _frame_0["error"];
  const _cursor_0 = _frame_0["cursor"];
  return $owned$045rows$058bridge_work_stock_write_result$(_handle_0, _error_0, _cursor_0, ($$$$047$$$047src$047ecs$047component$058tx_set$1260$(($schema$058stock$()), _tx_0, _handle_0, _incoming_0)));
}

function $$$$047$$$047src$047ecs$047owned$045family$058replaced$1260$(_rest_0, _result_0) {
  if (_result_0.$ === "../../src/ecs/restored-row.Replaced") {
    const _cell_0 = _result_0["cell"];
    const _previous_0 = _result_0["previous"];
    const _stamp_0 = _result_0["stamp"];
    return {$: "../../src/ecs/owned-family.Written", "owner": ($owned$045rows$058put_work_stock$(($owned$045rows$058journal_work_stock$(_rest_0, _previous_0, _stamp_0)), _cell_0))};
  } else {
    const _cell_1 = _result_0["cell"];
    const _incoming_0 = _result_0["incoming"];
    return $$$$047$$$047src$047ecs$047owned$045family$058replace_refused$1260$(_cell_1, _incoming_0, ($owned$045rows$058header_work_stock$(_rest_0)));
  }
}

function $owned$045rows$058bridge_work_recipe_get$(_row_0) {
  return $owned$045rows$058bridge_work_recipe_get_join$(($$$$047$$$047src$047ecs$047compose$058get$1261$(($owned$045rows$058leave_work$(_row_0)))));
}

function $$$$047$$$047src$047ecs$047owned$045family$058projected$1261$(_rest_0, _result_0) {
  if (_result_0.$ === "../../src/ecs/restored-row.Projected") {
    const _cell_0 = _result_0["cell"];
    const _t_0 = _result_0["value"];
    if (_t_0.$ === "None") {
      return {$: "Tuple", "fst": ($owned$045rows$058put_work_recipe$(_rest_0, _cell_0)), "snd": {$: "../../src/ecs/component.ComponentAbsent"}};
    } else {
      const _value_0 = _t_0["value"];
      return {$: "Tuple", "fst": ($owned$045rows$058put_work_recipe$(_rest_0, _cell_0)), "snd": {$: "../../src/ecs/component.Found", "value": _value_0}};
    }
  } else {
    const _cell_1 = _result_0["cell"];
    return $owned$045rows$058bridge_work_recipe_get$(($owned$045rows$058put_work_recipe$(_rest_0, _cell_1)));
  }
}

function $$$$047$$$047src$047ecs$047restored$045row$058project$1261$(_cell_0) {
  if (_cell_0.$ === "../../src/ecs/restored-row.Taken") {
    const _id_0 = _cell_0["id"];
    const _t_0 = _cell_0["owner"];
    if (_t_0.$ === "None") {
      const _stamp_0 = _cell_0["stamp"];
      const _dirty_0 = _cell_0["dirty"];
      const _cold_0 = _cell_0["restore"];
      return {$: "../../src/ecs/restored-row.Projected", "cell": {$: "../../src/ecs/restored-row.Taken", "id": _id_0, "owner": {$: "None"}, "stamp": _stamp_0, "dirty": _dirty_0, "restore": _cold_0}, "value": {$: "None"}};
    } else {
      const _owner_0 = _t_0["value"];
      const _stamp_1 = _cell_0["stamp"];
      const _dirty_1 = _cell_0["dirty"];
      const _cold_1 = _cell_0["restore"];
      return $$$$047$$$047src$047ecs$047restored$045row$058projected_owner$1261$(_id_0, _stamp_1, _dirty_1, _cold_1, ($schema$058project_recipe$(_owner_0)));
    }
  } else {
    const _column_0 = _cell_0["column"];
    return {$: "../../src/ecs/restored-row.Deferred", "cell": {$: "../../src/ecs/restored-row.Untaken", "column": _column_0}};
  }
}

function $owned$045rows$058bridge_work_queue_get$(_row_0) {
  return $owned$045rows$058bridge_work_queue_get_join$(($$$$047$$$047src$047ecs$047compose$058get$1262$(($owned$045rows$058leave_work$(_row_0)))));
}

function $$$$047$$$047src$047ecs$047owned$045family$058projected$1262$(_rest_0, _result_0) {
  if (_result_0.$ === "../../src/ecs/restored-row.Projected") {
    const _cell_0 = _result_0["cell"];
    const _t_0 = _result_0["value"];
    if (_t_0.$ === "None") {
      return {$: "Tuple", "fst": ($owned$045rows$058put_work_queue$(_rest_0, _cell_0)), "snd": {$: "../../src/ecs/component.ComponentAbsent"}};
    } else {
      const _value_0 = _t_0["value"];
      return {$: "Tuple", "fst": ($owned$045rows$058put_work_queue$(_rest_0, _cell_0)), "snd": {$: "../../src/ecs/component.Found", "value": _value_0}};
    }
  } else {
    const _cell_1 = _result_0["cell"];
    return $owned$045rows$058bridge_work_queue_get$(($owned$045rows$058put_work_queue$(_rest_0, _cell_1)));
  }
}

function $$$$047$$$047src$047ecs$047restored$045row$058project$1262$(_cell_0) {
  if (_cell_0.$ === "../../src/ecs/restored-row.Taken") {
    const _id_0 = _cell_0["id"];
    const _t_0 = _cell_0["owner"];
    if (_t_0.$ === "None") {
      const _stamp_0 = _cell_0["stamp"];
      const _dirty_0 = _cell_0["dirty"];
      const _cold_0 = _cell_0["restore"];
      return {$: "../../src/ecs/restored-row.Projected", "cell": {$: "../../src/ecs/restored-row.Taken", "id": _id_0, "owner": {$: "None"}, "stamp": _stamp_0, "dirty": _dirty_0, "restore": _cold_0}, "value": {$: "None"}};
    } else {
      const _owner_0 = _t_0["value"];
      const _stamp_1 = _cell_0["stamp"];
      const _dirty_1 = _cell_0["dirty"];
      const _cold_1 = _cell_0["restore"];
      return $$$$047$$$047src$047ecs$047restored$045row$058projected_owner$1262$(_id_0, _stamp_1, _dirty_1, _cold_1, ($schema$058project_queue$(_owner_0)));
    }
  } else {
    const _column_0 = _cell_0["column"];
    return {$: "../../src/ecs/restored-row.Deferred", "cell": {$: "../../src/ecs/restored-row.Untaken", "column": _column_0}};
  }
}

function $owned$045rows$058bridge_duplicate_stock_get_join$(_observed_0) {
  const _frame_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($owned$045rows$058enter_duplicate$(_frame_0)), "snd": _value_0};
}

function $$$$047$$$047src$047ecs$047restored$045row$058projected_owner$1260$(_id_0, _stamp_0, _dirty_0, _cold_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return {$: "../../src/ecs/restored-row.Projected", "cell": {$: "../../src/ecs/restored-row.Taken", "id": _id_0, "owner": {$: "Some", "value": _owner_0}, "stamp": _stamp_0, "dirty": _dirty_0, "restore": _cold_0}, "value": {$: "Some", "value": _value_0}};
}

function $owned$045rows$058bridge_duplicate_stock_write_result$(_handle_0, _error_0, _cursor_0, _result_0) {
  if (_result_0.$ === "../../src/ecs/component.Written") {
    const _tx_0 = _result_0["tx"];
    return {$: "../../src/ecs/owned-family.Written", "owner": ($owned$045rows$058enter_duplicate$({$: "../../src/ecs/compose.Frame", "tx": _tx_0, "handle": _handle_0, "error": _error_0, "cursor": _cursor_0}))};
  } else if (_result_0.$ === "../../src/ecs/component.WriteRejected") {
    const _tx_1 = _result_0["tx"];
    const _incoming_0 = _result_0["incoming"];
    const _reason_0 = _result_0["error"];
    return {$: "../../src/ecs/owned-family.Rejected", "owner": ($owned$045rows$058enter_duplicate$({$: "../../src/ecs/compose.Frame", "tx": _tx_1, "handle": _handle_0, "error": ($$$$047$$$047src$047ecs$047compose$058first_error$(_error_0, _reason_0)), "cursor": _cursor_0})), "incoming": _incoming_0, "error": _reason_0};
  } else {
    const _tx_2 = _result_0["tx"];
    const _reason_1 = _result_0["error"];
    return {$: "../../src/ecs/owned-family.Written", "owner": ($owned$045rows$058enter_duplicate$({$: "../../src/ecs/compose.Frame", "tx": _tx_2, "handle": _handle_0, "error": ($$$$047$$$047src$047ecs$047compose$058first_error$(_error_0, _reason_1)), "cursor": _cursor_0}))};
  }
}

function $$$$047$$$047src$047ecs$047component$058tx_set$1260$(_family_0, _tx_0, _handle_0, _incoming_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047src$047ecs$047component$058tx_set_fused$1260$(_family_0, _handle_0, _undo_0, _commands_0, _events_0, ($$$$047$$$047src$047ecs$047component$058stamped_allowed$1260$(($$$$047$$$047src$047ecs$047world$058valid$1260$(_world_0, _handle_0)), _handle_0, _incoming_0)));
}

function $owned$045rows$058journal_duplicate_stock$(_rest_0, _previous_0, _stamp_0) {
  const _header_0 = _rest_0["header"];
  const _cold_0 = _rest_0["cold"];
  return $owned$045rows$058journal_duplicate_stock_header$(_cold_0, _previous_0, _stamp_0, _header_0);
}

function $$$$047$$$047src$047ecs$047owned$045family$058replace_refused$1263$(_cell_0, _incoming_0, _observed_0) {
  const _rest_0 = _observed_0["fst"];
  const _header_0 = _observed_0["snd"];
  return $$$$047$$$047src$047ecs$047owned$045family$058rejected$1263$(_rest_0, _cell_0, _incoming_0, {$: "../../src/ecs/world.CapacityExceeded"}, _header_0);
}

function $$$$047$$$047src$047ecs$047restored$045row$058replacement_present$1260$(_id_0, _stamp_0, _cold_0, _incoming_0, _tick_0, _observed_0) {
  const _previous_0 = _observed_0["fst"];
  const _present_0 = _observed_0["snd"];
  return {$: "../../src/ecs/restored-row.Replaced", "cell": {$: "../../src/ecs/restored-row.Taken", "id": _id_0, "owner": {$: "Some", "value": _incoming_0}, "stamp": ($$$$047$$$047src$047ecs$047lifecycle$058after_write$(true, _present_0, _stamp_0, _tick_0)), "dirty": true, "restore": _cold_0}, "previous": _previous_0, "stamp": _stamp_0};
}

function $$$$047$$$047src$047ecs$047restored$045row$058owner_present$1260$(_owner_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "None"}, "snd": false};
  } else {
    const _owner_1 = _owner_0["value"];
    return {$: "Tuple", "fst": {$: "Some", "value": _owner_1}, "snd": true};
  }
}

function $gameplay$058work_queue_read$1261$(_value_0, _owned_0, _r_0, _observed_0) {
  const _ctx_0 = _observed_0["fst"];
  const _queue_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": run_loop($$$$047$$$047src$047ecs$047capabilities$058set$1266$(_ctx_0, ($schema$058stock_owner$({$: "schema.StockView", "value": ((_value_0 + _r_0) >>> 0), "owned": ($List$append$(_owned_0, {$: "Con", "head": ($gameplay$058queue_value$(_queue_0)), "tail": {$: "Nil"}}))})))), "snd": {$: "Tuple", "fst": {$: "../../src/ecs/transaction.Success"}, "snd": {$: "Unit"}}};
}

function $$$$047$$$047src$047ecs$047owned$045family$058write_owner$1261$(_result_0) {
  if (_result_0.$ === "../../src/ecs/owned-family.Written") {
    const _owner_0 = _result_0["owner"];
    return _owner_0;
  } else {
    const _owner_1 = _result_0["owner"];
    return _owner_1;
  }
}

function $$$$047$$$047src$047ecs$047owned$045family$058write$1261$(_owner_0, _incoming_0) {
  return $$$$047$$$047src$047ecs$047owned$045family$058write_taken$1261$(_incoming_0, ($owned$045rows$058take_work_recipe$(_owner_0)));
}

function $$$$047$$$047src$047ecs$047owned$045family$058write_owner$1262$(_result_0) {
  if (_result_0.$ === "../../src/ecs/owned-family.Written") {
    const _owner_0 = _result_0["owner"];
    return _owner_0;
  } else {
    const _owner_1 = _result_0["owner"];
    return _owner_1;
  }
}

function $$$$047$$$047src$047ecs$047owned$045family$058write$1262$(_owner_0, _incoming_0) {
  return $$$$047$$$047src$047ecs$047owned$045family$058write_taken$1262$(_incoming_0, ($owned$045rows$058take_work_queue$(_owner_0)));
}

function $$$$047$$$047src$047ecs$047compose$058insert_checked$1260$(_current_0, _error_0, _cursor_0, _target_0, _value_0, _undo_0, _commands_0, _events_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return {$: "../../src/ecs/compose.Frame", "tx": {$: "../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "handle": _current_0, "error": ($$$$047$$$047src$047ecs$047compose$058first_error$(_error_0, {$: "../../src/ecs/world.MissingEntity"})), "cursor": _cursor_0};
  } else {
    return {$: "../../src/ecs/compose.Frame", "tx": ($$$$047$$$047src$047ecs$047transaction$058stage$1260$({$: "../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, run_clo((_x_0) => {
  return $$$$047$$$047src$047ecs$047compose$058insert_apply$1260$(_target_0, _value_0, _x_0);
}))), "handle": _current_0, "error": _error_0, "cursor": _cursor_0};
  }
}

function $$$$047$$$047src$047ecs$047compose$058selected_value$1264$(_mode_0, _value_0) {
  if (_mode_0.$ === "../../src/ecs/compose.Required") {
    if (_value_0.$ === "../../src/ecs/component.Found") {
      return true;
    } else {
      return false;
    }
  } else if (_mode_0.$ === "../../src/ecs/compose.Present") {
    if (_value_0.$ === "../../src/ecs/component.Found") {
      return true;
    } else {
      return false;
    }
  } else if (_mode_0.$ === "../../src/ecs/compose.Absent") {
    if (_value_0.$ === "../../src/ecs/component.ComponentAbsent") {
      return true;
    } else {
      return false;
    }
  } else {
    if (_value_0.$ === "../../src/ecs/component.Found") {
      return true;
    } else if (_value_0.$ === "../../src/ecs/component.ComponentAbsent") {
      return true;
    } else {
      return false;
    }
  }
}

function $$$$047$$$047src$047ecs$047compose$058read_join$1262$(_handle_0, _error_0, _cursor_0, _observed_0) {
  const _tx_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../src/ecs/compose.Frame", "tx": _tx_0, "handle": _handle_0, "error": _error_0, "cursor": _cursor_0}, "snd": _value_0};
}

function $$$$047$$$047src$047ecs$047component$058tx_get$1262$(_family_0, _tx_0, _handle_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047src$047ecs$047component$058tx_get_join$1262$(_undo_0, _commands_0, _events_0, ($$$$047$$$047src$047ecs$047component$058get$1262$(_family_0, _world_0, _handle_0)));
}

function $$$$047$$$047src$047ecs$047column$058mark$1262$(_column_0, _id_0, _incoming_0, _wasPresent_0, _tick_0) {
  if (_column_0.$ === "../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../src/ecs/column.Column", "values": _values_0, "stamps": ($$$$047$$$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, ($$$$047$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, ($$$$047$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0)), _tick_0))))};
  } else if (_column_0.$ === "../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058mark_state$1262$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047$$$047src$047ecs$047column$058unseal$1262$(_carrier_0)));
  } else if (_column_0.$ === "../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058indexed_mark_state$1262$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047$$$047src$047ecs$047column$058indexed_unseal$1262$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058indexed_prepared_mark_state$1262$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1262$(_carrier_2)));
  }
}

function $$$$047$$$047src$047ecs$047column$058ensure_sized$1262$(_target_0, _stamps_0, _sized_0) {
  const _values_0 = _sized_0["fst"];
  const _size_0 = _sized_0["snd"];
  return $$$$047$$$047src$047ecs$047column$058grow$1262$(17, _values_0, _stamps_0, _size_0, ($U32$log2$(_size_0)), _target_0, (_target_0 <= _size_0));
}

function $$$$047$$$047src$047ecs$047column$058ensure_state$1262$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047src$047ecs$047column$058ensure_prepared$1262$(_target_0, {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, (_target_0 <= _capacity_0));
}

function $$$$047$$$047src$047ecs$047column$058indexed_ensure_state$1262$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047src$047ecs$047column$058indexed_ensure_sized$1262$(_target_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepared_ensure_state$1262$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047src$047ecs$047column$058ensure_prepared$1262$(_target_0, {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, (_target_0 <= _capacity_0));
}

function $$$$047$$$047src$047ecs$047capabilities$058value_read_field$1264$(_cap_0) {
  const _get_0 = _cap_0["get"];
  return _get_0;
}

function $reference$045declarations$058advanced_handle$1261$(_caps_0) {
  const _id_0 = _caps_0["id"];
  return _id_0;
}

function $$$$047$$$047src$047ecs$047owned$045family$058get$1264$(_owner_0) {
  return $$$$047$$$047src$047ecs$047owned$045family$058get_taken$1264$(($owned$045rows$058take_advanced_stock$(_owner_0)));
}

function $$$$047$$$047src$047ecs$047owned$045family$058get$1265$(_owner_0) {
  return $$$$047$$$047src$047ecs$047owned$045family$058get_taken$1265$(($owned$045rows$058take_advanced_queue$(_owner_0)));
}

function $owned$045rows$058id_advanced_header$(_stock_0, _queue_0, _cold_0, _header_0) {
  const _namespace_0 = _header_0["namespace"];
  const _nextId_0 = _header_0["nextId"];
  const _live_0 = _header_0["live"];
  const _t_0 = _header_0["handle"];
  const _ns_0 = _t_0["namespace"];
  const _key_0 = _t_0["id"];
  const _clock_0 = _header_0["clock"];
  const _error_0 = _header_0["error"];
  const _cursor_0 = _header_0["cursor"];
  return {$: "Tuple", "fst": {$: "owned-rows.AdvancedRow", "state": {$: "owned-rows.AdvancedState", "header": {$: "../../src/ecs/owned-family.Header", "namespace": _namespace_0, "nextId": _nextId_0, "live": _live_0, "handle": {$: "../../src/ecs/world.Handle", "namespace": _ns_0, "id": _key_0}, "clock": _clock_0, "error": _error_0, "cursor": _cursor_0}, "stock": _stock_0, "queue": _queue_0, "cold": _cold_0}}, "snd": _key_0};
}

function $reference$045declarations$058lifecycle_stock$(_frame_0) {
  return $$$$047$$$047src$047ecs$047compose$058lifecycle_match$1261$(_frame_0);
}

function $$$$047$$$047src$047ecs$047compose$058lifecycle_match$1260$(_frame_0) {
  const _t_0 = _frame_0["tx"];
  const _world_0 = _t_0["world"];
  const _undo_0 = _t_0["undo"];
  const _commands_0 = _t_0["commands"];
  const _events_0 = _t_0["events"];
  const _handle_0 = _frame_0["handle"];
  const _error_0 = _frame_0["error"];
  const _cursor_0 = _frame_0["cursor"];
  return $$$$047$$$047src$047ecs$047compose$058lifecycle_join$1260$(_handle_0, _error_0, _cursor_0, _undo_0, _commands_0, _events_0, ($$$$047$$$047src$047ecs$047component$058lifecycle$1260$(($schema$058recipe$()), _world_0, _handle_0)));
}

function $owned$045rows$058bridge_work_stock_get_join$(_observed_0) {
  const _frame_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($owned$045rows$058enter_work$(_frame_0)), "snd": _value_0};
}

function $owned$045rows$058bridge_work_stock_write_result$(_handle_0, _error_0, _cursor_0, _result_0) {
  if (_result_0.$ === "../../src/ecs/component.Written") {
    const _tx_0 = _result_0["tx"];
    return {$: "../../src/ecs/owned-family.Written", "owner": ($owned$045rows$058enter_work$({$: "../../src/ecs/compose.Frame", "tx": _tx_0, "handle": _handle_0, "error": _error_0, "cursor": _cursor_0}))};
  } else if (_result_0.$ === "../../src/ecs/component.WriteRejected") {
    const _tx_1 = _result_0["tx"];
    const _incoming_0 = _result_0["incoming"];
    const _reason_0 = _result_0["error"];
    return {$: "../../src/ecs/owned-family.Rejected", "owner": ($owned$045rows$058enter_work$({$: "../../src/ecs/compose.Frame", "tx": _tx_1, "handle": _handle_0, "error": ($$$$047$$$047src$047ecs$047compose$058first_error$(_error_0, _reason_0)), "cursor": _cursor_0})), "incoming": _incoming_0, "error": _reason_0};
  } else {
    const _tx_2 = _result_0["tx"];
    const _reason_1 = _result_0["error"];
    return {$: "../../src/ecs/owned-family.Written", "owner": ($owned$045rows$058enter_work$({$: "../../src/ecs/compose.Frame", "tx": _tx_2, "handle": _handle_0, "error": ($$$$047$$$047src$047ecs$047compose$058first_error$(_error_0, _reason_1)), "cursor": _cursor_0}))};
  }
}

function $owned$045rows$058journal_work_stock$(_rest_0, _previous_0, _stamp_0) {
  const _header_0 = _rest_0["header"];
  const _recipe_0 = _rest_0["recipe"];
  const _queue_0 = _rest_0["queue"];
  const _cold_0 = _rest_0["cold"];
  return $owned$045rows$058journal_work_stock_header$(_recipe_0, _queue_0, _cold_0, _previous_0, _stamp_0, _header_0);
}

function $$$$047$$$047src$047ecs$047owned$045family$058replace_refused$1260$(_cell_0, _incoming_0, _observed_0) {
  const _rest_0 = _observed_0["fst"];
  const _header_0 = _observed_0["snd"];
  return $$$$047$$$047src$047ecs$047owned$045family$058rejected$1260$(_rest_0, _cell_0, _incoming_0, {$: "../../src/ecs/world.CapacityExceeded"}, _header_0);
}

function $owned$045rows$058bridge_work_recipe_get_join$(_observed_0) {
  const _frame_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($owned$045rows$058enter_work$(_frame_0)), "snd": _value_0};
}

function $$$$047$$$047src$047ecs$047restored$045row$058projected_owner$1261$(_id_0, _stamp_0, _dirty_0, _cold_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return {$: "../../src/ecs/restored-row.Projected", "cell": {$: "../../src/ecs/restored-row.Taken", "id": _id_0, "owner": {$: "Some", "value": _owner_0}, "stamp": _stamp_0, "dirty": _dirty_0, "restore": _cold_0}, "value": {$: "Some", "value": _value_0}};
}

function $owned$045rows$058bridge_work_queue_get_join$(_observed_0) {
  const _frame_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($owned$045rows$058enter_work$(_frame_0)), "snd": _value_0};
}

function $$$$047$$$047src$047ecs$047restored$045row$058projected_owner$1262$(_id_0, _stamp_0, _dirty_0, _cold_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return {$: "../../src/ecs/restored-row.Projected", "cell": {$: "../../src/ecs/restored-row.Taken", "id": _id_0, "owner": {$: "Some", "value": _owner_0}, "stamp": _stamp_0, "dirty": _dirty_0, "restore": _cold_0}, "value": {$: "Some", "value": _value_0}};
}

function $$$$047$$$047src$047ecs$047component$058tx_set_fused$1260$(_family_0, _handle_0, _undo_0, _commands_0, _events_0, _observed_0) {
  const _result_0 = _observed_0["fst"];
  const _stamp_0 = _observed_0["snd"];
  return $$$$047$$$047src$047ecs$047component$058tx_written$1260$(_family_0, _handle_0, _undo_0, _commands_0, _events_0, _stamp_0, _result_0);
}

function $$$$047$$$047src$047ecs$047component$058stamped_allowed$1260$(_checked_0, _handle_0, _incoming_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": {$: "../../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": {$: "Some", "value": _incoming_0}, "error": {$: "../../src/ecs/world.MissingEntity"}}, "snd": {$: "../../src/ecs/lifecycle.Stamp", "added": 0, "changed": 0}};
  } else {
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047src$047ecs$047component$058stamped_world$1260$(_id_0, _incoming_0, _world_0);
  }
}

function $owned$045rows$058journal_duplicate_stock_header$(_cold_0, _previous_0, _stamp_0, _header_0) {
  const _namespace_0 = _header_0["namespace"];
  const _nextId_0 = _header_0["nextId"];
  const _live_0 = _header_0["live"];
  const _handle_0 = _header_0["handle"];
  const _clock_0 = _header_0["clock"];
  const _error_0 = _header_0["error"];
  const _cursor_0 = _header_0["cursor"];
  return {$: "owned-rows.DuplicateStockRest", "header": {$: "../../src/ecs/owned-family.Header", "namespace": _namespace_0, "nextId": _nextId_0, "live": _live_0, "handle": _handle_0, "clock": _clock_0, "error": _error_0, "cursor": _cursor_0}, "cold": ($owned$045rows$058journal_duplicate_stock_cold$(_handle_0, _previous_0, _stamp_0, _cold_0))};
}

function $$$$047$$$047src$047ecs$047capabilities$058set$1266$(_ctx_0, _value_0) {
  return run_tail(($$$$047$$$047src$047ecs$047capabilities$058write_field$1263$(($gameplay$058work_stock$1261$({$: "gameplay.WorkCaps", "stock": ($owned$045rows$058write_work_stock$()), "recipe": ($owned$045rows$058read_work_recipe$()), "queue": ($owned$045rows$058read_work_queue$()), "id": ($owned$045rows$058id_read_work$())}))))(_ctx_0), _value_0);
}

function $schema$058stock_owner$(_view_0) {
  const _value_0 = _view_0["value"];
  const _values_0 = _view_0["owned"];
  return {$: "schema.Stock", "value": _value_0, "owned": ($schema$058payload_array$(_values_0)), "length": ($List$length$(_values_0))};
}

function $gameplay$058queue_value$(_value_0) {
  if (_value_0.$ === "../../src/ecs/component.Found") {
    const _t_0 = _value_0["value"];
    const _value_1 = _t_0["value"];
    return _value_1;
  } else {
    return 0;
  }
}

function $$$$047$$$047src$047ecs$047owned$045family$058write_taken$1261$(_incoming_0, _observed_0) {
  const _rest_0 = _observed_0["fst"];
  const _cell_0 = _observed_0["snd"];
  return $$$$047$$$047src$047ecs$047owned$045family$058write_split$1261$(_cell_0, _incoming_0, ($owned$045rows$058header_work_recipe$(_rest_0)));
}

function $$$$047$$$047src$047ecs$047owned$045family$058write_taken$1262$(_incoming_0, _observed_0) {
  const _rest_0 = _observed_0["fst"];
  const _cell_0 = _observed_0["snd"];
  return $$$$047$$$047src$047ecs$047owned$045family$058write_split$1262$(_cell_0, _incoming_0, ($owned$045rows$058header_work_queue$(_rest_0)));
}

function $$$$047$$$047src$047ecs$047transaction$058stage$1260$(_tx_0, _command_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return {$: "../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": {$: "Con", "head": _command_0, "tail": _commands_0}, "events": _events_0};
}

function $$$$047$$$047src$047ecs$047compose$058insert_apply$1260$(_target_0, _value_0, _world_0) {
  return $$$$047$$$047src$047ecs$047component$058restore_done$1260$(($$$$047$$$047src$047ecs$047component$058replace$1262$(($schema$058queue$()), _world_0, _target_0, {$: "Some", "value": _value_0})));
}

function $$$$047$$$047src$047ecs$047component$058tx_get_join$1262$(_undo_0, _commands_0, _events_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "snd": _value_0};
}

function $$$$047$$$047src$047ecs$047column$058mark_state$1262$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": ($$$$047$$$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, ($$$$047$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, ($$$$047$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0)), _tick_0)))), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047src$047ecs$047column$058indexed_mark_state$1262$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047src$047ecs$047column$058indexed_mark_got$1262$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, ($$$$047$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepared_mark_state$1262$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047src$047ecs$047column$058indexed_prepared_mark_got$1262$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($$$$047$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047src$047ecs$047column$058grow$1262$($0, $1, $2, $3, $4, $5, $6) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _size_0 = $3;
      const _depth_0 = $4;
      const _target_0 = $5;
      const _enough_0 = $6;
      if (_fuel_0 === 0) {
        if (_enough_0) {
          return {$: "../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        } else {
          return {$: "../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        }
      } else {
        const _rest_0 = (_fuel_0 - 1);
        if (_enough_0) {
          return {$: "../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        } else {
          const _next_0 = ((_size_0 << 1) >>> 0);
          $0 = _rest_0;
          $1 = array_node(_values_0, ($$$$047$$$047src$047ecs$047column$058absent$1262$(_depth_0)));
          $2 = _stamps_0;
          $3 = _next_0;
          $4 = nat_chk(_depth_0 + 1);
          $5 = _target_0;
          $6 = (_target_0 <= _next_0);
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047column$058ensure_prepared$1262$(_target_0, _column_0, _fits_0) {
  if (_fits_0) {
    return _column_0;
  } else {
    return $$$$047$$$047src$047ecs$047column$058ensure_recovered$1262$(_target_0, ($$$$047$$$047src$047ecs$047column$058recover$1262$(_column_0)));
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_ensure_sized$1262$(_target_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047src$047ecs$047column$058indexed_grow$1262$(17, _values_0, _metadata_0, _size_0, ($U32$log2$(_size_0)), _target_0, (_target_0 <= _size_0));
}

function $$$$047$$$047src$047ecs$047owned$045family$058get_taken$1264$(_observed_0) {
  const _rest_0 = _observed_0["fst"];
  const _cell_0 = _observed_0["snd"];
  return $$$$047$$$047src$047ecs$047owned$045family$058get_split$1264$(_cell_0, ($owned$045rows$058header_advanced_stock$(_rest_0)));
}

function $owned$045rows$058take_advanced_stock$($0) {
  for (;;) {
    {
      const _row_0 = $0;
      if (_row_0.$ === "owned-rows.AdvancedRow") {
        const _t_0 = _row_0["state"];
        const _header_0 = _t_0["header"];
        const _stock_0 = _t_0["stock"];
        const _queue_0 = _t_0["queue"];
        const _cold_0 = _t_0["cold"];
        return {$: "Tuple", "fst": {$: "owned-rows.AdvancedStockRest", "header": _header_0, "queue": _queue_0, "cold": _cold_0}, "snd": _stock_0};
      } else {
        const _inner_0 = _row_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047owned$045family$058get_taken$1265$(_observed_0) {
  const _rest_0 = _observed_0["fst"];
  const _cell_0 = _observed_0["snd"];
  return $$$$047$$$047src$047ecs$047owned$045family$058get_split$1265$(_cell_0, ($owned$045rows$058header_advanced_queue$(_rest_0)));
}

function $owned$045rows$058take_advanced_queue$($0) {
  for (;;) {
    {
      const _row_0 = $0;
      if (_row_0.$ === "owned-rows.AdvancedRow") {
        const _t_0 = _row_0["state"];
        const _header_0 = _t_0["header"];
        const _stock_0 = _t_0["stock"];
        const _queue_0 = _t_0["queue"];
        const _cold_0 = _t_0["cold"];
        return {$: "Tuple", "fst": {$: "owned-rows.AdvancedQueueRest", "header": _header_0, "stock": _stock_0, "cold": _cold_0}, "snd": _queue_0};
      } else {
        const _inner_0 = _row_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047compose$058lifecycle_match$1261$(_frame_0) {
  const _t_0 = _frame_0["tx"];
  const _world_0 = _t_0["world"];
  const _undo_0 = _t_0["undo"];
  const _commands_0 = _t_0["commands"];
  const _events_0 = _t_0["events"];
  const _handle_0 = _frame_0["handle"];
  const _error_0 = _frame_0["error"];
  const _cursor_0 = _frame_0["cursor"];
  return $$$$047$$$047src$047ecs$047compose$058lifecycle_join$1261$(_handle_0, _error_0, _cursor_0, _undo_0, _commands_0, _events_0, ($$$$047$$$047src$047ecs$047component$058lifecycle$1261$(($schema$058stock$()), _world_0, _handle_0)));
}

function $$$$047$$$047src$047ecs$047compose$058lifecycle_join$1260$(_handle_0, _error_0, _cursor_0, _undo_0, _commands_0, _events_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _stamp_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../src/ecs/compose.Frame", "tx": {$: "../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "handle": _handle_0, "error": _error_0, "cursor": _cursor_0}, "snd": ($$$$047$$$047src$047ecs$047compose$058lifecycle_selected$({$: "../../src/ecs/compose.Added"}, _stamp_0, _cursor_0))};
}

function $$$$047$$$047src$047ecs$047component$058lifecycle$1260$(_family_0, _world_0, _handle_0) {
  return $$$$047$$$047src$047ecs$047component$058lifecycle_allowed$1260$(($$$$047$$$047src$047ecs$047world$058valid$1260$(_world_0, _handle_0)), _handle_0);
}

function $owned$045rows$058journal_work_stock_header$(_recipe_0, _queue_0, _cold_0, _previous_0, _stamp_0, _header_0) {
  const _namespace_0 = _header_0["namespace"];
  const _nextId_0 = _header_0["nextId"];
  const _live_0 = _header_0["live"];
  const _handle_0 = _header_0["handle"];
  const _clock_0 = _header_0["clock"];
  const _error_0 = _header_0["error"];
  const _cursor_0 = _header_0["cursor"];
  return {$: "owned-rows.WorkStockRest", "header": {$: "../../src/ecs/owned-family.Header", "namespace": _namespace_0, "nextId": _nextId_0, "live": _live_0, "handle": _handle_0, "clock": _clock_0, "error": _error_0, "cursor": _cursor_0}, "recipe": _recipe_0, "queue": _queue_0, "cold": ($owned$045rows$058journal_work_stock_cold$(_handle_0, _previous_0, _stamp_0, _cold_0))};
}

function $$$$047$$$047src$047ecs$047component$058tx_written$1260$(_family_0, _handle_0, _undo_0, _commands_0, _events_0, _stamp_0, _result_0) {
  if (_result_0.$ === "../../src/ecs/component.Replaced") {
    const _world_0 = _result_0["world"];
    const _previous_0 = _result_0["previous"];
    return {$: "../../src/ecs/component.Written", "tx": {$: "../../src/ecs/transaction.Tx", "world": _world_0, "undo": {$: "Con", "head": run_clo((_x_0) => {
  return $$$$047$$$047src$047ecs$047component$058restore_stamp$1260$(_handle_0, _stamp_0, ($$$$047$$$047src$047ecs$047component$058restore$1260$(_family_0, _handle_0, _previous_0, _x_0)));
}), "tail": _undo_0}, "commands": _commands_0, "events": _events_0}};
  } else {
    const _world_1 = _result_0["world"];
    const _t_0 = _result_0["incoming"];
    if (_t_0.$ === "Some") {
      const _incoming_0 = _t_0["value"];
      const _error_0 = _result_0["error"];
      return {$: "../../src/ecs/component.WriteRejected", "tx": {$: "../../src/ecs/transaction.Tx", "world": _world_1, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "incoming": _incoming_0, "error": _error_0};
    } else {
      const _error_1 = _result_0["error"];
      return {$: "../../src/ecs/component.WriteFailure", "tx": {$: "../../src/ecs/transaction.Tx", "world": _world_1, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "error": _error_1};
    }
  }
}

function $$$$047$$$047src$047ecs$047component$058stamped_world$1260$(_id_0, _incoming_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047src$047ecs$047component$058stamped_replaced$1260$(($$$$047$$$047src$047ecs$047world$058with_store_finish$12611$(($$$$047$$$047src$047ecs$047component$058stamped_store$1260$(_id_0, _incoming_0, ($$$$047$$$047src$047ecs$047component$058stamped_tick$(_clock_0, (_clock_0 < 4294967295))), (_clock_0 < 4294967295), ($schema$058take_stock$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, ($$$$047$$$047src$047ecs$047component$058stamped_tick$(_clock_0, (_clock_0 < 4294967295))))));
}

function $owned$045rows$058journal_duplicate_stock_cold$($0, $1, $2, $3) {
  for (;;) {
    {
      const _handle_0 = $0;
      const _previous_0 = $1;
      const _stamp_0 = $2;
      const _cold_0 = $3;
      if (_cold_0.$ === "owned-rows.DuplicateCold") {
        const _t_0 = _cold_0["state"];
        const _highWater_0 = _t_0["highWater"];
        const _capacity_0 = _t_0["capacity"];
        const _depth_0 = _t_0["depth"];
        const _recipe_0 = _t_0["recipe"];
        const _queue_0 = _t_0["queue"];
        const _enabled_0 = _t_0["enabled"];
        const _locked_0 = _t_0["locked"];
        const _resource_0 = _t_0["resource"];
        const _events_0 = _t_0["events"];
        const _pending_0 = _t_0["pending"];
        const _registrations_0 = _t_0["registrations"];
        const _nextSystemId_0 = _t_0["nextSystemId"];
        const _undo_0 = _t_0["undo"];
        const _commands_0 = _t_0["commands"];
        const _txEvents_0 = _t_0["txEvents"];
        return {$: "owned-rows.DuplicateCold", "state": {$: "owned-rows.DuplicateColdState", "highWater": _highWater_0, "capacity": _capacity_0, "depth": _depth_0, "recipe": _recipe_0, "queue": _queue_0, "enabled": _enabled_0, "locked": _locked_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "undo": {$: "Con", "head": run_clo((_x_0) => {
  return $$$$047$$$047src$047ecs$047component$058restore_stamp$1260$(_handle_0, _stamp_0, ($$$$047$$$047src$047ecs$047component$058restore$1260$(($schema$058stock$()), _handle_0, _previous_0, _x_0)));
}), "tail": _undo_0}, "commands": _commands_0, "txEvents": _txEvents_0}};
      } else {
        const _inner_0 = _cold_0["inner"];
        $0 = _handle_0;
        $1 = _previous_0;
        $2 = _stamp_0;
        $3 = _inner_0;
        continue;
      }
    }
  }
}

function $List$length$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return 0;
  } else {
    const _t_0 = _xs_0["tail"];
    return nat_chk(($List$length$(_t_0)) + 1);
  }
}

function $$$$047$$$047src$047ecs$047owned$045family$058write_split$1261$(_cell_0, _incoming_0, _observed_0) {
  const _rest_0 = _observed_0["fst"];
  const _meta_0 = _observed_0["snd"];
  return $$$$047$$$047src$047ecs$047owned$045family$058write_checked$1261$(_rest_0, _cell_0, _incoming_0, ($$$$047$$$047src$047ecs$047owned$045family$058checked$(_meta_0)));
}

function $$$$047$$$047src$047ecs$047owned$045family$058write_split$1262$(_cell_0, _incoming_0, _observed_0) {
  const _rest_0 = _observed_0["fst"];
  const _meta_0 = _observed_0["snd"];
  return $$$$047$$$047src$047ecs$047owned$045family$058write_checked$1262$(_rest_0, _cell_0, _incoming_0, ($$$$047$$$047src$047ecs$047owned$045family$058checked$(_meta_0)));
}

function $$$$047$$$047src$047ecs$047component$058restore_done$1260$(_result_0) {
  if (_result_0.$ === "../../src/ecs/component.Replaced") {
    const _world_0 = _result_0["world"];
    return _world_0;
  } else {
    const _world_1 = _result_0["world"];
    return _world_1;
  }
}

function $$$$047$$$047src$047ecs$047component$058replace$1262$(_family_0, _world_0, _handle_0, _incoming_0) {
  return $$$$047$$$047src$047ecs$047component$058replace_allowed$1262$(($$$$047$$$047src$047ecs$047world$058valid$1260$(_world_0, _handle_0)), _handle_0, _incoming_0);
}

function $$$$047$$$047src$047ecs$047column$058indexed_mark_got$1262$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return $$$$047$$$047src$047ecs$047column$058indexed_wrap$1262$(_values_0, ($$$$047$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, ($$$$047$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, _stamp_0, _tick_0)))));
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepared_mark_got$1262$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": ($$$$047$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, ($$$$047$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, _stamp_0, _tick_0)))), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047src$047ecs$047column$058absent$1262$(_depth_0) {
  if (_depth_0 === 0) {
    return [{$: "None"}];
  } else {
    const _rest_0 = (_depth_0 - 1);
    return array_node(($$$$047$$$047src$047ecs$047column$058absent$1262$(_rest_0)), ($$$$047$$$047src$047ecs$047column$058absent$1262$(_rest_0)));
  }
}

function $$$$047$$$047src$047ecs$047column$058ensure_recovered$1262$(_target_0, _column_0) {
  if (_column_0.$ === "../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047src$047ecs$047column$058ensure_sized$1262$(_target_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../src/ecs/column.Indexed") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058indexed_ensure_state$1262$(_target_0, ($$$$047$$$047src$047ecs$047column$058indexed_unseal$1262$(_carrier_0)));
  } else {
    return _column_0;
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_grow$1262$($0, $1, $2, $3, $4, $5, $6) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _size_0 = $3;
      const _depth_0 = $4;
      const _target_0 = $5;
      const _enough_0 = $6;
      if (_fuel_0 === 0) {
        if (_enough_0) {
          return $$$$047$$$047src$047ecs$047column$058indexed_wrap$1262$(_values_0, _metadata_0);
        } else {
          return $$$$047$$$047src$047ecs$047column$058indexed_wrap$1262$(_values_0, _metadata_0);
        }
      } else {
        const _rest_0 = (_fuel_0 - 1);
        if (_enough_0) {
          return $$$$047$$$047src$047ecs$047column$058indexed_wrap$1262$(_values_0, _metadata_0);
        } else {
          const _next_0 = ((_size_0 << 1) >>> 0);
          $0 = _rest_0;
          $1 = array_node(_values_0, ($$$$047$$$047src$047ecs$047column$058absent$1262$(_depth_0)));
          $2 = _metadata_0;
          $3 = _next_0;
          $4 = nat_chk(_depth_0 + 1);
          $5 = _target_0;
          $6 = (_target_0 <= _next_0);
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047owned$045family$058get_split$1264$(_cell_0, _observed_0) {
  const _rest_0 = _observed_0["fst"];
  const _meta_0 = _observed_0["snd"];
  return $$$$047$$$047src$047ecs$047owned$045family$058get_checked$1264$(_rest_0, _cell_0, ($$$$047$$$047src$047ecs$047owned$045family$058checked$(_meta_0)));
}

function $owned$045rows$058header_advanced_stock$(_rest_0) {
  const _header_0 = _rest_0["header"];
  const _queue_0 = _rest_0["queue"];
  const _cold_0 = _rest_0["cold"];
  return {$: "Tuple", "fst": {$: "owned-rows.AdvancedStockMetaRest", "queue": _queue_0, "cold": _cold_0}, "snd": _header_0};
}

function $$$$047$$$047src$047ecs$047owned$045family$058get_split$1265$(_cell_0, _observed_0) {
  const _rest_0 = _observed_0["fst"];
  const _meta_0 = _observed_0["snd"];
  return $$$$047$$$047src$047ecs$047owned$045family$058get_checked$1265$(_rest_0, _cell_0, ($$$$047$$$047src$047ecs$047owned$045family$058checked$(_meta_0)));
}

function $owned$045rows$058header_advanced_queue$(_rest_0) {
  const _header_0 = _rest_0["header"];
  const _stock_0 = _rest_0["stock"];
  const _cold_0 = _rest_0["cold"];
  return {$: "Tuple", "fst": {$: "owned-rows.AdvancedQueueMetaRest", "stock": _stock_0, "cold": _cold_0}, "snd": _header_0};
}

function $$$$047$$$047src$047ecs$047compose$058lifecycle_join$1261$(_handle_0, _error_0, _cursor_0, _undo_0, _commands_0, _events_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _stamp_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../src/ecs/compose.Frame", "tx": {$: "../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "handle": _handle_0, "error": _error_0, "cursor": _cursor_0}, "snd": ($$$$047$$$047src$047ecs$047compose$058lifecycle_selected$({$: "../../src/ecs/compose.Changed"}, _stamp_0, _cursor_0))};
}

function $$$$047$$$047src$047ecs$047component$058lifecycle$1261$(_family_0, _world_0, _handle_0) {
  return $$$$047$$$047src$047ecs$047component$058lifecycle_allowed$1261$(($$$$047$$$047src$047ecs$047world$058valid$1260$(_world_0, _handle_0)), _handle_0);
}

function $$$$047$$$047src$047ecs$047compose$058lifecycle_selected$(_mode_0, _stamp_0, _cursor_0) {
  if (_mode_0.$ === "../../src/ecs/compose.Added") {
    return $$$$047$$$047src$047ecs$047lifecycle$058added$(_stamp_0, _cursor_0);
  } else {
    return $$$$047$$$047src$047ecs$047lifecycle$058changed$(_stamp_0, _cursor_0);
  }
}

function $$$$047$$$047src$047ecs$047component$058lifecycle_allowed$1260$(_checked_0, _handle_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../src/ecs/lifecycle.Stamp", "added": 0, "changed": 0}};
  } else {
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047src$047ecs$047component$058lifecycle_world$1260$(_id_0, _world_0);
  }
}

function $owned$045rows$058journal_work_stock_cold$($0, $1, $2, $3) {
  for (;;) {
    {
      const _handle_0 = $0;
      const _previous_0 = $1;
      const _stamp_0 = $2;
      const _cold_0 = $3;
      if (_cold_0.$ === "owned-rows.WorkCold") {
        const _t_0 = _cold_0["state"];
        const _highWater_0 = _t_0["highWater"];
        const _capacity_0 = _t_0["capacity"];
        const _depth_0 = _t_0["depth"];
        const _enabled_0 = _t_0["enabled"];
        const _locked_0 = _t_0["locked"];
        const _resource_0 = _t_0["resource"];
        const _events_0 = _t_0["events"];
        const _pending_0 = _t_0["pending"];
        const _registrations_0 = _t_0["registrations"];
        const _nextSystemId_0 = _t_0["nextSystemId"];
        const _undo_0 = _t_0["undo"];
        const _commands_0 = _t_0["commands"];
        const _txEvents_0 = _t_0["txEvents"];
        return {$: "owned-rows.WorkCold", "state": {$: "owned-rows.WorkColdState", "highWater": _highWater_0, "capacity": _capacity_0, "depth": _depth_0, "enabled": _enabled_0, "locked": _locked_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "undo": {$: "Con", "head": run_clo((_x_0) => {
  return $$$$047$$$047src$047ecs$047component$058restore_stamp$1260$(_handle_0, _stamp_0, ($$$$047$$$047src$047ecs$047component$058restore$1260$(($schema$058stock$()), _handle_0, _previous_0, _x_0)));
}), "tail": _undo_0}, "commands": _commands_0, "txEvents": _txEvents_0}};
      } else {
        const _inner_0 = _cold_0["inner"];
        $0 = _handle_0;
        $1 = _previous_0;
        $2 = _stamp_0;
        $3 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047component$058restore_stamp$1260$(_handle_0, _stamp_0, _world_0) {
  const _id_0 = _handle_0["id"];
  return $$$$047$$$047src$047ecs$047component$058restore_stamp_done$1260$(($$$$047$$$047src$047ecs$047component$058restore_stamp_world$1260$(_id_0, _stamp_0, _world_0)));
}

function $$$$047$$$047src$047ecs$047component$058restore$1260$(_family_0, _handle_0, _incoming_0, _world_0) {
  return $$$$047$$$047src$047ecs$047component$058restore_allowed$1260$(($$$$047$$$047src$047ecs$047world$058metadata_valid$1260$(_world_0, _handle_0)), _handle_0, _incoming_0);
}

function $$$$047$$$047src$047ecs$047component$058stamped_replaced$1260$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  const _t_1 = _t_0["fst"];
  if (_t_1.$ === "../../src/ecs/component.Swapped") {
    const _previous_0 = _t_1["previous"];
    const _stamp_0 = _t_0["snd"];
    return {$: "Tuple", "fst": {$: "../../src/ecs/component.Replaced", "world": _world_0, "previous": _previous_0}, "snd": _stamp_0};
  } else {
    const _incoming_0 = _t_1["incoming"];
    const _stamp_1 = _t_0["snd"];
    return {$: "Tuple", "fst": {$: "../../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../src/ecs/world.CapacityExceeded"}}, "snd": _stamp_1};
  }
}

function $$$$047$$$047src$047ecs$047world$058with_store_finish$12611$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047src$047ecs$047component$058stamped_store$1260$(_id_0, _incoming_0, _tick_0, _allowed_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047src$047ecs$047component$058stamped_column$1260$(_rest_0, _id_0, _incoming_0, _tick_0, _allowed_0, ($$$$047$$$047src$047ecs$047column$058lifecycle$1260$(_column_0, _id_0)));
}

function $$$$047$$$047src$047ecs$047component$058stamped_tick$(_clock_0, _allowed_0) {
  if (!_allowed_0) {
    return _clock_0;
  } else {
    return ((_clock_0 + 1) >>> 0);
  }
}

function $$$$047$$$047src$047ecs$047owned$045family$058write_checked$1261$(_rest_0, _cell_0, _incoming_0, _observed_0) {
  const _meta_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return $$$$047$$$047src$047ecs$047owned$045family$058rejected$1261$(_rest_0, _cell_0, _incoming_0, {$: "../../src/ecs/world.MissingEntity"}, _meta_0);
  } else {
    return $$$$047$$$047src$047ecs$047owned$045family$058write_targeted$1261$(_rest_0, _cell_0, _incoming_0, ($$$$047$$$047src$047ecs$047owned$045family$058target$(_meta_0)));
  }
}

function $$$$047$$$047src$047ecs$047owned$045family$058write_checked$1262$(_rest_0, _cell_0, _incoming_0, _observed_0) {
  const _meta_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return $$$$047$$$047src$047ecs$047owned$045family$058rejected$1262$(_rest_0, _cell_0, _incoming_0, {$: "../../src/ecs/world.MissingEntity"}, _meta_0);
  } else {
    return $$$$047$$$047src$047ecs$047owned$045family$058write_targeted$1262$(_rest_0, _cell_0, _incoming_0, ($$$$047$$$047src$047ecs$047owned$045family$058target$(_meta_0)));
  }
}

function $$$$047$$$047src$047ecs$047owned$045family$058get_checked$1264$(_rest_0, _cell_0, _observed_0) {
  const _header_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": ($owned$045rows$058put_advanced_stock$(($owned$045rows$058put_header_advanced_stock$(_rest_0, _header_0)), _cell_0)), "snd": {$: "../../src/ecs/component.MissingEntity"}};
  } else {
    return $$$$047$$$047src$047ecs$047owned$045family$058get_targeted$1264$(_rest_0, _cell_0, ($$$$047$$$047src$047ecs$047owned$045family$058target$(_header_0)));
  }
}

function $$$$047$$$047src$047ecs$047owned$045family$058get_checked$1265$(_rest_0, _cell_0, _observed_0) {
  const _header_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": ($owned$045rows$058put_advanced_queue$(($owned$045rows$058put_header_advanced_queue$(_rest_0, _header_0)), _cell_0)), "snd": {$: "../../src/ecs/component.MissingEntity"}};
  } else {
    return $$$$047$$$047src$047ecs$047owned$045family$058get_targeted$1265$(_rest_0, _cell_0, ($$$$047$$$047src$047ecs$047owned$045family$058target$(_header_0)));
  }
}

function $$$$047$$$047src$047ecs$047component$058lifecycle_allowed$1261$(_checked_0, _handle_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../src/ecs/lifecycle.Stamp", "added": 0, "changed": 0}};
  } else {
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047src$047ecs$047component$058lifecycle_world$1261$(_id_0, _world_0);
  }
}

function $$$$047$$$047src$047ecs$047lifecycle$058added$(_stamp_0, _cursor_0) {
  const _value_0 = _stamp_0["added"];
  return (_value_0 > _cursor_0);
}

function $$$$047$$$047src$047ecs$047lifecycle$058changed$(_stamp_0, _cursor_0) {
  const _value_0 = _stamp_0["changed"];
  return (_value_0 > _cursor_0);
}

function $$$$047$$$047src$047ecs$047component$058lifecycle_world$1260$(_id_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047src$047ecs$047world$058with_store_finish$12616$(($$$$047$$$047src$047ecs$047component$058lifecycle_store$1260$(_id_0, ($schema$058take_recipe$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047src$047ecs$047component$058restore_stamp_done$1260$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  return _world_0;
}

function $$$$047$$$047src$047ecs$047component$058restore_stamp_world$1260$(_id_0, _stamp_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047src$047ecs$047world$058with_store_finish$12610$(($$$$047$$$047src$047ecs$047component$058restore_stamp_store$1260$(_id_0, _stamp_0, ($schema$058take_stock$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047src$047ecs$047component$058restore_allowed$1260$(_checked_0, _handle_0, _incoming_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return _world_0;
  } else {
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047src$047ecs$047component$058restore_observed$1260$(($$$$047$$$047src$047ecs$047component$058restore_world$1260$(_id_0, _incoming_0, _world_0)));
  }
}

function $$$$047$$$047src$047ecs$047component$058stamped_column$1260$(_rest_0, _id_0, _incoming_0, _tick_0, _allowed_0, _observed_0) {
  if (!_allowed_0) {
    const _column_0 = _observed_0["fst"];
    const _stamp_0 = _observed_0["snd"];
    return {$: "Tuple", "fst": ($schema$058put_stock$(_rest_0, _column_0)), "snd": {$: "Tuple", "fst": {$: "../../src/ecs/component.SwapRejected", "incoming": {$: "Some", "value": _incoming_0}}, "snd": _stamp_0}};
  } else {
    const _column_1 = _observed_0["fst"];
    const _stamp_1 = _observed_0["snd"];
    return $$$$047$$$047src$047ecs$047component$058stamped_store_join$1260$(_stamp_1, ($$$$047$$$047src$047ecs$047component$058swap_join$1260$(_rest_0, _id_0, true, _tick_0, ($$$$047$$$047src$047ecs$047column$058swap$1260$(($$$$047$$$047src$047ecs$047column$058ensure$1260$(_column_1, _id_0)), _id_0, {$: "Some", "value": _incoming_0})))));
  }
}

function $$$$047$$$047src$047ecs$047column$058lifecycle$1260$(_column_0, _id_0) {
  if (_column_0.$ === "../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "Tuple", "fst": {$: "../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": ($$$$047$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0))};
  } else if (_column_0.$ === "../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058lifecycle_state$1260$(_id_0, ($$$$047$$$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
  } else if (_column_0.$ === "../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058indexed_lifecycle_state$1260$(_id_0, ($$$$047$$$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058indexed_prepared_lifecycle_state$1260$(_id_0, ($$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
  }
}

function $$$$047$$$047src$047ecs$047owned$045family$058rejected$1261$(_rest_0, _cell_0, _incoming_0, _reason_0, _header_0) {
  return {$: "../../src/ecs/owned-family.Rejected", "owner": ($owned$045rows$058put_work_recipe$(($owned$045rows$058put_header_work_recipe$(_rest_0, ($$$$047$$$047src$047ecs$047owned$045family$058reject_header$(_reason_0, _header_0)))), _cell_0)), "incoming": _incoming_0, "error": _reason_0};
}

function $$$$047$$$047src$047ecs$047owned$045family$058write_targeted$1261$(_rest_0, _cell_0, _incoming_0, _observed_0) {
  const _meta_0 = _observed_0["fst"];
  const _id_0 = _observed_0["snd"];
  return $$$$047$$$047src$047ecs$047owned$045family$058write_matching$1261$(_rest_0, _meta_0, _incoming_0, ($$$$047$$$047src$047ecs$047owned$045family$058cell_matches$1261$(_cell_0, _id_0)));
}

function $$$$047$$$047src$047ecs$047owned$045family$058rejected$1262$(_rest_0, _cell_0, _incoming_0, _reason_0, _header_0) {
  return {$: "../../src/ecs/owned-family.Rejected", "owner": ($owned$045rows$058put_work_queue$(($owned$045rows$058put_header_work_queue$(_rest_0, ($$$$047$$$047src$047ecs$047owned$045family$058reject_header$(_reason_0, _header_0)))), _cell_0)), "incoming": _incoming_0, "error": _reason_0};
}

function $$$$047$$$047src$047ecs$047owned$045family$058write_targeted$1262$(_rest_0, _cell_0, _incoming_0, _observed_0) {
  const _meta_0 = _observed_0["fst"];
  const _id_0 = _observed_0["snd"];
  return $$$$047$$$047src$047ecs$047owned$045family$058write_matching$1262$(_rest_0, _meta_0, _incoming_0, ($$$$047$$$047src$047ecs$047owned$045family$058cell_matches$1262$(_cell_0, _id_0)));
}

function $owned$045rows$058put_advanced_stock$(_rest_0, _cell_0) {
  const _header_0 = _rest_0["header"];
  const _queue_0 = _rest_0["queue"];
  const _cold_0 = _rest_0["cold"];
  return {$: "owned-rows.AdvancedRow", "state": {$: "owned-rows.AdvancedState", "header": _header_0, "stock": _cell_0, "queue": _queue_0, "cold": _cold_0}};
}

function $owned$045rows$058put_header_advanced_stock$(_rest_0, _header_0) {
  const _queue_0 = _rest_0["queue"];
  const _cold_0 = _rest_0["cold"];
  return {$: "owned-rows.AdvancedStockRest", "header": _header_0, "queue": _queue_0, "cold": _cold_0};
}

function $$$$047$$$047src$047ecs$047owned$045family$058get_targeted$1264$(_rest_0, _cell_0, _observed_0) {
  const _header_0 = _observed_0["fst"];
  const _id_0 = _observed_0["snd"];
  return $$$$047$$$047src$047ecs$047owned$045family$058get_matching$1264$(($owned$045rows$058put_header_advanced_stock$(_rest_0, _header_0)), ($$$$047$$$047src$047ecs$047owned$045family$058cell_matches$1260$(_cell_0, _id_0)));
}

function $owned$045rows$058put_advanced_queue$(_rest_0, _cell_0) {
  const _header_0 = _rest_0["header"];
  const _stock_0 = _rest_0["stock"];
  const _cold_0 = _rest_0["cold"];
  return {$: "owned-rows.AdvancedRow", "state": {$: "owned-rows.AdvancedState", "header": _header_0, "stock": _stock_0, "queue": _cell_0, "cold": _cold_0}};
}

function $owned$045rows$058put_header_advanced_queue$(_rest_0, _header_0) {
  const _stock_0 = _rest_0["stock"];
  const _cold_0 = _rest_0["cold"];
  return {$: "owned-rows.AdvancedQueueRest", "header": _header_0, "stock": _stock_0, "cold": _cold_0};
}

function $$$$047$$$047src$047ecs$047owned$045family$058get_targeted$1265$(_rest_0, _cell_0, _observed_0) {
  const _header_0 = _observed_0["fst"];
  const _id_0 = _observed_0["snd"];
  return $$$$047$$$047src$047ecs$047owned$045family$058get_matching$1265$(($owned$045rows$058put_header_advanced_queue$(_rest_0, _header_0)), ($$$$047$$$047src$047ecs$047owned$045family$058cell_matches$1262$(_cell_0, _id_0)));
}

function $$$$047$$$047src$047ecs$047component$058lifecycle_world$1261$(_id_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047src$047ecs$047world$058with_store_finish$12616$(($$$$047$$$047src$047ecs$047component$058lifecycle_store$1261$(_id_0, ($schema$058take_stock$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047src$047ecs$047world$058with_store_finish$12616$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047src$047ecs$047component$058lifecycle_store$1260$(_id_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047src$047ecs$047component$058lifecycle_join$1260$(_rest_0, ($$$$047$$$047src$047ecs$047column$058lifecycle$1261$(_column_0, _id_0)));
}

function $$$$047$$$047src$047ecs$047component$058restore_stamp_store$1260$(_id_0, _stamp_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return {$: "Tuple", "fst": ($schema$058put_stock$(_rest_0, ($$$$047$$$047src$047ecs$047column$058restore_stamp$1260$(_column_0, _id_0, _stamp_0)))), "snd": {$: "Unit"}};
}

function $$$$047$$$047src$047ecs$047component$058restore_observed$1260$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  return _world_0;
}

function $$$$047$$$047src$047ecs$047component$058restore_world$1260$(_id_0, _incoming_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047src$047ecs$047world$058with_store_finish$12610$(($$$$047$$$047src$047ecs$047component$058restore_store$1260$(_id_0, _incoming_0, ($schema$058take_stock$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047src$047ecs$047component$058stamped_store_join$1260$(_stamp_0, _result_0) {
  const _store_0 = _result_0["fst"];
  const _outcome_0 = _result_0["snd"];
  return {$: "Tuple", "fst": _store_0, "snd": {$: "Tuple", "fst": _outcome_0, "snd": _stamp_0}};
}

function $$$$047$$$047src$047ecs$047column$058lifecycle_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "Tuple", "fst": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": ($$$$047$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0))};
}

function $$$$047$$$047src$047ecs$047column$058indexed_lifecycle_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047src$047ecs$047column$058indexed_lifecycle_got$1260$(_values_0, ($$$$047$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepared_lifecycle_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047src$047ecs$047column$058indexed_prepared_lifecycle_got$1260$(_values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($$$$047$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047src$047ecs$047owned$045family$058write_matching$1261$(_rest_0, _meta_0, _incoming_0, _observed_0) {
  const _cell_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return $owned$045rows$058bridge_work_recipe_write$(($owned$045rows$058put_work_recipe$(($owned$045rows$058put_header_work_recipe$(_rest_0, _meta_0)), _cell_0)), _incoming_0);
  } else {
    return $$$$047$$$047src$047ecs$047owned$045family$058write_clocked$1261$(_rest_0, _cell_0, _incoming_0, ($$$$047$$$047src$047ecs$047owned$045family$058clocked$(_meta_0)));
  }
}

function $$$$047$$$047src$047ecs$047owned$045family$058write_matching$1262$(_rest_0, _meta_0, _incoming_0, _observed_0) {
  const _cell_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return $owned$045rows$058bridge_work_queue_write$(($owned$045rows$058put_work_queue$(($owned$045rows$058put_header_work_queue$(_rest_0, _meta_0)), _cell_0)), _incoming_0);
  } else {
    return $$$$047$$$047src$047ecs$047owned$045family$058write_clocked$1262$(_rest_0, _cell_0, _incoming_0, ($$$$047$$$047src$047ecs$047owned$045family$058clocked$(_meta_0)));
  }
}

function $$$$047$$$047src$047ecs$047owned$045family$058get_matching$1264$(_rest_0, _observed_0) {
  const _cell_0 = _observed_0["fst"];
  const _same_0 = _observed_0["snd"];
  return $$$$047$$$047src$047ecs$047owned$045family$058get_ready$1264$(_rest_0, _cell_0, _same_0);
}

function $$$$047$$$047src$047ecs$047owned$045family$058get_matching$1265$(_rest_0, _observed_0) {
  const _cell_0 = _observed_0["fst"];
  const _same_0 = _observed_0["snd"];
  return $$$$047$$$047src$047ecs$047owned$045family$058get_ready$1265$(_rest_0, _cell_0, _same_0);
}

function $$$$047$$$047src$047ecs$047component$058lifecycle_store$1261$(_id_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047src$047ecs$047component$058lifecycle_join$1261$(_rest_0, ($$$$047$$$047src$047ecs$047column$058lifecycle$1260$(_column_0, _id_0)));
}

function $$$$047$$$047src$047ecs$047component$058lifecycle_join$1260$(_rest_0, _observed_0) {
  const _column_0 = _observed_0["fst"];
  const _stamp_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($schema$058put_recipe$(_rest_0, _column_0)), "snd": _stamp_0};
}

function $$$$047$$$047src$047ecs$047column$058lifecycle$1261$(_column_0, _id_0) {
  if (_column_0.$ === "../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "Tuple", "fst": {$: "../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": ($$$$047$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0))};
  } else if (_column_0.$ === "../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058lifecycle_state$1261$(_id_0, ($$$$047$$$047src$047ecs$047column$058unseal$1261$(_carrier_0)));
  } else if (_column_0.$ === "../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058indexed_lifecycle_state$1261$(_id_0, ($$$$047$$$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058indexed_prepared_lifecycle_state$1261$(_id_0, ($$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1261$(_carrier_2)));
  }
}

function $$$$047$$$047src$047ecs$047component$058restore_store$1260$(_id_0, _incoming_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047src$047ecs$047component$058restore_swap$1260$(_rest_0, ($$$$047$$$047src$047ecs$047column$058swap$1260$(($$$$047$$$047src$047ecs$047column$058ensure$1260$(_column_0, _id_0)), _id_0, _incoming_0)));
}

function $$$$047$$$047src$047ecs$047column$058indexed_lifecycle_got$1260$(_values_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "Tuple", "fst": ($$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "snd": _stamp_0};
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepared_lifecycle_got$1260$(_values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": _stamp_0};
}

function $owned$045rows$058bridge_work_recipe_write$(_row_0, _incoming_0) {
  return $owned$045rows$058bridge_work_recipe_write_frame$(_incoming_0, ($owned$045rows$058leave_work$(_row_0)));
}

function $$$$047$$$047src$047ecs$047owned$045family$058write_clocked$1261$(_rest_0, _cell_0, _incoming_0, _observed_0) {
  const _meta_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "None") {
    return $$$$047$$$047src$047ecs$047owned$045family$058rejected$1261$(_rest_0, _cell_0, _incoming_0, {$: "../../src/ecs/world.CapacityExceeded"}, _meta_0);
  } else {
    const _tick_0 = _t_0["value"];
    return $$$$047$$$047src$047ecs$047owned$045family$058replaced$1261$(($owned$045rows$058put_header_work_recipe$(_rest_0, _meta_0)), ($$$$047$$$047src$047ecs$047restored$045row$058replace$1261$(_cell_0, _incoming_0, _tick_0)));
  }
}

function $owned$045rows$058bridge_work_queue_write$(_row_0, _incoming_0) {
  return $owned$045rows$058bridge_work_queue_write_frame$(_incoming_0, ($owned$045rows$058leave_work$(_row_0)));
}

function $$$$047$$$047src$047ecs$047owned$045family$058write_clocked$1262$(_rest_0, _cell_0, _incoming_0, _observed_0) {
  const _meta_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "None") {
    return $$$$047$$$047src$047ecs$047owned$045family$058rejected$1262$(_rest_0, _cell_0, _incoming_0, {$: "../../src/ecs/world.CapacityExceeded"}, _meta_0);
  } else {
    const _tick_0 = _t_0["value"];
    return $$$$047$$$047src$047ecs$047owned$045family$058replaced$1262$(($owned$045rows$058put_header_work_queue$(_rest_0, _meta_0)), ($$$$047$$$047src$047ecs$047restored$045row$058replace$1262$(_cell_0, _incoming_0, _tick_0)));
  }
}

function $$$$047$$$047src$047ecs$047owned$045family$058get_ready$1264$(_rest_0, _cell_0, _same_0) {
  if (!_same_0) {
    return $owned$045rows$058bridge_advanced_stock_get$(($owned$045rows$058put_advanced_stock$(_rest_0, _cell_0)));
  } else {
    return $$$$047$$$047src$047ecs$047owned$045family$058projected$1264$(_rest_0, ($$$$047$$$047src$047ecs$047restored$045row$058project$1260$(_cell_0)));
  }
}

function $$$$047$$$047src$047ecs$047owned$045family$058get_ready$1265$(_rest_0, _cell_0, _same_0) {
  if (!_same_0) {
    return $owned$045rows$058bridge_advanced_queue_get$(($owned$045rows$058put_advanced_queue$(_rest_0, _cell_0)));
  } else {
    return $$$$047$$$047src$047ecs$047owned$045family$058projected$1265$(_rest_0, ($$$$047$$$047src$047ecs$047restored$045row$058project$1262$(_cell_0)));
  }
}

function $$$$047$$$047src$047ecs$047component$058lifecycle_join$1261$(_rest_0, _observed_0) {
  const _column_0 = _observed_0["fst"];
  const _stamp_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($schema$058put_stock$(_rest_0, _column_0)), "snd": _stamp_0};
}

function $$$$047$$$047src$047ecs$047column$058lifecycle_state$1261$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "Tuple", "fst": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": ($$$$047$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0))};
}

function $$$$047$$$047src$047ecs$047column$058indexed_lifecycle_state$1261$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047src$047ecs$047column$058indexed_lifecycle_got$1261$(_values_0, ($$$$047$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepared_lifecycle_state$1261$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047src$047ecs$047column$058indexed_prepared_lifecycle_got$1261$(_values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($$$$047$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047src$047ecs$047component$058restore_swap$1260$(_rest_0, _result_0) {
  if (_result_0.$ === "../../src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    return {$: "Tuple", "fst": ($schema$058put_stock$(_rest_0, _column_0)), "snd": {$: "Unit"}};
  } else {
    const _column_1 = _result_0["column"];
    return {$: "Tuple", "fst": ($schema$058put_stock$(_rest_0, _column_1)), "snd": {$: "Unit"}};
  }
}

function $owned$045rows$058bridge_work_recipe_write_frame$(_incoming_0, _frame_0) {
  const _tx_0 = _frame_0["tx"];
  const _handle_0 = _frame_0["handle"];
  const _error_0 = _frame_0["error"];
  const _cursor_0 = _frame_0["cursor"];
  return $owned$045rows$058bridge_work_recipe_write_result$(_handle_0, _error_0, _cursor_0, ($$$$047$$$047src$047ecs$047component$058tx_set$1261$(($schema$058recipe$()), _tx_0, _handle_0, _incoming_0)));
}

function $$$$047$$$047src$047ecs$047owned$045family$058replaced$1261$(_rest_0, _result_0) {
  if (_result_0.$ === "../../src/ecs/restored-row.Replaced") {
    const _cell_0 = _result_0["cell"];
    const _previous_0 = _result_0["previous"];
    const _stamp_0 = _result_0["stamp"];
    return {$: "../../src/ecs/owned-family.Written", "owner": ($owned$045rows$058put_work_recipe$(($owned$045rows$058journal_work_recipe$(_rest_0, _previous_0, _stamp_0)), _cell_0))};
  } else {
    const _cell_1 = _result_0["cell"];
    const _incoming_0 = _result_0["incoming"];
    return $$$$047$$$047src$047ecs$047owned$045family$058replace_refused$1261$(_cell_1, _incoming_0, ($owned$045rows$058header_work_recipe$(_rest_0)));
  }
}

function $$$$047$$$047src$047ecs$047restored$045row$058replace$1261$(_cell_0, _incoming_0, _tick_0) {
  if (_cell_0.$ === "../../src/ecs/restored-row.Taken") {
    const _id_0 = _cell_0["id"];
    const _owner_0 = _cell_0["owner"];
    const _stamp_0 = _cell_0["stamp"];
    const _cold_0 = _cell_0["restore"];
    return $$$$047$$$047src$047ecs$047restored$045row$058replacement_present$1261$(_id_0, _stamp_0, _cold_0, _incoming_0, _tick_0, ($$$$047$$$047src$047ecs$047restored$045row$058owner_present$1261$(_owner_0)));
  } else {
    const _column_0 = _cell_0["column"];
    return {$: "../../src/ecs/restored-row.Refused", "cell": {$: "../../src/ecs/restored-row.Untaken", "column": _column_0}, "incoming": _incoming_0};
  }
}

function $owned$045rows$058bridge_work_queue_write_frame$(_incoming_0, _frame_0) {
  const _tx_0 = _frame_0["tx"];
  const _handle_0 = _frame_0["handle"];
  const _error_0 = _frame_0["error"];
  const _cursor_0 = _frame_0["cursor"];
  return $owned$045rows$058bridge_work_queue_write_result$(_handle_0, _error_0, _cursor_0, ($$$$047$$$047src$047ecs$047component$058tx_set$1262$(($schema$058queue$()), _tx_0, _handle_0, _incoming_0)));
}

function $$$$047$$$047src$047ecs$047owned$045family$058replaced$1262$(_rest_0, _result_0) {
  if (_result_0.$ === "../../src/ecs/restored-row.Replaced") {
    const _cell_0 = _result_0["cell"];
    const _previous_0 = _result_0["previous"];
    const _stamp_0 = _result_0["stamp"];
    return {$: "../../src/ecs/owned-family.Written", "owner": ($owned$045rows$058put_work_queue$(($owned$045rows$058journal_work_queue$(_rest_0, _previous_0, _stamp_0)), _cell_0))};
  } else {
    const _cell_1 = _result_0["cell"];
    const _incoming_0 = _result_0["incoming"];
    return $$$$047$$$047src$047ecs$047owned$045family$058replace_refused$1262$(_cell_1, _incoming_0, ($owned$045rows$058header_work_queue$(_rest_0)));
  }
}

function $$$$047$$$047src$047ecs$047restored$045row$058replace$1262$(_cell_0, _incoming_0, _tick_0) {
  if (_cell_0.$ === "../../src/ecs/restored-row.Taken") {
    const _id_0 = _cell_0["id"];
    const _owner_0 = _cell_0["owner"];
    const _stamp_0 = _cell_0["stamp"];
    const _cold_0 = _cell_0["restore"];
    return $$$$047$$$047src$047ecs$047restored$045row$058replacement_present$1262$(_id_0, _stamp_0, _cold_0, _incoming_0, _tick_0, ($$$$047$$$047src$047ecs$047restored$045row$058owner_present$1262$(_owner_0)));
  } else {
    const _column_0 = _cell_0["column"];
    return {$: "../../src/ecs/restored-row.Refused", "cell": {$: "../../src/ecs/restored-row.Untaken", "column": _column_0}, "incoming": _incoming_0};
  }
}

function $owned$045rows$058bridge_advanced_stock_get$(_row_0) {
  return $owned$045rows$058bridge_advanced_stock_get_join$(($$$$047$$$047src$047ecs$047compose$058get$1260$(($owned$045rows$058leave_advanced$(_row_0)))));
}

function $$$$047$$$047src$047ecs$047owned$045family$058projected$1264$(_rest_0, _result_0) {
  if (_result_0.$ === "../../src/ecs/restored-row.Projected") {
    const _cell_0 = _result_0["cell"];
    const _t_0 = _result_0["value"];
    if (_t_0.$ === "None") {
      return {$: "Tuple", "fst": ($owned$045rows$058put_advanced_stock$(_rest_0, _cell_0)), "snd": {$: "../../src/ecs/component.ComponentAbsent"}};
    } else {
      const _value_0 = _t_0["value"];
      return {$: "Tuple", "fst": ($owned$045rows$058put_advanced_stock$(_rest_0, _cell_0)), "snd": {$: "../../src/ecs/component.Found", "value": _value_0}};
    }
  } else {
    const _cell_1 = _result_0["cell"];
    return $owned$045rows$058bridge_advanced_stock_get$(($owned$045rows$058put_advanced_stock$(_rest_0, _cell_1)));
  }
}

function $owned$045rows$058bridge_advanced_queue_get$(_row_0) {
  return $owned$045rows$058bridge_advanced_queue_get_join$(($$$$047$$$047src$047ecs$047compose$058get$1262$(($owned$045rows$058leave_advanced$(_row_0)))));
}

function $$$$047$$$047src$047ecs$047owned$045family$058projected$1265$(_rest_0, _result_0) {
  if (_result_0.$ === "../../src/ecs/restored-row.Projected") {
    const _cell_0 = _result_0["cell"];
    const _t_0 = _result_0["value"];
    if (_t_0.$ === "None") {
      return {$: "Tuple", "fst": ($owned$045rows$058put_advanced_queue$(_rest_0, _cell_0)), "snd": {$: "../../src/ecs/component.ComponentAbsent"}};
    } else {
      const _value_0 = _t_0["value"];
      return {$: "Tuple", "fst": ($owned$045rows$058put_advanced_queue$(_rest_0, _cell_0)), "snd": {$: "../../src/ecs/component.Found", "value": _value_0}};
    }
  } else {
    const _cell_1 = _result_0["cell"];
    return $owned$045rows$058bridge_advanced_queue_get$(($owned$045rows$058put_advanced_queue$(_rest_0, _cell_1)));
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_lifecycle_got$1261$(_values_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "Tuple", "fst": ($$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0)), "snd": _stamp_0};
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepared_lifecycle_got$1261$(_values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": _stamp_0};
}

function $owned$045rows$058bridge_work_recipe_write_result$(_handle_0, _error_0, _cursor_0, _result_0) {
  if (_result_0.$ === "../../src/ecs/component.Written") {
    const _tx_0 = _result_0["tx"];
    return {$: "../../src/ecs/owned-family.Written", "owner": ($owned$045rows$058enter_work$({$: "../../src/ecs/compose.Frame", "tx": _tx_0, "handle": _handle_0, "error": _error_0, "cursor": _cursor_0}))};
  } else if (_result_0.$ === "../../src/ecs/component.WriteRejected") {
    const _tx_1 = _result_0["tx"];
    const _incoming_0 = _result_0["incoming"];
    const _reason_0 = _result_0["error"];
    return {$: "../../src/ecs/owned-family.Rejected", "owner": ($owned$045rows$058enter_work$({$: "../../src/ecs/compose.Frame", "tx": _tx_1, "handle": _handle_0, "error": ($$$$047$$$047src$047ecs$047compose$058first_error$(_error_0, _reason_0)), "cursor": _cursor_0})), "incoming": _incoming_0, "error": _reason_0};
  } else {
    const _tx_2 = _result_0["tx"];
    const _reason_1 = _result_0["error"];
    return {$: "../../src/ecs/owned-family.Written", "owner": ($owned$045rows$058enter_work$({$: "../../src/ecs/compose.Frame", "tx": _tx_2, "handle": _handle_0, "error": ($$$$047$$$047src$047ecs$047compose$058first_error$(_error_0, _reason_1)), "cursor": _cursor_0}))};
  }
}

function $$$$047$$$047src$047ecs$047component$058tx_set$1261$(_family_0, _tx_0, _handle_0, _incoming_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047src$047ecs$047component$058tx_set_fused$1261$(_family_0, _handle_0, _undo_0, _commands_0, _events_0, ($$$$047$$$047src$047ecs$047component$058stamped_allowed$1261$(($$$$047$$$047src$047ecs$047world$058valid$1260$(_world_0, _handle_0)), _handle_0, _incoming_0)));
}

function $owned$045rows$058journal_work_recipe$(_rest_0, _previous_0, _stamp_0) {
  const _header_0 = _rest_0["header"];
  const _stock_0 = _rest_0["stock"];
  const _queue_0 = _rest_0["queue"];
  const _cold_0 = _rest_0["cold"];
  return $owned$045rows$058journal_work_recipe_header$(_stock_0, _queue_0, _cold_0, _previous_0, _stamp_0, _header_0);
}

function $$$$047$$$047src$047ecs$047owned$045family$058replace_refused$1261$(_cell_0, _incoming_0, _observed_0) {
  const _rest_0 = _observed_0["fst"];
  const _header_0 = _observed_0["snd"];
  return $$$$047$$$047src$047ecs$047owned$045family$058rejected$1261$(_rest_0, _cell_0, _incoming_0, {$: "../../src/ecs/world.CapacityExceeded"}, _header_0);
}

function $$$$047$$$047src$047ecs$047restored$045row$058replacement_present$1261$(_id_0, _stamp_0, _cold_0, _incoming_0, _tick_0, _observed_0) {
  const _previous_0 = _observed_0["fst"];
  const _present_0 = _observed_0["snd"];
  return {$: "../../src/ecs/restored-row.Replaced", "cell": {$: "../../src/ecs/restored-row.Taken", "id": _id_0, "owner": {$: "Some", "value": _incoming_0}, "stamp": ($$$$047$$$047src$047ecs$047lifecycle$058after_write$(true, _present_0, _stamp_0, _tick_0)), "dirty": true, "restore": _cold_0}, "previous": _previous_0, "stamp": _stamp_0};
}

function $$$$047$$$047src$047ecs$047restored$045row$058owner_present$1261$(_owner_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "None"}, "snd": false};
  } else {
    const _owner_1 = _owner_0["value"];
    return {$: "Tuple", "fst": {$: "Some", "value": _owner_1}, "snd": true};
  }
}

function $owned$045rows$058bridge_work_queue_write_result$(_handle_0, _error_0, _cursor_0, _result_0) {
  if (_result_0.$ === "../../src/ecs/component.Written") {
    const _tx_0 = _result_0["tx"];
    return {$: "../../src/ecs/owned-family.Written", "owner": ($owned$045rows$058enter_work$({$: "../../src/ecs/compose.Frame", "tx": _tx_0, "handle": _handle_0, "error": _error_0, "cursor": _cursor_0}))};
  } else if (_result_0.$ === "../../src/ecs/component.WriteRejected") {
    const _tx_1 = _result_0["tx"];
    const _incoming_0 = _result_0["incoming"];
    const _reason_0 = _result_0["error"];
    return {$: "../../src/ecs/owned-family.Rejected", "owner": ($owned$045rows$058enter_work$({$: "../../src/ecs/compose.Frame", "tx": _tx_1, "handle": _handle_0, "error": ($$$$047$$$047src$047ecs$047compose$058first_error$(_error_0, _reason_0)), "cursor": _cursor_0})), "incoming": _incoming_0, "error": _reason_0};
  } else {
    const _tx_2 = _result_0["tx"];
    const _reason_1 = _result_0["error"];
    return {$: "../../src/ecs/owned-family.Written", "owner": ($owned$045rows$058enter_work$({$: "../../src/ecs/compose.Frame", "tx": _tx_2, "handle": _handle_0, "error": ($$$$047$$$047src$047ecs$047compose$058first_error$(_error_0, _reason_1)), "cursor": _cursor_0}))};
  }
}

function $$$$047$$$047src$047ecs$047component$058tx_set$1262$(_family_0, _tx_0, _handle_0, _incoming_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047src$047ecs$047component$058tx_set_fused$1262$(_family_0, _handle_0, _undo_0, _commands_0, _events_0, ($$$$047$$$047src$047ecs$047component$058stamped_allowed$1262$(($$$$047$$$047src$047ecs$047world$058valid$1260$(_world_0, _handle_0)), _handle_0, _incoming_0)));
}

function $owned$045rows$058journal_work_queue$(_rest_0, _previous_0, _stamp_0) {
  const _header_0 = _rest_0["header"];
  const _stock_0 = _rest_0["stock"];
  const _recipe_0 = _rest_0["recipe"];
  const _cold_0 = _rest_0["cold"];
  return $owned$045rows$058journal_work_queue_header$(_stock_0, _recipe_0, _cold_0, _previous_0, _stamp_0, _header_0);
}

function $$$$047$$$047src$047ecs$047owned$045family$058replace_refused$1262$(_cell_0, _incoming_0, _observed_0) {
  const _rest_0 = _observed_0["fst"];
  const _header_0 = _observed_0["snd"];
  return $$$$047$$$047src$047ecs$047owned$045family$058rejected$1262$(_rest_0, _cell_0, _incoming_0, {$: "../../src/ecs/world.CapacityExceeded"}, _header_0);
}

function $$$$047$$$047src$047ecs$047restored$045row$058replacement_present$1262$(_id_0, _stamp_0, _cold_0, _incoming_0, _tick_0, _observed_0) {
  const _previous_0 = _observed_0["fst"];
  const _present_0 = _observed_0["snd"];
  return {$: "../../src/ecs/restored-row.Replaced", "cell": {$: "../../src/ecs/restored-row.Taken", "id": _id_0, "owner": {$: "Some", "value": _incoming_0}, "stamp": ($$$$047$$$047src$047ecs$047lifecycle$058after_write$(true, _present_0, _stamp_0, _tick_0)), "dirty": true, "restore": _cold_0}, "previous": _previous_0, "stamp": _stamp_0};
}

function $$$$047$$$047src$047ecs$047restored$045row$058owner_present$1262$(_owner_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "None"}, "snd": false};
  } else {
    const _owner_1 = _owner_0["value"];
    return {$: "Tuple", "fst": {$: "Some", "value": _owner_1}, "snd": true};
  }
}

function $owned$045rows$058bridge_advanced_stock_get_join$(_observed_0) {
  const _frame_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($owned$045rows$058enter_advanced$(_frame_0)), "snd": _value_0};
}

function $owned$045rows$058bridge_advanced_queue_get_join$(_observed_0) {
  const _frame_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($owned$045rows$058enter_advanced$(_frame_0)), "snd": _value_0};
}

function $$$$047$$$047src$047ecs$047component$058tx_set_fused$1261$(_family_0, _handle_0, _undo_0, _commands_0, _events_0, _observed_0) {
  const _result_0 = _observed_0["fst"];
  const _stamp_0 = _observed_0["snd"];
  return $$$$047$$$047src$047ecs$047component$058tx_written$1261$(_family_0, _handle_0, _undo_0, _commands_0, _events_0, _stamp_0, _result_0);
}

function $$$$047$$$047src$047ecs$047component$058stamped_allowed$1261$(_checked_0, _handle_0, _incoming_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": {$: "../../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": {$: "Some", "value": _incoming_0}, "error": {$: "../../src/ecs/world.MissingEntity"}}, "snd": {$: "../../src/ecs/lifecycle.Stamp", "added": 0, "changed": 0}};
  } else {
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047src$047ecs$047component$058stamped_world$1261$(_id_0, _incoming_0, _world_0);
  }
}

function $owned$045rows$058journal_work_recipe_header$(_stock_0, _queue_0, _cold_0, _previous_0, _stamp_0, _header_0) {
  const _namespace_0 = _header_0["namespace"];
  const _nextId_0 = _header_0["nextId"];
  const _live_0 = _header_0["live"];
  const _handle_0 = _header_0["handle"];
  const _clock_0 = _header_0["clock"];
  const _error_0 = _header_0["error"];
  const _cursor_0 = _header_0["cursor"];
  return {$: "owned-rows.WorkRecipeRest", "header": {$: "../../src/ecs/owned-family.Header", "namespace": _namespace_0, "nextId": _nextId_0, "live": _live_0, "handle": _handle_0, "clock": _clock_0, "error": _error_0, "cursor": _cursor_0}, "stock": _stock_0, "queue": _queue_0, "cold": ($owned$045rows$058journal_work_recipe_cold$(_handle_0, _previous_0, _stamp_0, _cold_0))};
}

function $$$$047$$$047src$047ecs$047component$058tx_set_fused$1262$(_family_0, _handle_0, _undo_0, _commands_0, _events_0, _observed_0) {
  const _result_0 = _observed_0["fst"];
  const _stamp_0 = _observed_0["snd"];
  return $$$$047$$$047src$047ecs$047component$058tx_written$1262$(_family_0, _handle_0, _undo_0, _commands_0, _events_0, _stamp_0, _result_0);
}

function $$$$047$$$047src$047ecs$047component$058stamped_allowed$1262$(_checked_0, _handle_0, _incoming_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": {$: "../../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": {$: "Some", "value": _incoming_0}, "error": {$: "../../src/ecs/world.MissingEntity"}}, "snd": {$: "../../src/ecs/lifecycle.Stamp", "added": 0, "changed": 0}};
  } else {
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047src$047ecs$047component$058stamped_world$1262$(_id_0, _incoming_0, _world_0);
  }
}

function $owned$045rows$058journal_work_queue_header$(_stock_0, _recipe_0, _cold_0, _previous_0, _stamp_0, _header_0) {
  const _namespace_0 = _header_0["namespace"];
  const _nextId_0 = _header_0["nextId"];
  const _live_0 = _header_0["live"];
  const _handle_0 = _header_0["handle"];
  const _clock_0 = _header_0["clock"];
  const _error_0 = _header_0["error"];
  const _cursor_0 = _header_0["cursor"];
  return {$: "owned-rows.WorkQueueRest", "header": {$: "../../src/ecs/owned-family.Header", "namespace": _namespace_0, "nextId": _nextId_0, "live": _live_0, "handle": _handle_0, "clock": _clock_0, "error": _error_0, "cursor": _cursor_0}, "stock": _stock_0, "recipe": _recipe_0, "cold": ($owned$045rows$058journal_work_queue_cold$(_handle_0, _previous_0, _stamp_0, _cold_0))};
}

function $$$$047$$$047src$047ecs$047component$058tx_written$1261$(_family_0, _handle_0, _undo_0, _commands_0, _events_0, _stamp_0, _result_0) {
  if (_result_0.$ === "../../src/ecs/component.Replaced") {
    const _world_0 = _result_0["world"];
    const _previous_0 = _result_0["previous"];
    return {$: "../../src/ecs/component.Written", "tx": {$: "../../src/ecs/transaction.Tx", "world": _world_0, "undo": {$: "Con", "head": run_clo((_x_0) => {
  return $$$$047$$$047src$047ecs$047component$058restore_stamp$1261$(_handle_0, _stamp_0, ($$$$047$$$047src$047ecs$047component$058restore$1261$(_family_0, _handle_0, _previous_0, _x_0)));
}), "tail": _undo_0}, "commands": _commands_0, "events": _events_0}};
  } else {
    const _world_1 = _result_0["world"];
    const _t_0 = _result_0["incoming"];
    if (_t_0.$ === "Some") {
      const _incoming_0 = _t_0["value"];
      const _error_0 = _result_0["error"];
      return {$: "../../src/ecs/component.WriteRejected", "tx": {$: "../../src/ecs/transaction.Tx", "world": _world_1, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "incoming": _incoming_0, "error": _error_0};
    } else {
      const _error_1 = _result_0["error"];
      return {$: "../../src/ecs/component.WriteFailure", "tx": {$: "../../src/ecs/transaction.Tx", "world": _world_1, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "error": _error_1};
    }
  }
}

function $$$$047$$$047src$047ecs$047component$058stamped_world$1261$(_id_0, _incoming_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047src$047ecs$047component$058stamped_replaced$1261$(($$$$047$$$047src$047ecs$047world$058with_store_finish$12612$(($$$$047$$$047src$047ecs$047component$058stamped_store$1261$(_id_0, _incoming_0, ($$$$047$$$047src$047ecs$047component$058stamped_tick$(_clock_0, (_clock_0 < 4294967295))), (_clock_0 < 4294967295), ($schema$058take_recipe$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, ($$$$047$$$047src$047ecs$047component$058stamped_tick$(_clock_0, (_clock_0 < 4294967295))))));
}

function $owned$045rows$058journal_work_recipe_cold$($0, $1, $2, $3) {
  for (;;) {
    {
      const _handle_0 = $0;
      const _previous_0 = $1;
      const _stamp_0 = $2;
      const _cold_0 = $3;
      if (_cold_0.$ === "owned-rows.WorkCold") {
        const _t_0 = _cold_0["state"];
        const _highWater_0 = _t_0["highWater"];
        const _capacity_0 = _t_0["capacity"];
        const _depth_0 = _t_0["depth"];
        const _enabled_0 = _t_0["enabled"];
        const _locked_0 = _t_0["locked"];
        const _resource_0 = _t_0["resource"];
        const _events_0 = _t_0["events"];
        const _pending_0 = _t_0["pending"];
        const _registrations_0 = _t_0["registrations"];
        const _nextSystemId_0 = _t_0["nextSystemId"];
        const _undo_0 = _t_0["undo"];
        const _commands_0 = _t_0["commands"];
        const _txEvents_0 = _t_0["txEvents"];
        return {$: "owned-rows.WorkCold", "state": {$: "owned-rows.WorkColdState", "highWater": _highWater_0, "capacity": _capacity_0, "depth": _depth_0, "enabled": _enabled_0, "locked": _locked_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "undo": {$: "Con", "head": run_clo((_x_0) => {
  return $$$$047$$$047src$047ecs$047component$058restore_stamp$1261$(_handle_0, _stamp_0, ($$$$047$$$047src$047ecs$047component$058restore$1261$(($schema$058recipe$()), _handle_0, _previous_0, _x_0)));
}), "tail": _undo_0}, "commands": _commands_0, "txEvents": _txEvents_0}};
      } else {
        const _inner_0 = _cold_0["inner"];
        $0 = _handle_0;
        $1 = _previous_0;
        $2 = _stamp_0;
        $3 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047component$058tx_written$1262$(_family_0, _handle_0, _undo_0, _commands_0, _events_0, _stamp_0, _result_0) {
  if (_result_0.$ === "../../src/ecs/component.Replaced") {
    const _world_0 = _result_0["world"];
    const _previous_0 = _result_0["previous"];
    return {$: "../../src/ecs/component.Written", "tx": {$: "../../src/ecs/transaction.Tx", "world": _world_0, "undo": {$: "Con", "head": run_clo((_x_0) => {
  return $$$$047$$$047src$047ecs$047component$058restore_stamp$1262$(_handle_0, _stamp_0, ($$$$047$$$047src$047ecs$047component$058restore$1262$(_family_0, _handle_0, _previous_0, _x_0)));
}), "tail": _undo_0}, "commands": _commands_0, "events": _events_0}};
  } else {
    const _world_1 = _result_0["world"];
    const _t_0 = _result_0["incoming"];
    if (_t_0.$ === "Some") {
      const _incoming_0 = _t_0["value"];
      const _error_0 = _result_0["error"];
      return {$: "../../src/ecs/component.WriteRejected", "tx": {$: "../../src/ecs/transaction.Tx", "world": _world_1, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "incoming": _incoming_0, "error": _error_0};
    } else {
      const _error_1 = _result_0["error"];
      return {$: "../../src/ecs/component.WriteFailure", "tx": {$: "../../src/ecs/transaction.Tx", "world": _world_1, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "error": _error_1};
    }
  }
}

function $$$$047$$$047src$047ecs$047component$058stamped_world$1262$(_id_0, _incoming_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047src$047ecs$047component$058stamped_replaced$1262$(($$$$047$$$047src$047ecs$047world$058with_store_finish$12613$(($$$$047$$$047src$047ecs$047component$058stamped_store$1262$(_id_0, _incoming_0, ($$$$047$$$047src$047ecs$047component$058stamped_tick$(_clock_0, (_clock_0 < 4294967295))), (_clock_0 < 4294967295), ($schema$058take_queue$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, ($$$$047$$$047src$047ecs$047component$058stamped_tick$(_clock_0, (_clock_0 < 4294967295))))));
}

function $owned$045rows$058journal_work_queue_cold$($0, $1, $2, $3) {
  for (;;) {
    {
      const _handle_0 = $0;
      const _previous_0 = $1;
      const _stamp_0 = $2;
      const _cold_0 = $3;
      if (_cold_0.$ === "owned-rows.WorkCold") {
        const _t_0 = _cold_0["state"];
        const _highWater_0 = _t_0["highWater"];
        const _capacity_0 = _t_0["capacity"];
        const _depth_0 = _t_0["depth"];
        const _enabled_0 = _t_0["enabled"];
        const _locked_0 = _t_0["locked"];
        const _resource_0 = _t_0["resource"];
        const _events_0 = _t_0["events"];
        const _pending_0 = _t_0["pending"];
        const _registrations_0 = _t_0["registrations"];
        const _nextSystemId_0 = _t_0["nextSystemId"];
        const _undo_0 = _t_0["undo"];
        const _commands_0 = _t_0["commands"];
        const _txEvents_0 = _t_0["txEvents"];
        return {$: "owned-rows.WorkCold", "state": {$: "owned-rows.WorkColdState", "highWater": _highWater_0, "capacity": _capacity_0, "depth": _depth_0, "enabled": _enabled_0, "locked": _locked_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "undo": {$: "Con", "head": run_clo((_x_0) => {
  return $$$$047$$$047src$047ecs$047component$058restore_stamp$1262$(_handle_0, _stamp_0, ($$$$047$$$047src$047ecs$047component$058restore$1262$(($schema$058queue$()), _handle_0, _previous_0, _x_0)));
}), "tail": _undo_0}, "commands": _commands_0, "txEvents": _txEvents_0}};
      } else {
        const _inner_0 = _cold_0["inner"];
        $0 = _handle_0;
        $1 = _previous_0;
        $2 = _stamp_0;
        $3 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047component$058restore_stamp$1261$(_handle_0, _stamp_0, _world_0) {
  const _id_0 = _handle_0["id"];
  return $$$$047$$$047src$047ecs$047component$058restore_stamp_done$1261$(($$$$047$$$047src$047ecs$047component$058restore_stamp_world$1261$(_id_0, _stamp_0, _world_0)));
}

function $$$$047$$$047src$047ecs$047component$058restore$1261$(_family_0, _handle_0, _incoming_0, _world_0) {
  return $$$$047$$$047src$047ecs$047component$058restore_allowed$1261$(($$$$047$$$047src$047ecs$047world$058metadata_valid$1260$(_world_0, _handle_0)), _handle_0, _incoming_0);
}

function $$$$047$$$047src$047ecs$047component$058stamped_replaced$1261$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  const _t_1 = _t_0["fst"];
  if (_t_1.$ === "../../src/ecs/component.Swapped") {
    const _previous_0 = _t_1["previous"];
    const _stamp_0 = _t_0["snd"];
    return {$: "Tuple", "fst": {$: "../../src/ecs/component.Replaced", "world": _world_0, "previous": _previous_0}, "snd": _stamp_0};
  } else {
    const _incoming_0 = _t_1["incoming"];
    const _stamp_1 = _t_0["snd"];
    return {$: "Tuple", "fst": {$: "../../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../src/ecs/world.CapacityExceeded"}}, "snd": _stamp_1};
  }
}

function $$$$047$$$047src$047ecs$047world$058with_store_finish$12612$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047src$047ecs$047component$058stamped_store$1261$(_id_0, _incoming_0, _tick_0, _allowed_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047src$047ecs$047component$058stamped_column$1261$(_rest_0, _id_0, _incoming_0, _tick_0, _allowed_0, ($$$$047$$$047src$047ecs$047column$058lifecycle$1261$(_column_0, _id_0)));
}

function $$$$047$$$047src$047ecs$047component$058restore_stamp$1262$(_handle_0, _stamp_0, _world_0) {
  const _id_0 = _handle_0["id"];
  return $$$$047$$$047src$047ecs$047component$058restore_stamp_done$1262$(($$$$047$$$047src$047ecs$047component$058restore_stamp_world$1262$(_id_0, _stamp_0, _world_0)));
}

function $$$$047$$$047src$047ecs$047component$058restore$1262$(_family_0, _handle_0, _incoming_0, _world_0) {
  return $$$$047$$$047src$047ecs$047component$058restore_allowed$1262$(($$$$047$$$047src$047ecs$047world$058metadata_valid$1260$(_world_0, _handle_0)), _handle_0, _incoming_0);
}

function $$$$047$$$047src$047ecs$047component$058stamped_replaced$1262$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  const _t_1 = _t_0["fst"];
  if (_t_1.$ === "../../src/ecs/component.Swapped") {
    const _previous_0 = _t_1["previous"];
    const _stamp_0 = _t_0["snd"];
    return {$: "Tuple", "fst": {$: "../../src/ecs/component.Replaced", "world": _world_0, "previous": _previous_0}, "snd": _stamp_0};
  } else {
    const _incoming_0 = _t_1["incoming"];
    const _stamp_1 = _t_0["snd"];
    return {$: "Tuple", "fst": {$: "../../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../src/ecs/world.CapacityExceeded"}}, "snd": _stamp_1};
  }
}

function $$$$047$$$047src$047ecs$047world$058with_store_finish$12613$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047src$047ecs$047component$058stamped_store$1262$(_id_0, _incoming_0, _tick_0, _allowed_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047src$047ecs$047component$058stamped_column$1262$(_rest_0, _id_0, _incoming_0, _tick_0, _allowed_0, ($$$$047$$$047src$047ecs$047column$058lifecycle$1262$(_column_0, _id_0)));
}

function $$$$047$$$047src$047ecs$047component$058restore_stamp_done$1261$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  return _world_0;
}

function $$$$047$$$047src$047ecs$047component$058restore_stamp_world$1261$(_id_0, _stamp_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047src$047ecs$047world$058with_store_finish$12610$(($$$$047$$$047src$047ecs$047component$058restore_stamp_store$1261$(_id_0, _stamp_0, ($schema$058take_recipe$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047src$047ecs$047component$058restore_allowed$1261$(_checked_0, _handle_0, _incoming_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return _world_0;
  } else {
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047src$047ecs$047component$058restore_observed$1261$(($$$$047$$$047src$047ecs$047component$058restore_world$1261$(_id_0, _incoming_0, _world_0)));
  }
}

function $$$$047$$$047src$047ecs$047component$058stamped_column$1261$(_rest_0, _id_0, _incoming_0, _tick_0, _allowed_0, _observed_0) {
  if (!_allowed_0) {
    const _column_0 = _observed_0["fst"];
    const _stamp_0 = _observed_0["snd"];
    return {$: "Tuple", "fst": ($schema$058put_recipe$(_rest_0, _column_0)), "snd": {$: "Tuple", "fst": {$: "../../src/ecs/component.SwapRejected", "incoming": {$: "Some", "value": _incoming_0}}, "snd": _stamp_0}};
  } else {
    const _column_1 = _observed_0["fst"];
    const _stamp_1 = _observed_0["snd"];
    return $$$$047$$$047src$047ecs$047component$058stamped_store_join$1261$(_stamp_1, ($$$$047$$$047src$047ecs$047component$058swap_join$1261$(_rest_0, _id_0, true, _tick_0, ($$$$047$$$047src$047ecs$047column$058swap$1261$(($$$$047$$$047src$047ecs$047column$058ensure$1261$(_column_1, _id_0)), _id_0, {$: "Some", "value": _incoming_0})))));
  }
}

function $$$$047$$$047src$047ecs$047component$058restore_stamp_done$1262$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  return _world_0;
}

function $$$$047$$$047src$047ecs$047component$058restore_stamp_world$1262$(_id_0, _stamp_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047src$047ecs$047world$058with_store_finish$12610$(($$$$047$$$047src$047ecs$047component$058restore_stamp_store$1262$(_id_0, _stamp_0, ($schema$058take_queue$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047src$047ecs$047component$058restore_allowed$1262$(_checked_0, _handle_0, _incoming_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return _world_0;
  } else {
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047src$047ecs$047component$058restore_observed$1262$(($$$$047$$$047src$047ecs$047component$058restore_world$1262$(_id_0, _incoming_0, _world_0)));
  }
}

function $$$$047$$$047src$047ecs$047component$058stamped_column$1262$(_rest_0, _id_0, _incoming_0, _tick_0, _allowed_0, _observed_0) {
  if (!_allowed_0) {
    const _column_0 = _observed_0["fst"];
    const _stamp_0 = _observed_0["snd"];
    return {$: "Tuple", "fst": ($schema$058put_queue$(_rest_0, _column_0)), "snd": {$: "Tuple", "fst": {$: "../../src/ecs/component.SwapRejected", "incoming": {$: "Some", "value": _incoming_0}}, "snd": _stamp_0}};
  } else {
    const _column_1 = _observed_0["fst"];
    const _stamp_1 = _observed_0["snd"];
    return $$$$047$$$047src$047ecs$047component$058stamped_store_join$1262$(_stamp_1, ($$$$047$$$047src$047ecs$047component$058swap_join$1262$(_rest_0, _id_0, true, _tick_0, ($$$$047$$$047src$047ecs$047column$058swap$1262$(($$$$047$$$047src$047ecs$047column$058ensure$1262$(_column_1, _id_0)), _id_0, {$: "Some", "value": _incoming_0})))));
  }
}

function $$$$047$$$047src$047ecs$047column$058lifecycle$1262$(_column_0, _id_0) {
  if (_column_0.$ === "../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "Tuple", "fst": {$: "../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": ($$$$047$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0))};
  } else if (_column_0.$ === "../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058lifecycle_state$1262$(_id_0, ($$$$047$$$047src$047ecs$047column$058unseal$1262$(_carrier_0)));
  } else if (_column_0.$ === "../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058indexed_lifecycle_state$1262$(_id_0, ($$$$047$$$047src$047ecs$047column$058indexed_unseal$1262$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058indexed_prepared_lifecycle_state$1262$(_id_0, ($$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1262$(_carrier_2)));
  }
}

function $$$$047$$$047src$047ecs$047component$058restore_stamp_store$1261$(_id_0, _stamp_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return {$: "Tuple", "fst": ($schema$058put_recipe$(_rest_0, ($$$$047$$$047src$047ecs$047column$058restore_stamp$1261$(_column_0, _id_0, _stamp_0)))), "snd": {$: "Unit"}};
}

function $$$$047$$$047src$047ecs$047component$058restore_observed$1261$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  return _world_0;
}

function $$$$047$$$047src$047ecs$047component$058restore_world$1261$(_id_0, _incoming_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047src$047ecs$047world$058with_store_finish$12610$(($$$$047$$$047src$047ecs$047component$058restore_store$1261$(_id_0, _incoming_0, ($schema$058take_recipe$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047src$047ecs$047component$058stamped_store_join$1261$(_stamp_0, _result_0) {
  const _store_0 = _result_0["fst"];
  const _outcome_0 = _result_0["snd"];
  return {$: "Tuple", "fst": _store_0, "snd": {$: "Tuple", "fst": _outcome_0, "snd": _stamp_0}};
}

function $$$$047$$$047src$047ecs$047component$058restore_stamp_store$1262$(_id_0, _stamp_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return {$: "Tuple", "fst": ($schema$058put_queue$(_rest_0, ($$$$047$$$047src$047ecs$047column$058restore_stamp$1262$(_column_0, _id_0, _stamp_0)))), "snd": {$: "Unit"}};
}

function $$$$047$$$047src$047ecs$047component$058restore_observed$1262$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  return _world_0;
}

function $$$$047$$$047src$047ecs$047component$058restore_world$1262$(_id_0, _incoming_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047src$047ecs$047world$058with_store_finish$12610$(($$$$047$$$047src$047ecs$047component$058restore_store$1262$(_id_0, _incoming_0, ($schema$058take_queue$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047src$047ecs$047component$058stamped_store_join$1262$(_stamp_0, _result_0) {
  const _store_0 = _result_0["fst"];
  const _outcome_0 = _result_0["snd"];
  return {$: "Tuple", "fst": _store_0, "snd": {$: "Tuple", "fst": _outcome_0, "snd": _stamp_0}};
}

function $$$$047$$$047src$047ecs$047column$058lifecycle_state$1262$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "Tuple", "fst": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": ($$$$047$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0))};
}

function $$$$047$$$047src$047ecs$047column$058indexed_lifecycle_state$1262$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047src$047ecs$047column$058indexed_lifecycle_got$1262$(_values_0, ($$$$047$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepared_lifecycle_state$1262$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047src$047ecs$047column$058indexed_prepared_lifecycle_got$1262$(_values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($$$$047$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047src$047ecs$047component$058restore_store$1261$(_id_0, _incoming_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047src$047ecs$047component$058restore_swap$1261$(_rest_0, ($$$$047$$$047src$047ecs$047column$058swap$1261$(($$$$047$$$047src$047ecs$047column$058ensure$1261$(_column_0, _id_0)), _id_0, _incoming_0)));
}

function $$$$047$$$047src$047ecs$047component$058restore_store$1262$(_id_0, _incoming_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047src$047ecs$047component$058restore_swap$1262$(_rest_0, ($$$$047$$$047src$047ecs$047column$058swap$1262$(($$$$047$$$047src$047ecs$047column$058ensure$1262$(_column_0, _id_0)), _id_0, _incoming_0)));
}

function $$$$047$$$047src$047ecs$047column$058indexed_lifecycle_got$1262$(_values_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "Tuple", "fst": ($$$$047$$$047src$047ecs$047column$058indexed_wrap$1262$(_values_0, _metadata_0)), "snd": _stamp_0};
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepared_lifecycle_got$1262$(_values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": _stamp_0};
}

function $$$$047$$$047src$047ecs$047component$058restore_swap$1261$(_rest_0, _result_0) {
  if (_result_0.$ === "../../src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    return {$: "Tuple", "fst": ($schema$058put_recipe$(_rest_0, _column_0)), "snd": {$: "Unit"}};
  } else {
    const _column_1 = _result_0["column"];
    return {$: "Tuple", "fst": ($schema$058put_recipe$(_rest_0, _column_1)), "snd": {$: "Unit"}};
  }
}

function $$$$047$$$047src$047ecs$047component$058restore_swap$1262$(_rest_0, _result_0) {
  if (_result_0.$ === "../../src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    return {$: "Tuple", "fst": ($schema$058put_queue$(_rest_0, _column_0)), "snd": {$: "Unit"}};
  } else {
    const _column_1 = _result_0["column"];
    return {$: "Tuple", "fst": ($schema$058put_queue$(_rest_0, _column_1)), "snd": {$: "Unit"}};
  }
}

// Cli
// ===

let cli_args = [];

function cli(argv) {
  cli_args.push(argv[0]);
  for (let i = 1; i < argv.length; i += 1) {
    if (argv[i] === "--") {
      cli_args.push(...argv.slice(i + 1));
      break;
    } else if (argv[i] === "--bend-help") {
      io_out(1, io_bytes("usage: " + argv[0] + "\n"));
      process.exit(0);
    } else if (argv[i] === "--threads" || argv[i] === "--gpu") {
      i += 1;
    } else {
      cli_args.push(argv[i]);
    }
  }
}

// Show
// ====

// show_val prints a pure main's value as term_show does (see show_main);
// chain is the bracket it continues, or 0. show_chr escapes as char_show.

function show_chr(c, q) {
  const k = { 10: "n", 9: "t", 13: "r", 0: "0", 92: "\\" }[c]
    ?? (c === q.codePointAt(0) ? q : null);
  return k !== null ? "\\" + k : c < 32 || c === 127
    || (c >= 0xD800 && c <= 0xDFFF) || c > 0x10FFFF
    ? "\\u{" + c.toString(16) + "}" : String.fromCodePoint(c);
}

function show_val(D, N, d, v, chain) {
  if (D[d] === 7) {
    const fs = Object.values(typeof v === "boolean"
      ? { $: v ? "True" : "False" } : v);
    let a = d + 3;
    for (; N[D[a]] !== fs[0]; a += 4 + 2 * D[a + 2]) {}
    const o = "{[("[D[a + 3]];
    let s = o === "{" ? fs[0] + "{" : chain === o ? "" : o;
    for (const [j, f] of fs.slice(1).entries()) {
      if (o === "[" ? j === 0 && chain === o : j > 0) {
        s += ", ";
      }
      s += show_val(D, N, D[a + 5 + 2 * j], f, j === 1 && o !== "{" ? o : 0);
    }
    return o === "{" || chain !== o ? s + "}])"[D[a + 3]] : s;
  }
  return D[d] === 0 ? String(v)
    : D[d] === 1 ? f32_show(v).replace(/^-?\d+(?=e|$)/, "$&.0")
    : D[d] === 2 ? v + "n"
    : D[d] === 3 ? "'" + show_chr(v.codePointAt(0), "'") + "'"
    : D[d] === 4 ? "\"" + [...v].map((c) =>
      show_chr(c.codePointAt(0), "\"")).join("") + "\""
    : D[d] === 5 ? "{==}"
    : "[" + v.map((x) => show_val(D, N, D[d + 1], x, 0)).join(", ") + "]";
}

// Io
// ==

// Apple arm64 passes variadic fcntl flags on the stack, so io_sys
// binds fcntl there with the flags as the ninth fixed argument. A
// parked effect waits for fd (a write when out) or until at
// (performance.now()), either one undefined when unused; io_wake
// resumes k with the value of more, and undefined parks it again. The
// waits stay in deadline order, as io_park does in C.

function io_exit(main, show) {
  try {
    if (show !== null) {
      io_out(1, io_bytes(show_val(...show, 0, run_loop(main()), 0) + "\n"));
      process.exit(0);
    }
    process.exit(io_run(main));
  } catch (e) {
    io_errs(String(e));
    process.exit(1);
  }
}

function io_out(fd, data) {
  const fs = require("fs");
  let at = 0;
  while (at < data.length) {
    try {
      at += fs.writeSync(fd, data, at, data.length - at);
    } catch (e) {
      if (e.code === "EAGAIN" || e.code === "EINTR") {
        continue;
      }
      try {
        fs.writeSync(2, "bend: a short write on a standard stream\n");
      } catch (o) {
      }
      process.exit(1);
    }
  }
}

function io_errs(message) {
  io_out(2, io_bytes(message + "\n"));
}

function io_sys() {
  if (globalThis.BEND_SYS === undefined) {
    const ffi = require("bun:ffi");
    const mac = process.platform === "darwin";
    const err = mac ? "__error" : "__errno_location";
    const sel = mac ? "select$DARWIN_EXTSN" : "select";
    const T = { i: "i32", u: "u32", U: "u64", I: "i64", p: "ptr",
      c: "cstring" };
    const vari = mac && process.arch === "arm64";
    const lib = ffi.dlopen(mac ? "libSystem.dylib" : "libc.so.6",
      Object.fromEntries(("socket:iii>i bind:ipu>i listen:ii>i connect:ipu>i"
        + " accept:ipp>i send:ipUi>I recv:ipUi>I read:ipU>I pread:ipUI>I"
        + " sendto:ipUipu>I recvfrom:ipUipp>I close:i>i setsockopt:iiipu>i"
        + " " + sel + ":ipppp>i"
        + (vari ? " fcntl:iiiiiiiii>i" : " fcntl:iii>i") + " getsockopt:iiipp>i"
        + " strerror:i>c " + err + ":>p").split(" ").map((s) => {
        const [name, args, ret] = s.split(/[:>]/);
        return [name, { args: [...args].map((a) => T[a]), returns: T[ret] }];
      }))).symbols;
    const fcntl = (fd, cmd, arg) => vari
      ? lib.fcntl(fd, cmd, 0, 0, 0, 0, 0, 0, arg)
      : lib.fcntl(fd, cmd, arg);
    globalThis.BEND_SYS = { ...lib, fcntl, select: lib[sel],
      ptr: ffi.ptr, mac,
      errno: () => ffi.read.i32(lib[err](), 0) };
  }
  return globalThis.BEND_SYS;
}

// strerror needs bun:ffi; a host without it (node) gets the bare errno.
function io_strerror(code) {
  try {
    return String(io_sys().strerror(code));
  } catch (_) {
    return "errno " + code;
  }
}

function io_fail(code) {
  return { $: "Fail",
    error: io_tup(code >>> 0, io_strerror(code)) };
}

function io_done(value) {
  return { $: "Done", value };
}

function io_tup(...xs) {
  return xs.reduceRight((snd, fst) => ({ $: "Tuple", fst, snd }));
}

function io_bytes(text) {
  return new TextEncoder().encode(text);
}

function io_text(b, n) {
  return new TextDecoder("utf-8", { ignoreBOM: true }).decode(b.subarray(0, n));
}

// Bytes cross as they are (0..255), one List cell each, with no UTF-8 in
// either direction; io_unlist answers null if a value is past 255.
function io_list(b, n) {
  let xs = { $: "Nil" };
  while (n > 0) {
    xs = { $: "Con", head: b[--n], tail: xs };
  }
  return xs;
}

function io_unlist(xs) {
  const b = [];
  for (; xs.$ === "Con"; xs = xs.tail) {
    b.push(xs.head);
  }
  return b.some((x) => x > 255) ? null : Uint8Array.from(b);
}

function io_addr(host, port) {
  const part = host.split(".");
  const deci = (p) => /^(0|[1-9]\d{0,2})$/.test(p) && Number(p) < 256;
  if (port > 65535 || part.length !== 4 || !part.every(deci)) {
    return null;
  }
  const b = new Uint8Array(16);
  const head = io_sys().mac ? [16, 2] : [2, 0];
  b.set([...head, port >> 8, port & 255, ...part.map(Number)]);
  return b;
}

function io_push(fun, arg, fresh) {
  const io = globalThis.BEND_IO;
  io.runs.push({ fun, arg });
  io.live += fresh ? 1 : 0;
}

function io_wait(io, block) {
  const soon = io.waits[0]?.at ?? Infinity;
  const ms = !block ? 0 : soon === Infinity ? -1
    : Math.max(0, Math.ceil(soon - performance.now()));
  const fds = io.waits.filter((w) => w.fd !== undefined);
  const top = fds.reduce((m, w) => Math.max(m, w.fd), 0);
  const len = (top >> 6 << 3) + 8;
  const set = new Uint8Array(2 * len);
  const at = (w) => (w.out ? len : 0) + (w.fd >> 3);
  for (const w of fds) {
    set[at(w)] |= 1 << (w.fd & 7);
  }
  const tv = new BigInt64Array([BigInt(ms / 1000 | 0),
    BigInt(ms % 1000 * 1000)]);
  const sys = io_sys();
  if (sys.select(top + 1, sys.ptr(set), sys.ptr(set, len), null,
    ms < 0 ? null : sys.ptr(tv)) < 0) {
    if (sys.errno() !== 4) {
      throw "bend: the poller failed";
    }
    set.fill(0);
  }
  const now = performance.now();
  io.waits = io.waits.filter((w) => {
    const ready = w.at <= now || w.fd !== undefined
      && set[at(w)] & 1 << (w.fd & 7);
    if (ready) {
      io_push(io_wake, w, false);
    }
    return !ready;
  });
}

function io_wake(w) {
  const x = w.more();
  return x === undefined ? undefined : w.k(x);
}

function io_park_on(fd, out, k, more, at) {
  const ws = globalThis.BEND_IO.waits;
  const i = ws.findLastIndex((w) => (w.at ?? Infinity) <= (at ?? Infinity));
  ws.splice(i + 1, 0, { fd, out, k, more, at });
}

function io_run(m) {
  const io = { runs: [], live: 0, waits: [] };
  globalThis.BEND_IO = io;
  try {
    io_push(run_loop(m()), (x) => ({ $: "Emit", value: x }), true);
    let look = 0;
    for (let n = 0;; n += 1) {
      if (io.runs.length === 0) {
        if (io.live === 0) {
          return 0;
        }
        if (io.waits.length === 0) {
          io_errs("bend: deadlock: every computation waits on a channel");
          return 1;
        }
        io_wait(io, true);
        continue;
      }
      if ((n & 63) === 0 && io.waits.length > 0) {
        const now = performance.now();
        if (now >= look || io.waits[0].at <= now) {
          look = now + 10;
          io_wait(io, false);
        }
      }
      const s = io.runs.shift();
      let op = s.fun(s.arg);
      while (op !== undefined) {
        if (op.$ === "Emit") {
          io.live -= 1;
          break;
        }
        if (op.$ === "Halt") {
          io_errs(op.message);
          return op.code;
        }
        const need = op.need?.() ?? {};
        if (need.time || need.read) {
          const more = () => op.run(...op.args, op.kont);
          io_park_on(need.read ? op.args[0] : undefined, false, op.kont, more,
            need.read ? undefined : performance.now() + Number(op.args[0]));
          break;
        }
        const x = op.run(...op.args, op.kont);
        if (x === undefined) {
          break;
        }
        op = op.kont(x);
      }
    }
  } catch (req) {
    if (req instanceof RangeError) {
      throw "bend: memory fault (machine stack overflow?)";
    }
    if (req?.$ !== "$FFI") {
      throw req;
    }
    io_errs("bend: runtime fail-stop");
    return 1;
  }
}

cli(process.argv.slice(1));
io_exit($main$, null);
}
(async()=>{
await post('HeapProfiler.enable');await post('HeapProfiler.startSampling',{samplingInterval:16384,includeObjectsCollectedByMajorGC:true,includeObjectsCollectedByMinorGC:true});
for(let i=0;i<20;i++){const t=performance.now();freshProgram();times.push(performance.now()-t);completed++;}
await new Promise(resolve=>setTimeout(resolve,20));
const result=await post('HeapProfiler.stopSampling');
require('node:fs').writeFileSync("/workspace/formal-proofs/bendvy/.artifacts/indexed-array-view-after-node-profiles/heap.heapprofile",JSON.stringify(result.profile));observer.disconnect();session.disconnect();process.exit=originalExit;process.stderr.write(JSON.stringify({completed,zeroExits,times,gc})+'\n');})().catch(error=>{process.stderr.write(String(error));originalExit(1);});
